-- models/marts/dim_customers_current.sql
-- Current-state dimension: one row per active customer.
-- Equivalent to: SELECT * FROM DIM_CUSTOMERS WHERE SCD_CUR_IND = 'Y'
--
-- Maps dbt snapshot internals to DIM_CUSTOMERS column conventions
-- (SCD_EFF_DTM, SCD_EXPN_DTM, SCD_CUR_IND, CUSTOMER_KEY, SCD_HASH).

WITH snap AS (
    SELECT * FROM {{ ref('snap_dim_customers') }}
    WHERE dbt_valid_to IS NULL   -- current rows only
)
SELECT
    -- Surrogate PK (stable per customer; same across all versions)
    {{ dbt_utils.generate_surrogate_key(['CUSTOMER_BUSINESS_KEY']) }}
                                                            AS CUSTOMER_KEY,

    -- SCD2 standard columns
    CUSTOMER_BUSINESS_KEY,
    dbt_valid_from                                          AS SCD_EFF_DTM,
    TIMESTAMP '{{ var("scd2_open_record_date") }} 00:00:00' AS SCD_EXPN_DTM,
    'Y'                                                     AS SCD_CUR_IND,

    -- Change-detection hash of all Type II columns (per SCD2_Requirements)
    SHA2(
        CONCAT_WS('|',
            COALESCE(CARD_TYPE,            ''),
            COALESCE(CARD_TYPE_NBR,        ''),
            COALESCE(CASINO_MEMBER_ID,     ''),
            COALESCE(CASINO_MEMBER_ID_OPT, ''),
            COALESCE(CASINO_MEMBER_ID_VRF, ''),
            COALESCE(CITY,                 ''),
            COALESCE(COUNTRY,              ''),
            COALESCE(CUSTOMER_TIER,        ''),
            COALESCE(CUSTOMER_TIER_CD,     ''),
            COALESCE(MAILING_ADDR_CITY,    ''),
            COALESCE(MAILING_ADDR_COUNTRY, ''),
            COALESCE(MAILING_ADDR_REGION,  ''),
            COALESCE(MAILING_POSTAL_CODE,  ''),
            COALESCE(MARKETING_CONTACT_OK, ''),
            COALESCE(PLAYNOW_JURISDICTION, ''),
            COALESCE(POSTAL_CODE,          ''),
            COALESCE(REGION,               ''),
            COALESCE(RESTRICTED_FLAG,      ''),
            COALESCE(SF_CAN_EMAIL,         '')
        ), 256
    )                                                       AS SCD_HASH,

    -- ELT metadata
    dbt_valid_from                                          AS ELT_CREATE_DTM,
    dbt_valid_from                                          AS ELT_UPDATE_DTM,
    'dbt_snap_dim_customers'                                AS ELT_JOB_NAME,
    0                                                       AS ELT_PRCS_RUN_ID,

    -- Source metadata
    SOURCE_SYSTEM,
    SYSTEM_MODIFIED_TIMESTAMP,

    -- SCD2 Type II attributes
    CARD_TYPE,
    CARD_TYPE_NBR,
    CASINO_MEMBER_ID,
    CASINO_MEMBER_ID_OPT,
    CASINO_MEMBER_ID_VRF,
    CITY,
    COUNTRY,
    CUSTOMER_TIER,
    CUSTOMER_TIER_CD,
    MAILING_ADDR_CITY,
    MAILING_ADDR_COUNTRY,
    MAILING_ADDR_REGION,
    MAILING_POSTAL_CODE,
    MARKETING_CONTACT_OK,
    PLAYNOW_JURISDICTION,
    POSTAL_CODE,
    REGION,
    RESTRICTED_FLAG,
    SF_CAN_EMAIL,

    -- Non-Type II attributes
    FIRST_NAME,
    LAST_NAME,
    SALUTATION,
    EMAIL,
    PHONE,
    MOBILE_PHONE,
    PLAYER_ID,
    PLAYNOW_ACCOUNT_STATUS,
    PLAYNOW_UUID,
    PLAYNOW_ACCOUNT_ID,
    CIH_UID,
    BC_GOLD_ACCOUNT_ID

FROM snap
