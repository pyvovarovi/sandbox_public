-- models/marts/dim_customers_history.sql
-- Full SCD2 history: all versions of every customer.
-- Use this model for point-in-time lookups:
--   WHERE :as_of_ts >= SCD_EFF_DTM AND :as_of_ts < SCD_EXPN_DTM
--
-- Interval semantics: half-open [SCD_EFF_DTM, SCD_EXPN_DTM)
-- On version close: new row's SCD_EFF_DTM = prior row's SCD_EXPN_DTM
-- (no gap, no overlap — enforced by assert_no_overlapping_periods test)

WITH snap AS (
    SELECT * FROM {{ ref('snap_dim_customers') }}
)
SELECT
    -- Version-level surrogate key (unique per SCD2 version)
    {{ dbt_utils.generate_surrogate_key(['CUSTOMER_BUSINESS_KEY', 'dbt_valid_from']) }}
                                                            AS CUSTOMER_VERSION_SK,

    -- Stable customer-level key (unchanged across versions)
    {{ dbt_utils.generate_surrogate_key(['CUSTOMER_BUSINESS_KEY']) }}
                                                            AS CUSTOMER_KEY,

    -- SCD2 standard columns
    CUSTOMER_BUSINESS_KEY,
    dbt_valid_from                                          AS SCD_EFF_DTM,
    COALESCE(
        dbt_valid_to,
        TIMESTAMP '{{ var("scd2_open_record_date") }} 00:00:00'
    )                                                       AS SCD_EXPN_DTM,
    CASE WHEN dbt_valid_to IS NULL THEN 'Y' ELSE 'N' END    AS SCD_CUR_IND,

    -- Change-detection hash of all Type II columns
    SHA2(
        CONCAT_WS('|',
            COALESCE(CARD_TYPE,            ''),
            COALESCE(CARD_TYPE_NBR,        ''),
            COALESCE(CASINO_MEMBER_ID,     ''),
            COALESCE(CASINO_MEMBER_ID_OPT, ''),
            COALESCE(CASINO_MEMBER_ID_VRF, ''),
            COALESCE(CITY,                 ''),
            COALESCE(COUNTRY,              ''),
            COALESCE(CUSTOMER_TIER,        ''),
            COALESCE(CUSTOMER_TIER_CD,     ''),
            COALESCE(MAILING_ADDR_CITY,    ''),
            COALESCE(MAILING_ADDR_COUNTRY, ''),
            COALESCE(MAILING_ADDR_REGION,  ''),
            COALESCE(MAILING_POSTAL_CODE,  ''),
            COALESCE(MARKETING_CONTACT_OK, ''),
            COALESCE(PLAYNOW_JURISDICTION, ''),
            COALESCE(POSTAL_CODE,          ''),
            COALESCE(REGION,               ''),
            COALESCE(RESTRICTED_FLAG,      ''),
            COALESCE(SF_CAN_EMAIL,         '')
        ), 256
    )                                                       AS SCD_HASH,

    -- ELT metadata
    dbt_valid_from                                          AS ELT_CREATE_DTM,
    dbt_valid_from                                          AS ELT_UPDATE_DTM,
    'dbt_snap_dim_customers'                                AS ELT_JOB_NAME,
    0                                                       AS ELT_PRCS_RUN_ID,

    -- Source metadata
    SOURCE_SYSTEM,
    SYSTEM_MODIFIED_TIMESTAMP,

    -- SCD2 Type II attributes
    CARD_TYPE,
    CARD_TYPE_NBR,
    CASINO_MEMBER_ID,
    CASINO_MEMBER_ID_OPT,
    CASINO_MEMBER_ID_VRF,
    CITY,
    COUNTRY,
    CUSTOMER_TIER,
    CUSTOMER_TIER_CD,
    MAILING_ADDR_CITY,
    MAILING_ADDR_COUNTRY,
    MAILING_ADDR_REGION,
    MAILING_POSTAL_CODE,
    MARKETING_CONTACT_OK,
    PLAYNOW_JURISDICTION,
    POSTAL_CODE,
    REGION,
    RESTRICTED_FLAG,
    SF_CAN_EMAIL,

    -- Non-Type II attributes
    FIRST_NAME,
    LAST_NAME,
    SALUTATION,
    EMAIL,
    PHONE,
    MOBILE_PHONE,
    PLAYER_ID,
    PLAYNOW_ACCOUNT_STATUS,
    PLAYNOW_UUID,
    PLAYNOW_ACCOUNT_ID,
    CIH_UID,
    BC_GOLD_ACCOUNT_ID

FROM snap
