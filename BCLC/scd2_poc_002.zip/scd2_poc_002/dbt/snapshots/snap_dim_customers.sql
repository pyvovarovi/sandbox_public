{# ===================================================================
   snap_dim_customers.sql

   STRATEGY: check
   - Tracks only the 19 explicitly listed SCD2 Type II columns.
   - Changes to any non-tracked column (FIRST_NAME, LAST_NAME, EMAIL,
     etc.) update the snapshot row in place — no new SCD2 version.
   - This matches the business rule: version history captures material
     attribute changes (tier, address, casino membership, flags) not
     cosmetic data corrections.

   HARD DELETES: invalidate_hard_deletes = true
   - When a customer row disappears from CUSTOMER_SRC_002 (e.g. C004
     deleted in round 2), dbt closes the open version by setting
     dbt_valid_to to the snapshot run timestamp.

   ANALOGOUS DATASTAGE PATTERN:
     Change Capture stage comparing hash of SCD2 cols → SCD stage
     writing EFF/EXPN dates; delete detection via outer join / CDC flag.
   =================================================================== #}

{% snapshot snap_dim_customers %}

    {{
        config(
            target_schema='SNAPSHOTS',
            unique_key='CUSTOMER_BUSINESS_KEY',
            strategy='check',
            check_cols=[
                'CARD_TYPE',
                'CARD_TYPE_NBR',
                'CASINO_MEMBER_ID',
                'CASINO_MEMBER_ID_OPT',
                'CASINO_MEMBER_ID_VRF',
                'CITY',
                'COUNTRY',
                'CUSTOMER_TIER',
                'CUSTOMER_TIER_CD',
                'MAILING_ADDR_CITY',
                'MAILING_ADDR_COUNTRY',
                'MAILING_ADDR_REGION',
                'MAILING_POSTAL_CODE',
                'MARKETING_CONTACT_OK',
                'PLAYNOW_JURISDICTION',
                'POSTAL_CODE',
                'REGION',
                'RESTRICTED_FLAG',
                'SF_CAN_EMAIL'
            ],
            invalidate_hard_deletes=True
        )
    }}

    SELECT
        CUSTOMER_BUSINESS_KEY,
        SYSTEM_MODIFIED_TIMESTAMP,
        -- SCD2 Type II tracked columns
        CARD_TYPE,
        CARD_TYPE_NBR,
        CASINO_MEMBER_ID,
        CASINO_MEMBER_ID_OPT,
        CASINO_MEMBER_ID_VRF,
        CITY,
        COUNTRY,
        CUSTOMER_TIER,
        CUSTOMER_TIER_CD,
        MAILING_ADDR_CITY,
        MAILING_ADDR_COUNTRY,
        MAILING_ADDR_REGION,
        MAILING_POSTAL_CODE,
        MARKETING_CONTACT_OK,
        PLAYNOW_JURISDICTION,
        POSTAL_CODE,
        REGION,
        RESTRICTED_FLAG,
        SF_CAN_EMAIL,
        -- Non-Type II columns (pass through; updated in place on change)
        FIRST_NAME,
        LAST_NAME,
        SALUTATION,
        EMAIL,
        PHONE,
        MOBILE_PHONE,
        SOURCE_SYSTEM,
        PLAYER_ID,
        PLAYNOW_ACCOUNT_STATUS,
        PLAYNOW_UUID,
        PLAYNOW_ACCOUNT_ID,
        CIH_UID,
        BC_GOLD_ACCOUNT_ID
    FROM {{ source('raw', 'CUSTOMER_SRC_002') }}

{% endsnapshot %}
