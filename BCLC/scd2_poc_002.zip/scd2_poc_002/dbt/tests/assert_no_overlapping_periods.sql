{# ===================================================================
   tests/assert_no_overlapping_periods.sql

   Generic test: for any natural key, two SCD2 rows must NEVER overlap
   in their [VALID_FROM, VALID_TO) interval. This is the critical
   integrity guarantee for point-in-time lookups.

   Reusable across every history model — pass column names as args.
   Returns rows on failure (non-zero row count = test fails).
   =================================================================== #}

{% test assert_no_overlapping_periods(model,
                                       natural_key_column,
                                       valid_from_column,
                                       valid_to_column) %}

WITH versioned AS (
    SELECT
        {{ natural_key_column }}                          AS nk,
        {{ valid_from_column }}                           AS vf,
        {{ valid_to_column }}                             AS vt,
        LEAD({{ valid_from_column }}) OVER (
            PARTITION BY {{ natural_key_column }}
            ORDER BY {{ valid_from_column }}
        )                                                 AS next_vf
    FROM {{ model }}
)
SELECT *
FROM versioned
WHERE next_vf IS NOT NULL
  AND vt > next_vf

{% endtest %}
