@echo off
setlocal enabledelayedexpansion

REM =====================================================================
REM demo_run.bat
REM SCD2 POC 002 — DIM_CUSTOMERS  (UV + dbt + Snowflake)
REM
REM Prerequisites:
REM   1. uv installed: https://docs.astral.sh/uv/getting-started/installation/
REM   2. Snowflake SQL scripts 01–05 executed in order (see snowflake\ folder)
REM   3. ~/.dbt/profiles.yml configured (copy dbt\profiles.yml.example)
REM
REM Usage:
REM   demo_run.bat              — full demo (T0 + 3 pipeline runs)
REM   demo_run.bat --setup-only — create venv + install deps, then exit
REM =====================================================================

SET ROOT=%~dp0
SET DBT_DIR=%ROOT%dbt
SET VENV_DIR=%DBT_DIR%\.venv
SET PYTHON=%VENV_DIR%\Scripts\python.exe
SET DBT=%VENV_DIR%\Scripts\dbt.exe

echo.
echo =====================================================================
echo  SCD2 POC 002 - DIM_CUSTOMERS Demo
echo =====================================================================
echo.

REM -----------------------------------------------------------------------
REM STEP 1: Check uv is available
REM -----------------------------------------------------------------------
echo [1/7] Checking uv installation...
uv --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: uv not found. Install it from:
    echo   https://docs.astral.sh/uv/getting-started/installation/
    echo   Windows: powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
    exit /b 1
)
FOR /F "tokens=*" %%V IN ('uv --version') DO SET UV_VER=%%V
echo   Found: %UV_VER%

REM -----------------------------------------------------------------------
REM STEP 2: Create virtual environment (skips if already exists)
REM -----------------------------------------------------------------------
echo.
echo [2/7] Creating virtual environment in dbt\.venv ...
IF NOT EXIST "%VENV_DIR%\Scripts\python.exe" (
    uv venv "%VENV_DIR%" --python 3.11
    IF %ERRORLEVEL% NEQ 0 (
        echo ERROR: Failed to create virtual environment.
        exit /b 1
    )
    echo   Virtual environment created.
) ELSE (
    echo   Virtual environment already exists, skipping.
)

REM -----------------------------------------------------------------------
REM STEP 3: Install dbt-snowflake
REM -----------------------------------------------------------------------
echo.
echo [3/7] Installing dbt-snowflake into venv ...
IF NOT EXIST "%DBT%" (
    uv pip install --python "%PYTHON%" dbt-snowflake
    IF %ERRORLEVEL% NEQ 0 (
        echo ERROR: Failed to install dbt-snowflake.
        exit /b 1
    )
    echo   dbt-snowflake installed.
) ELSE (
    FOR /F "tokens=*" %%V IN ('"%DBT%" --version 2^>^&1 ^| findstr /i "dbt"') DO SET DBT_VER=%%V
    echo   dbt already installed: !DBT_VER!
)

REM -----------------------------------------------------------------------
REM STEP 4: Install dbt packages (dbt_utils)
REM -----------------------------------------------------------------------
echo.
echo [4/7] Installing dbt packages (dbt_utils) ...
cd /d "%DBT_DIR%"
"%DBT%" deps
IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: dbt deps failed. Check profiles.yml and network access.
    exit /b 1
)

IF "%~1"=="--setup-only" (
    echo.
    echo Setup complete. Run without --setup-only to execute the full demo.
    exit /b 0
)

REM -----------------------------------------------------------------------
REM Verify profiles.yml is configured
REM -----------------------------------------------------------------------
echo.
echo Verifying Snowflake connection ...
"%DBT%" debug --profiles-dir "%USERPROFILE%\.dbt"
IF %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: dbt debug failed. Please check:
    echo   1. ~/.dbt/profiles.yml exists (copy from dbt\profiles.yml.example)
    echo   2. Snowflake credentials are correct
    echo   3. Snowflake SQL scripts 01_setup_database.sql and
    echo      02_create_raw_tables.sql have been executed
    exit /b 1
)

REM -----------------------------------------------------------------------
REM ROUND T0: Initial load (5 customers)
REM -----------------------------------------------------------------------
echo.
echo =====================================================================
echo  ROUND T0 — Initial Load
echo  Run snowflake\03_load_initial_data.sql in Snowflake first, then
echo  press any key to run the dbt pipeline.
echo =====================================================================
pause

echo.
echo [5/7] Running dbt pipeline - T0 (snapshot + run + test) ...
echo --- dbt snapshot ---
"%DBT%" snapshot
IF %ERRORLEVEL% NEQ 0 ( echo ERROR: dbt snapshot failed && exit /b 1 )

echo --- dbt run ---
"%DBT%" run
IF %ERRORLEVEL% NEQ 0 ( echo ERROR: dbt run failed && exit /b 1 )

echo --- dbt test ---
"%DBT%" test
IF %ERRORLEVEL% NEQ 0 ( echo WARNING: dbt test had failures - check output above )

echo.
echo T0 complete. Expected: 5 rows in DIM_CUSTOMERS_CURRENT (all SCD_CUR_IND=Y)

REM -----------------------------------------------------------------------
REM ROUND T1: Type II + Non-Type II changes
REM -----------------------------------------------------------------------
echo.
echo =====================================================================
echo  ROUND T1 — Changes Round 1
echo  Run snowflake\04_apply_changes_round1.sql in Snowflake first, then
echo  press any key to run the dbt pipeline.
echo =====================================================================
pause

echo.
echo Running dbt pipeline - T1 ...
"%DBT%" snapshot
IF %ERRORLEVEL% NEQ 0 ( echo ERROR: dbt snapshot failed && exit /b 1 )
"%DBT%" run
IF %ERRORLEVEL% NEQ 0 ( echo ERROR: dbt run failed && exit /b 1 )
"%DBT%" test
IF %ERRORLEVEL% NEQ 0 ( echo WARNING: dbt test had failures - check output above )

echo.
echo T1 complete. Expected:
echo   - C001: 2 versions (Vancouver/Gold became Victoria/Platinum)
echo   - C002: 1 version  (FIRST_NAME change NOT tracked = no new version)

REM -----------------------------------------------------------------------
REM ROUND T2: More Type II changes + hard delete + new customer
REM -----------------------------------------------------------------------
echo.
echo =====================================================================
echo  ROUND T2 — Changes Round 2
echo  Run snowflake\05_apply_changes_round2.sql in Snowflake first, then
echo  press any key to run the dbt pipeline.
echo =====================================================================
pause

echo.
echo Running dbt pipeline - T2 ...
"%DBT%" snapshot
IF %ERRORLEVEL% NEQ 0 ( echo ERROR: dbt snapshot failed && exit /b 1 )
"%DBT%" run
IF %ERRORLEVEL% NEQ 0 ( echo ERROR: dbt run failed && exit /b 1 )
"%DBT%" test
IF %ERRORLEVEL% NEQ 0 ( echo WARNING: dbt test had failures - check output above )

echo.
echo T2 complete. Expected:
echo   - C001: 3 versions (added RESTRICTED_FLAG=Y)
echo   - C004: closed row (hard delete), SCD_CUR_IND=N
echo   - C006: new customer, 1 version

REM -----------------------------------------------------------------------
REM Final summary
REM -----------------------------------------------------------------------
echo.
echo [6/7] Generating dbt docs ...
"%DBT%" docs generate
echo   Docs generated. Run: dbt docs serve

echo.
echo [7/7] Demo complete!
echo =====================================================================
echo  Run snowflake\06_validation_queries.sql to verify all SCD2 rules.
echo  Key checks:
echo    - C001 has 3 versions
echo    - C004 SCD_CUR_IND=N (hard delete)
echo    - C002 has 1 version (non-Type-II change not tracked)
echo    - Zero overlapping intervals
echo    - Zero rows with NULL SCD_HASH
echo =====================================================================
echo.

endlocal
