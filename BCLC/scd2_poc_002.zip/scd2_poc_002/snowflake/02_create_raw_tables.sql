-- =====================================================================
-- 02_create_raw_tables.sql
-- Creates the raw source landing table CUSTOMER_SRC_002.
-- This is the full-replace or append landing zone populated by
-- Matillion / any ETL before dbt snapshot runs.
-- =====================================================================

USE ROLE SCD2_POC_002_ROLE;
USE WAREHOUSE SCD2_POC_002_WH;
USE DATABASE SCD2_POC_002;
USE SCHEMA RAW;

CREATE OR REPLACE TABLE CUSTOMER_SRC_002 (

    -- Natural key
    CUSTOMER_BUSINESS_KEY       VARCHAR     NOT NULL,

    -- Change-detection timestamp (drives dbt snapshot timestamp strategy if used)
    SYSTEM_MODIFIED_TIMESTAMP   TIMESTAMP_NTZ,

    -- ----------------------------------------------------------------
    -- SCD2 Type II tracked columns
    -- A change in ANY of these triggers a new SCD2 version.
    -- ----------------------------------------------------------------
    CARD_TYPE                   VARCHAR,
    CARD_TYPE_NBR               VARCHAR,
    CASINO_MEMBER_ID            VARCHAR,
    CASINO_MEMBER_ID_OPT        VARCHAR,
    CASINO_MEMBER_ID_VRF        VARCHAR,
    CITY                        VARCHAR,
    COUNTRY                     VARCHAR,
    CUSTOMER_TIER               VARCHAR,
    CUSTOMER_TIER_CD            VARCHAR,
    MAILING_ADDR_CITY           VARCHAR,
    MAILING_ADDR_COUNTRY        VARCHAR,
    MAILING_ADDR_REGION         VARCHAR,
    MAILING_POSTAL_CODE         VARCHAR,
    MARKETING_CONTACT_OK        VARCHAR,        -- 'Y' / 'N'
    PLAYNOW_JURISDICTION        VARCHAR,
    POSTAL_CODE                 VARCHAR,
    REGION                      VARCHAR,
    RESTRICTED_FLAG             VARCHAR,        -- 'Y' / 'N'
    SF_CAN_EMAIL                VARCHAR,        -- 'Y' / 'N'

    -- ----------------------------------------------------------------
    -- Non-Type II columns (changes update in place, no new version)
    -- ----------------------------------------------------------------
    FIRST_NAME                  VARCHAR,
    LAST_NAME                   VARCHAR,
    SALUTATION                  VARCHAR,
    EMAIL                       VARCHAR,
    PHONE                       VARCHAR,
    MOBILE_PHONE                VARCHAR,
    SOURCE_SYSTEM               VARCHAR,
    PLAYER_ID                   VARCHAR,
    PLAYNOW_ACCOUNT_STATUS      VARCHAR,
    PLAYNOW_UUID                VARCHAR,
    PLAYNOW_ACCOUNT_ID          VARCHAR,
    CIH_UID                     VARCHAR,
    BC_GOLD_ACCOUNT_ID          VARCHAR,

    CONSTRAINT PK_CUSTOMER_SRC_002 PRIMARY KEY (CUSTOMER_BUSINESS_KEY)
);

SELECT 'CUSTOMER_SRC_002 created in RAW schema.' AS STATUS;
