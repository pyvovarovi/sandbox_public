-- =====================================================================
-- 99_teardown.sql
-- Destroys all SCD2_POC_002 objects. IRREVERSIBLE.
-- Run as ACCOUNTADMIN or a role with DROP DATABASE privilege.
-- =====================================================================

USE ROLE ACCOUNTADMIN;

DROP DATABASE  IF EXISTS SCD2_POC_002    CASCADE;
DROP WAREHOUSE IF EXISTS SCD2_POC_002_WH;
DROP ROLE      IF EXISTS SCD2_POC_002_ROLE;

SELECT 'Teardown complete. All SCD2_POC_002 objects dropped.' AS STATUS;
