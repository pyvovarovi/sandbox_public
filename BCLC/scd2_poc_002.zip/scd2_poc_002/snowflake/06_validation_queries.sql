-- =====================================================================
-- 06_validation_queries.sql
-- SCD2 integrity checks after all three pipeline rounds.
-- All SELECT queries should return ZERO rows on the "failure" checks.
-- =====================================================================

USE ROLE SCD2_POC_002_ROLE;
USE WAREHOUSE SCD2_POC_002_WH;
USE DATABASE SCD2_POC_002;

-- =====================================================================
-- 1. Version counts by customer (after T2 + 3 pipeline runs)
-- =====================================================================
SELECT
    CUSTOMER_BUSINESS_KEY,
    COUNT(*)                          AS VERSION_COUNT,
    MIN(SCD_EFF_DTM)                  AS EARLIEST_EFF,
    MAX(SCD_EXPN_DTM)                 AS LATEST_EXPN,
    SUM(CASE WHEN SCD_CUR_IND = 'Y' THEN 1 ELSE 0 END) AS CURRENT_ROWS
FROM MARTS.DIM_CUSTOMERS_HISTORY
GROUP BY CUSTOMER_BUSINESS_KEY
ORDER BY CUSTOMER_BUSINESS_KEY;
-- Expected: C001=3, C002=1, C003=1, C004=1(closed), C005=1, C006=1

-- =====================================================================
-- 2. Exactly one current row per active customer
-- =====================================================================
SELECT CUSTOMER_BUSINESS_KEY, COUNT(*) AS CNT
FROM MARTS.DIM_CUSTOMERS_CURRENT
GROUP BY CUSTOMER_BUSINESS_KEY
HAVING COUNT(*) <> 1;
-- Expected: 0 rows (each active customer has exactly 1 row)

-- =====================================================================
-- 3. C001 full version history — should show 3 versions
-- =====================================================================
SELECT
    CUSTOMER_BUSINESS_KEY,
    SCD_EFF_DTM,
    SCD_EXPN_DTM,
    SCD_CUR_IND,
    CITY,
    CUSTOMER_TIER,
    RESTRICTED_FLAG
FROM MARTS.DIM_CUSTOMERS_HISTORY
WHERE CUSTOMER_BUSINESS_KEY = 'C001'
ORDER BY SCD_EFF_DTM;

-- =====================================================================
-- 4. C002 — only 1 version despite FIRST_NAME changing in T1
-- =====================================================================
SELECT
    CUSTOMER_BUSINESS_KEY,
    COUNT(*) AS VERSION_COUNT,
    MAX(FIRST_NAME) AS CURRENT_FIRST_NAME
FROM MARTS.DIM_CUSTOMERS_HISTORY
WHERE CUSTOMER_BUSINESS_KEY = 'C002'
GROUP BY CUSTOMER_BUSINESS_KEY;
-- Expected: 1 version, FIRST_NAME = 'Robert' (updated in place)

-- =====================================================================
-- 5. C004 hard-delete check — row closed, not in current dim
-- =====================================================================
SELECT
    CUSTOMER_BUSINESS_KEY,
    SCD_CUR_IND,
    SCD_EXPN_DTM
FROM MARTS.DIM_CUSTOMERS_HISTORY
WHERE CUSTOMER_BUSINESS_KEY = 'C004';
-- Expected: 1 row, SCD_CUR_IND='N', SCD_EXPN_DTM < '9999-12-31'

SELECT COUNT(*) AS SHOULD_BE_ZERO
FROM MARTS.DIM_CUSTOMERS_CURRENT
WHERE CUSTOMER_BUSINESS_KEY = 'C004';
-- Expected: 0

-- =====================================================================
-- 6. No overlapping SCD2 intervals per customer (half-open [eff, expn))
-- =====================================================================
WITH versioned AS (
    SELECT
        CUSTOMER_BUSINESS_KEY,
        SCD_EFF_DTM,
        SCD_EXPN_DTM,
        LEAD(SCD_EFF_DTM) OVER (
            PARTITION BY CUSTOMER_BUSINESS_KEY
            ORDER BY SCD_EFF_DTM
        ) AS NEXT_EFF
    FROM MARTS.DIM_CUSTOMERS_HISTORY
)
SELECT *
FROM versioned
WHERE NEXT_EFF IS NOT NULL
  AND SCD_EXPN_DTM > NEXT_EFF;
-- Expected: 0 rows (no overlaps)

-- =====================================================================
-- 7. Contiguity check — no time gaps between consecutive versions
-- =====================================================================
WITH versioned AS (
    SELECT
        CUSTOMER_BUSINESS_KEY,
        SCD_EFF_DTM,
        SCD_EXPN_DTM,
        LEAD(SCD_EFF_DTM) OVER (
            PARTITION BY CUSTOMER_BUSINESS_KEY
            ORDER BY SCD_EFF_DTM
        ) AS NEXT_EFF
    FROM MARTS.DIM_CUSTOMERS_HISTORY
)
SELECT *
FROM versioned
WHERE NEXT_EFF IS NOT NULL
  AND SCD_EXPN_DTM <> NEXT_EFF;
-- Expected: 0 rows (no gaps between consecutive versions)

-- =====================================================================
-- 8. SCD_CUR_IND consistency — 'Y' iff SCD_EXPN_DTM = '9999-12-31'
-- =====================================================================
SELECT *
FROM MARTS.DIM_CUSTOMERS_HISTORY
WHERE (SCD_CUR_IND = 'Y' AND SCD_EXPN_DTM <> '9999-12-31 00:00:00'::TIMESTAMP_NTZ)
   OR (SCD_CUR_IND = 'N' AND SCD_EXPN_DTM  = '9999-12-31 00:00:00'::TIMESTAMP_NTZ);
-- Expected: 0 rows

-- =====================================================================
-- 9. SCD2 hash not null on all history rows
-- =====================================================================
SELECT COUNT(*) AS NULL_HASH_COUNT
FROM MARTS.DIM_CUSTOMERS_HISTORY
WHERE SCD_HASH IS NULL;
-- Expected: 0

-- =====================================================================
-- 10. Point-in-time lookup for C001 as of 2026-01-20 (between T1 and T2)
--     Should return Victoria/Platinum version
-- =====================================================================
SELECT
    CUSTOMER_BUSINESS_KEY,
    CITY,
    CUSTOMER_TIER,
    RESTRICTED_FLAG,
    SCD_EFF_DTM,
    SCD_EXPN_DTM,
    SCD_CUR_IND
FROM MARTS.DIM_CUSTOMERS_HISTORY
WHERE CUSTOMER_BUSINESS_KEY = 'C001'
  AND '2026-01-20 00:00:00'::TIMESTAMP_NTZ >= SCD_EFF_DTM
  AND '2026-01-20 00:00:00'::TIMESTAMP_NTZ  < SCD_EXPN_DTM;
-- Expected: 1 row, CITY='Victoria', CUSTOMER_TIER='Platinum', RESTRICTED_FLAG='N'
