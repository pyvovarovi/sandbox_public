-- =====================================================================
-- 04_apply_changes_round1.sql
-- T1 = 2026-01-15 12:00:00 UTC
--
-- USE CASES:
--   A. C001: Type II change  → CITY and CUSTOMER_TIER change.
--            dbt snapshot detects change and creates a NEW SCD2 version.
--            C001 will have 2 rows in history after next pipeline run.
--
--   B. C002: Non-Type II change → only FIRST_NAME changes.
--            FIRST_NAME is NOT in the snapshot check_cols list,
--            so NO new SCD2 version is created.
--            C002 remains 1 row in history (value updated in place).
--
-- C003, C004, C005: no changes — unchanged.
-- =====================================================================

USE ROLE SCD2_POC_002_ROLE;
USE WAREHOUSE SCD2_POC_002_WH;
USE DATABASE SCD2_POC_002;
USE SCHEMA RAW;

-- -----------------------------------------------------------------------
-- USE CASE A: C001 Type II change
--   CITY:          'Vancouver'  → 'Victoria'
--   CUSTOMER_TIER: 'Gold'       → 'Platinum'
--   CUSTOMER_TIER_CD: 'GLD'     → 'PLT'
--   Also update MAILING_ADDR_CITY to match new city.
--   Bump SYSTEM_MODIFIED_TIMESTAMP to T1.
-- -----------------------------------------------------------------------
UPDATE CUSTOMER_SRC_002
SET
    CITY                    = 'Victoria',
    CUSTOMER_TIER           = 'Platinum',
    CUSTOMER_TIER_CD        = 'PLT',
    MAILING_ADDR_CITY       = 'Victoria',
    MAILING_ADDR_REGION     = 'BC',
    POSTAL_CODE             = 'V8W 1N3',
    MAILING_POSTAL_CODE     = 'V8W 1N3',
    SYSTEM_MODIFIED_TIMESTAMP = '2026-01-15 12:00:00'::TIMESTAMP_NTZ
WHERE CUSTOMER_BUSINESS_KEY = 'C001';

-- -----------------------------------------------------------------------
-- USE CASE B: C002 Non-Type II change
--   FIRST_NAME: 'Bob' → 'Robert'  (NOT a tracked Type II column)
--   dbt check strategy ignores this — no new version.
--   SYSTEM_MODIFIED_TIMESTAMP bumped (but check_cols hash unchanged).
-- -----------------------------------------------------------------------
UPDATE CUSTOMER_SRC_002
SET
    FIRST_NAME              = 'Robert',
    SYSTEM_MODIFIED_TIMESTAMP = '2026-01-15 12:00:00'::TIMESTAMP_NTZ
WHERE CUSTOMER_BUSINESS_KEY = 'C002';

SELECT
    CUSTOMER_BUSINESS_KEY,
    CITY,
    CUSTOMER_TIER,
    FIRST_NAME,
    SYSTEM_MODIFIED_TIMESTAMP
FROM CUSTOMER_SRC_002
ORDER BY CUSTOMER_BUSINESS_KEY;

-- =====================================================================
-- After running this script, execute the dbt pipeline:
--   dbt snapshot && dbt run && dbt test
-- Expected results:
--   dim_customers_current:  5 rows (C001 shows Victoria/Platinum)
--   dim_customers_history:  C001 has 2 versions, C002 still has 1 version
-- =====================================================================
