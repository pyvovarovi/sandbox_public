-- =====================================================================
-- 05_apply_changes_round2.sql
-- T2 = 2026-02-01 09:00:00 UTC
--
-- USE CASES:
--   C. C001: Second Type II change → RESTRICTED_FLAG: 'N' → 'Y'
--            C001 will have 3 rows in history after next pipeline run.
--
--   D. C004: Hard delete → row removed from source table.
--            dbt invalidate_hard_deletes=True closes the open version
--            (sets dbt_valid_to to snapshot run time).
--            C004 will have SCD_CUR_IND='N' and SCD_EXPN_DTM set.
--
--   E. C006: New customer → fresh INSERT.
--            C006 will have 1 row in history with SCD_CUR_IND='Y'.
--
-- C002, C003, C005: no changes.
-- =====================================================================

USE ROLE SCD2_POC_002_ROLE;
USE WAREHOUSE SCD2_POC_002_WH;
USE DATABASE SCD2_POC_002;
USE SCHEMA RAW;

-- -----------------------------------------------------------------------
-- USE CASE C: C001 Second Type II change — RESTRICTED_FLAG flip
-- -----------------------------------------------------------------------
UPDATE CUSTOMER_SRC_002
SET
    RESTRICTED_FLAG           = 'Y',
    SYSTEM_MODIFIED_TIMESTAMP = '2026-02-01 09:00:00'::TIMESTAMP_NTZ
WHERE CUSTOMER_BUSINESS_KEY = 'C001';

-- -----------------------------------------------------------------------
-- USE CASE D: C004 Hard delete — remove from source entirely
-- -----------------------------------------------------------------------
DELETE FROM CUSTOMER_SRC_002
WHERE CUSTOMER_BUSINESS_KEY = 'C004';

-- -----------------------------------------------------------------------
-- USE CASE E: C006 New customer insert
-- -----------------------------------------------------------------------
INSERT INTO CUSTOMER_SRC_002 VALUES (
    'C006',
    '2026-02-01 09:00:00'::TIMESTAMP_NTZ,
    'STANDARD',  '006',
    NULL,  NULL,  NULL,
    'Kelowna',   'Canada',
    'Bronze',    'BRZ',
    'Kelowna',   'Canada',  'BC',  'V1Y 6G9',
    'Y',
    'BC',  'V1Y 6G9',  'BC',
    'N',  'Y',
    'Frank',  'Lee',  'Mr.',
    'frank.lee@email.com',  '250-555-0106',  NULL,
    'CRM',  'PL-10006',  'ACTIVE',  'uuid-0006',  'PNA-006',  'CIH-006',  NULL
);

SELECT
    CUSTOMER_BUSINESS_KEY,
    RESTRICTED_FLAG,
    SYSTEM_MODIFIED_TIMESTAMP
FROM CUSTOMER_SRC_002
ORDER BY CUSTOMER_BUSINESS_KEY;

SELECT COUNT(*) AS ROW_COUNT, 'T2 - 5 customers remaining (C004 deleted, C006 added)' AS NOTE
FROM CUSTOMER_SRC_002;

-- =====================================================================
-- After running this script, execute the dbt pipeline:
--   dbt snapshot && dbt run && dbt test
-- Expected results:
--   dim_customers_current:  5 rows (C001–C003, C005, C006); C004 absent
--   dim_customers_history:
--     C001 → 3 versions (Vancouver/Gold, Victoria/Platinum, +RESTRICTED_FLAG=Y)
--     C002 → 1 version  (name change in T1 NOT tracked)
--     C003 → 1 version
--     C004 → 1 version, SCD_CUR_IND='N', SCD_EXPN_DTM set (hard delete)
--     C005 → 1 version
--     C006 → 1 version  (new in T2)
-- =====================================================================
