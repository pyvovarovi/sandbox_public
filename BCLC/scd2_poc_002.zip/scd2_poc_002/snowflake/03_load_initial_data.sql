-- =====================================================================
-- 03_load_initial_data.sql
-- T0 = 2026-01-01 00:00:00 UTC  (baseline / initial load)
--
-- USE CASE: Initial load — 5 customers inserted.
-- After running dbt snapshot: 5 rows in SNAPSHOTS, all SCD_CUR_IND='Y'.
-- =====================================================================

USE ROLE SCD2_POC_002_ROLE;
USE WAREHOUSE SCD2_POC_002_WH;
USE DATABASE SCD2_POC_002;
USE SCHEMA RAW;

-- Clear any prior data (idempotent rerun)
TRUNCATE TABLE CUSTOMER_SRC_002;

-- -----------------------------------------------------------------------
-- C001: Gold-tier player in Vancouver, PlayNow active
-- -----------------------------------------------------------------------
INSERT INTO CUSTOMER_SRC_002 VALUES (
    'C001',                                         -- CUSTOMER_BUSINESS_KEY
    '2026-01-01 00:00:00'::TIMESTAMP_NTZ,           -- SYSTEM_MODIFIED_TIMESTAMP
    -- Type II columns
    'STANDARD',    '001',                           -- CARD_TYPE, CARD_TYPE_NBR
    'CM-10001',    'Y',  'Y',                       -- CASINO_MEMBER_ID, OPT, VRF
    'Vancouver',   'Canada',                        -- CITY, COUNTRY
    'Gold',        'GLD',                           -- CUSTOMER_TIER, CUSTOMER_TIER_CD
    'Vancouver',   'Canada',   'BC',  'V6B 1A1',   -- MAILING_ADDR_*
    'Y',                                            -- MARKETING_CONTACT_OK
    'BC',          'V6B 1A1',  'BC',               -- PLAYNOW_JURISDICTION, POSTAL_CODE, REGION
    'N',           'Y',                             -- RESTRICTED_FLAG, SF_CAN_EMAIL
    -- Non-Type II columns
    'Alice',  'Smith',  'Ms.',
    'alice.smith@email.com',  '604-555-0101',  '604-555-0201',
    'CRM',  'PL-10001',  'ACTIVE',  'uuid-0001',  'PNA-001',  'CIH-001',  'BCG-001'
);

-- -----------------------------------------------------------------------
-- C002: Silver-tier player in Toronto
-- -----------------------------------------------------------------------
INSERT INTO CUSTOMER_SRC_002 VALUES (
    'C002',
    '2026-01-01 00:00:00'::TIMESTAMP_NTZ,
    'PREMIUM',  '002',
    'CM-10002',  'Y',  'N',
    'Toronto',   'Canada',
    'Silver',    'SLV',
    'Toronto',   'Canada',  'ON',  'M5V 2K4',
    'Y',
    'ON',  'M5V 2K4',  'ON',
    'N',  'Y',
    'Bob',  'Jones',  'Mr.',
    'bob.jones@email.com',  '416-555-0102',  '416-555-0202',
    'CRM',  'PL-10002',  'ACTIVE',  'uuid-0002',  'PNA-002',  'CIH-002',  'BCG-002'
);

-- -----------------------------------------------------------------------
-- C003: Bronze-tier player in Calgary, no casino membership
-- -----------------------------------------------------------------------
INSERT INTO CUSTOMER_SRC_002 VALUES (
    'C003',
    '2026-01-01 00:00:00'::TIMESTAMP_NTZ,
    'STANDARD',  '003',
    NULL,  NULL,  NULL,
    'Calgary',  'Canada',
    'Bronze',   'BRZ',
    'Calgary',  'Canada',  'AB',  'T2P 1J9',
    'N',
    'AB',  'T2P 1J9',  'AB',
    'N',  'N',
    'Carol',  'White',  'Mrs.',
    'carol.white@email.com',  '403-555-0103',  NULL,
    'CRM',  'PL-10003',  'ACTIVE',  'uuid-0003',  'PNA-003',  'CIH-003',  NULL
);

-- -----------------------------------------------------------------------
-- C004: Gold-tier player in Montreal — will be hard-deleted in T2
-- -----------------------------------------------------------------------
INSERT INTO CUSTOMER_SRC_002 VALUES (
    'C004',
    '2026-01-01 00:00:00'::TIMESTAMP_NTZ,
    'STANDARD',  '004',
    'CM-10004',  'Y',  'Y',
    'Montreal',  'Canada',
    'Gold',      'GLD',
    'Montreal',  'Canada',  'QC',  'H2Y 1C6',
    'Y',
    'QC',  'H2Y 1C6',  'QC',
    'N',  'Y',
    'David',  'Brown',  'Mr.',
    'david.brown@email.com',  '514-555-0104',  NULL,
    'CRM',  'PL-10004',  'ACTIVE',  'uuid-0004',  'PNA-004',  'CIH-004',  'BCG-004'
);

-- -----------------------------------------------------------------------
-- C005: Platinum-tier player in Edmonton
-- -----------------------------------------------------------------------
INSERT INTO CUSTOMER_SRC_002 VALUES (
    'C005',
    '2026-01-01 00:00:00'::TIMESTAMP_NTZ,
    'PREMIUM',  '005',
    'CM-10005',  'Y',  'Y',
    'Edmonton',  'Canada',
    'Platinum',  'PLT',
    'Edmonton',  'Canada',  'AB',  'T5J 1N4',
    'Y',
    'AB',  'T5J 1N4',  'AB',
    'N',  'Y',
    'Eve',  'Wilson',  'Dr.',
    'eve.wilson@email.com',  '780-555-0105',  '780-555-0205',
    'CRM',  'PL-10005',  'ACTIVE',  'uuid-0005',  'PNA-005',  'CIH-005',  'BCG-005'
);

SELECT COUNT(*) AS ROW_COUNT, 'T0 - Initial load: 5 customers' AS NOTE
FROM CUSTOMER_SRC_002;

-- =====================================================================
-- After running this script, execute the dbt pipeline:
--   dbt snapshot && dbt run && dbt test
-- Expected result: 5 rows in dim_customers_current, all SCD_CUR_IND='Y'
-- =====================================================================
