# SCD2 POC 002 — DIM_CUSTOMERS with dbt + Snowflake

## Table of Contents

1. [What This POC Does](#1-what-this-poc-does)
2. [What Is SCD Type 2?](#2-what-is-scd-type-2)
3. [What Is dbt?](#3-what-is-dbt)
4. [SCD2 Requirements (Column Conventions)](#4-scd2-requirements-column-conventions)
5. [Data Architecture](#5-data-architecture)
6. [Prerequisites](#6-prerequisites)
7. [Folder and File Reference](#7-folder-and-file-reference)
8. [Step-by-Step Setup Guide](#8-step-by-step-setup-guide)
9. [Test Scenarios Explained](#9-test-scenarios-explained)
10. [How to Validate Results](#10-how-to-validate-results)
11. [Troubleshooting](#11-troubleshooting)
12. [Glossary](#12-glossary)

---

## 1. What This POC Does

This is a **Proof of Concept (POC)** that shows how to implement **Slowly Changing Dimension Type 2 (SCD2)** for a customer table using:

- **Snowflake** — cloud data warehouse where data is stored
- **dbt** — tool that transforms raw data into clean, versioned dimension tables
- **UV** — fast Python package manager used to install dbt

The POC is based on a real-world `DIM_CUSTOMERS` table from a gaming/CRM system. It demonstrates how to track the full history of customer attribute changes — so you can always answer questions like:

> *"What loyalty tier was customer C001 on January 20th, 2026?"*

**What you get after running this POC:**

| Output Table | Description |
|---|---|
| `MARTS.DIM_CUSTOMERS_CURRENT` | One row per active customer — their **current** attributes |
| `MARTS.DIM_CUSTOMERS_HISTORY` | All **historical versions** of every customer since the initial load |

---

## 2. What Is SCD Type 2?

**Slowly Changing Dimension (SCD) Type 2** is a technique for keeping full history in a data warehouse when data changes over time.

### The Problem

Imagine a customer moves from Vancouver to Victoria and gets upgraded from Gold to Platinum tier. If you simply overwrite the old values, you lose the history:

```
BEFORE:  C001 | Vancouver | Gold
AFTER:   C001 | Victoria  | Platinum   ← old record is gone
```

This is a problem because historical sales reports would incorrectly show the customer was always Platinum in Victoria — even for orders placed when they were Gold in Vancouver.

### The SCD2 Solution

Instead of overwriting, you **close the old row** and **add a new row**:

```
ROW 1 (closed):  C001 | Vancouver | Gold     | EFF: 2026-01-01 | EXPN: 2026-01-15 | CUR: N
ROW 2 (current): C001 | Victoria  | Platinum | EFF: 2026-01-15 | EXPN: 9999-12-31 | CUR: Y
```

Now you can look up *any point in time* and get the correct customer attributes for that moment.

### Key Rules

1. A current row always has `SCD_EXPN_DTM = '9999-12-31'` and `SCD_CUR_IND = 'Y'`
2. A closed (historical) row has a real expiry date and `SCD_CUR_IND = 'N'`
3. Intervals are **half-open**: `[SCD_EFF_DTM, SCD_EXPN_DTM)` — the new row starts exactly when the old row ends (no gaps, no overlaps)
4. **Not every column change creates a new version** — only the 19 designated **Type II columns** trigger a new version. Changes to other columns (like `FIRST_NAME`) are updated in place without creating history.

---

## 3. What Is dbt?

**dbt (data build tool)** is an open-source command-line tool that lets data engineers write SQL transformations and run them against a data warehouse.

Think of it as a **SQL pipeline runner** that:

- Runs your SQL files in the correct order
- Manages schema creation automatically
- Tests the output data quality
- Generates documentation

### Key dbt Concepts Used in This POC

| Concept | What it does |
|---|---|
| **Snapshot** | Tracks changes in a source table over time; creates SCD2 history automatically |
| **Model** | A SQL SELECT statement saved as a `.sql` file; dbt turns it into a table or view |
| **Source** | Defines the raw input tables that dbt reads from |
| **Test** | A data quality check that dbt runs after building models |
| **Profile** | Your Snowflake connection settings (stored outside the project for security) |
| **Package** | A reusable dbt library; this POC uses `dbt_utils` for generating surrogate keys |

### How dbt Snapshots Work (Simplified)

```
SOURCE TABLE                    SNAPSHOT TABLE (auto-managed by dbt)
CUSTOMER_SRC_002  ──────────►  SNAPSHOTS.SNAP_DIM_CUSTOMERS
                                  (contains dbt_valid_from, dbt_valid_to)
                                              │
                                              ▼
                               MARTS.DIM_CUSTOMERS_HISTORY
                               MARTS.DIM_CUSTOMERS_CURRENT
```

Each time you run `dbt snapshot`, dbt:
1. Reads the current source data
2. Compares it to the last snapshot using the **check columns** (the 19 Type II cols)
3. If a tracked column changed → closes the old row, inserts a new row
4. If nothing changed → no new row created
5. If a row disappeared from source → closes the open row (hard delete handling)

---

## 4. SCD2 Requirements (Column Conventions)

This POC follows the standard SCD2 column conventions defined in `../prompt/SCD2_Requirements.md`.

### Standard SCD2 Columns

| Column | Type | Description |
|---|---|---|
| `SCD_EFF_DTM` | `TIMESTAMP_NTZ` | Effectivity start — when this version became active |
| `SCD_EXPN_DTM` | `TIMESTAMP_NTZ` | Effectivity end — `9999-12-31` for the current version |
| `SCD_CUR_IND` | `CHAR(1)` | `'Y'` = current row, `'N'` = historical row |
| `CUSTOMER_BUSINESS_KEY` | `VARCHAR` | Natural key from the source system |

### Companion Columns (also generated)

| Column | Description |
|---|---|
| `CUSTOMER_KEY` | Surrogate PK — stable hash of `CUSTOMER_BUSINESS_KEY`, same value across all versions |
| `CUSTOMER_VERSION_SK` | Version-level surrogate key — unique per SCD2 version (history model only) |
| `SCD_HASH` | SHA2-256 hash of all 19 Type II columns — allows single-column change detection |
| `ELT_CREATE_DTM` | Timestamp when this row was first created |
| `ELT_UPDATE_DTM` | Timestamp when this row was last updated |
| `ELT_JOB_NAME` | Name of the dbt job that created this row |

### The 19 SCD2 Type II Columns

A change in **any** of these columns creates a new version:

| Column | Business Meaning |
|---|---|
| `CARD_TYPE` | Loyalty card type (e.g. STANDARD, PREMIUM) |
| `CARD_TYPE_NBR` | Loyalty card number |
| `CASINO_MEMBER_ID` | Casino membership identifier |
| `CASINO_MEMBER_ID_OPT` | Casino membership opted-in flag (Y/N) |
| `CASINO_MEMBER_ID_VRF` | Casino membership verified flag (Y/N) |
| `CITY` | City of residence |
| `COUNTRY` | Country of residence |
| `CUSTOMER_TIER` | Loyalty tier (Bronze / Silver / Gold / Platinum) |
| `CUSTOMER_TIER_CD` | Loyalty tier code (BRZ / SLV / GLD / PLT) |
| `MAILING_ADDR_CITY` | Mailing address city |
| `MAILING_ADDR_COUNTRY` | Mailing address country |
| `MAILING_ADDR_REGION` | Mailing address region/province |
| `MAILING_POSTAL_CODE` | Mailing address postal code |
| `MARKETING_CONTACT_OK` | Marketing contact permission (Y/N) |
| `PLAYNOW_JURISDICTION` | PlayNow jurisdiction code |
| `POSTAL_CODE` | Residential postal code |
| `REGION` | Residential region/province |
| `RESTRICTED_FLAG` | Customer restriction flag (Y/N) |
| `SF_CAN_EMAIL` | Salesforce email consent flag (Y/N) |

### Non-Type II Columns (no new version on change)

Changes to these columns are recorded in the current row **without** creating a new version:

`FIRST_NAME`, `LAST_NAME`, `SALUTATION`, `EMAIL`, `PHONE`, `MOBILE_PHONE`, `SOURCE_SYSTEM`, `PLAYER_ID`, `PLAYNOW_ACCOUNT_STATUS`, `PLAYNOW_UUID`, `PLAYNOW_ACCOUNT_ID`, `CIH_UID`, `BC_GOLD_ACCOUNT_ID`

---

## 5. Data Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  SNOWFLAKE  DATABASE: SCD2_POC_002                              │
│                                                                 │
│  RAW schema                                                     │
│  └── CUSTOMER_SRC_002          ← raw landing table (ETL input) │
│                                                                 │
│  SNAPSHOTS schema                                               │
│  └── SNAP_DIM_CUSTOMERS        ← dbt-managed SCD2 history      │
│                                                                 │
│  STAGING schema                                                 │
│  └── STG_DIM_CUSTOMERS (view)  ← cleaned/normalised data       │
│                                                                 │
│  MARTS schema                                                   │
│  ├── DIM_CUSTOMERS_CURRENT     ← 1 row per active customer     │
│  └── DIM_CUSTOMERS_HISTORY     ← all versions for point-in-time│
└─────────────────────────────────────────────────────────────────┘
```

### Data Flow Step by Step

```
1. ETL / Matillion loads data into:
   RAW.CUSTOMER_SRC_002

2. dbt snapshot reads RAW table, detects changes, writes to:
   SNAPSHOTS.SNAP_DIM_CUSTOMERS
   (adds dbt_valid_from, dbt_valid_to, dbt_scd_id columns)

3. dbt run reads snapshot, applies transformations, writes to:
   STAGING.STG_DIM_CUSTOMERS      (cleaning/normalisation)
   MARTS.DIM_CUSTOMERS_CURRENT    (current state)
   MARTS.DIM_CUSTOMERS_HISTORY    (full audit trail)

4. dbt test validates data quality on all output models
```

---

## 6. Prerequisites

### Software You Need

| Software | Purpose | Install |
|---|---|---|
| **Snowflake account** | The data warehouse | Enterprise trial or existing account |
| **uv** | Python package manager (installs dbt) | See below |
| **Git** | Version control | Already installed if you have this repo |

### Install uv (Windows)

Open PowerShell and run:

```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

Restart your terminal, then verify:

```cmd
uv --version
```

### Snowflake Access

You need a Snowflake account with:
- An admin user capable of running `CREATE DATABASE`, `CREATE ROLE`, `CREATE WAREHOUSE`
- Network access to Snowflake from your machine

### Configure dbt Profile

dbt stores your Snowflake credentials in `~/.dbt/profiles.yml` (your Windows home folder, e.g. `C:\Users\YourName\.dbt\profiles.yml`).

1. Copy the template:
   ```
   scd2_poc_002\dbt\profiles.yml.example  →  C:\Users\YourName\.dbt\profiles.yml
   ```
2. Fill in your Snowflake account, username, and password.

The file should look like:

```yaml
scd2_poc_002:
  target: dev
  outputs:
    dev:
      type: snowflake
      account: abc123.us-east-1    # your Snowflake account identifier
      user: my_user
      password: my_password
      role: SCD2_POC_002_ROLE
      warehouse: SCD2_POC_002_WH
      database: SCD2_POC_002
      schema: MARTS
      threads: 4
```

---

## 7. Folder and File Reference

```
scd2_poc_002/
│
├── README.md                          ← You are here
├── demo_run.bat                       ← Automated demo script (UV + dbt)
│
├── snowflake/                         ← Snowflake SQL scripts (run manually)
│   ├── 01_setup_database.sql
│   ├── 02_create_raw_tables.sql
│   ├── 03_load_initial_data.sql
│   ├── 04_apply_changes_round1.sql
│   ├── 05_apply_changes_round2.sql
│   ├── 06_validation_queries.sql
│   └── 99_teardown.sql
│
└── dbt/                               ← The dbt project
    ├── dbt_project.yml                ← Project configuration
    ├── profiles.yml.example           ← Connection template
    ├── packages.yml                   ← External dbt libraries
    │
    ├── snapshots/
    │   └── snap_dim_customers.sql     ← SCD2 engine (most important file)
    │
    ├── models/
    │   ├── sources.yml                ← Declares the raw source table
    │   ├── staging/
    │   │   ├── stg_dim_customers.sql  ← Cleaning/normalisation
    │   │   └── schema.yml             ← Tests for staging layer
    │   └── marts/
    │       ├── dim_customers_current.sql   ← Current-state table
    │       ├── dim_customers_history.sql   ← Full history table
    │       └── schema.yml                  ← Tests for mart layer
    │
    └── tests/
        └── assert_no_overlapping_periods.sql  ← Custom SCD2 integrity test
```

---

### Snowflake Scripts — Detailed

#### `snowflake/01_setup_database.sql`
**What it does:** Creates all the Snowflake infrastructure needed for the POC.

Creates:
- **Warehouse** `SCD2_POC_002_WH` — the compute engine that runs queries (X-Small, auto-suspend after 60 seconds)
- **Database** `SCD2_POC_002` — the container for all tables and views
- **Schemas** `RAW`, `SNAPSHOTS`, `MARTS`, `STAGING` — logical namespaces separating data layers
- **Role** `SCD2_POC_002_ROLE` — a security role with only the permissions needed for this POC

**Run as:** `ACCOUNTADMIN` (or equivalent admin role)

---

#### `snowflake/02_create_raw_tables.sql`
**What it does:** Creates the raw landing table `CUSTOMER_SRC_002` in the `RAW` schema.

This table is the **input** to the pipeline. In a real system, your ETL tool (Matillion, Fivetran, etc.) would populate this table from the source CRM. In this POC, you populate it manually using the test data scripts.

The table has three groups of columns:
- **Natural key**: `CUSTOMER_BUSINESS_KEY`
- **19 SCD2 Type II columns**: changes here create new history versions
- **Non-Type II columns**: changes here update the current row only

---

#### `snowflake/03_load_initial_data.sql`
**What it does:** Inserts the baseline test data (**T0 = 2026-01-01**) — 5 customers.

| Customer | City | Tier | Notes |
|---|---|---|---|
| C001 | Vancouver | Gold | Will change tier and city in T1 |
| C002 | Toronto | Silver | Will have non-tracked name change in T1 |
| C003 | Calgary | Bronze | No changes throughout |
| C004 | Montreal | Gold | Will be hard-deleted in T2 |
| C005 | Edmonton | Platinum | No changes throughout |

After running `dbt snapshot && dbt run`, you should see 5 rows in `DIM_CUSTOMERS_CURRENT`, all with `SCD_CUR_IND = 'Y'`.

---

#### `snowflake/04_apply_changes_round1.sql`
**What it does:** Applies changes at **T1 = 2026-01-15**. Demonstrates two contrasting use cases.

**Use Case A — C001 Type II change (triggers new version):**
- `CITY`: `'Vancouver'` → `'Victoria'`
- `CUSTOMER_TIER`: `'Gold'` → `'Platinum'`
- Result: C001 gets a second version. Old row closes with `SCD_EXPN_DTM = 2026-01-15`, new row opens.

**Use Case B — C002 Non-Type II change (no new version):**
- `FIRST_NAME`: `'Bob'` → `'Robert'`
- `FIRST_NAME` is NOT in the 19 tracked columns, so dbt ignores this change.
- Result: C002 remains 1 row. The name is simply updated in place.

---

#### `snowflake/05_apply_changes_round2.sql`
**What it does:** Applies changes at **T2 = 2026-02-01**. Three more use cases.

**Use Case C — C001 second Type II change:**
- `RESTRICTED_FLAG`: `'N'` → `'Y'`
- Result: C001 gets a third version.

**Use Case D — C004 hard delete:**
- The entire C004 row is deleted from `CUSTOMER_SRC_002`.
- Because the snapshot uses `invalidate_hard_deletes=True`, dbt detects the missing row and closes C004's open version.
- Result: C004 has `SCD_CUR_IND = 'N'` and `SCD_EXPN_DTM` set to the snapshot run time. C004 disappears from `DIM_CUSTOMERS_CURRENT`.

**Use Case E — C006 new customer:**
- A new customer `C006` (Frank Lee, Kelowna) is inserted.
- Result: C006 appears in both `DIM_CUSTOMERS_CURRENT` and `DIM_CUSTOMERS_HISTORY`.

---

#### `snowflake/06_validation_queries.sql`
**What it does:** 10 SQL queries that verify the SCD2 data is correct after all 3 rounds.

All "failure" queries should return **zero rows**. Key checks:
1. Version counts per customer
2. Exactly one current row per active customer
3. C001 has 3 versions with correct attributes at each stage
4. C002 has 1 version despite the name change
5. C004 is closed (hard delete) and absent from the current table
6. No overlapping SCD2 intervals
7. No time gaps between consecutive versions
8. `SCD_CUR_IND` consistency with `SCD_EXPN_DTM`
9. `SCD_HASH` is never null
10. Point-in-time lookup for C001 at 2026-01-20

---

#### `snowflake/99_teardown.sql`
**What it does:** Drops the entire `SCD2_POC_002` database, warehouse, and role. Use this to clean up after you're done.

> **Warning:** This is irreversible. Everything in `SCD2_POC_002` will be deleted.

---

### dbt Files — Detailed

#### `dbt/dbt_project.yml`
**What it does:** The main configuration file for the dbt project. Every dbt project must have this file.

Key settings:
- `profile: 'scd2_poc_002'` — tells dbt which profile in `~/.dbt/profiles.yml` to use for the Snowflake connection
- Schema mapping: staging models go to `STAGING` schema, mart models go to `MARTS` schema, snapshots go to `SNAPSHOTS` schema
- `scd2_open_record_date: "9999-12-31"` — the sentinel date used for open (current) SCD2 rows

---

#### `dbt/profiles.yml.example`
**What it does:** A template for your Snowflake connection. **This file does not contain real credentials** — it's a guide for what `~/.dbt/profiles.yml` should look like.

You must copy this to `C:\Users\YourName\.dbt\profiles.yml` and fill in your real Snowflake account details before dbt will work.

---

#### `dbt/packages.yml`
**What it does:** Lists external dbt libraries (called "packages") that this project uses.

This project uses `dbt-labs/dbt_utils`, specifically the `generate_surrogate_key()` macro which creates consistent hash-based surrogate keys from one or more columns.

After editing this file, always run `dbt deps` to download the packages.

---

#### `dbt/snapshots/snap_dim_customers.sql` ⭐ Most Important File
**What it does:** This is the **heart of the SCD2 logic**. dbt reads this file and automatically manages the version history table in Snowflake.

Key configuration:
```sql
strategy='check'             -- detect changes by comparing column values
check_cols=[                 -- only these 19 columns trigger new versions
    'CARD_TYPE', 'CITY', 'CUSTOMER_TIER', ... (all 19 Type II cols)
]
unique_key='CUSTOMER_BUSINESS_KEY'   -- the natural key
invalidate_hard_deletes=True         -- close the row if it disappears from source
```

When you run `dbt snapshot`:
- dbt reads `RAW.CUSTOMER_SRC_002`
- For each row, it hashes the 19 `check_cols`
- If the hash changed → new version (closes old row, inserts new row)
- If the row is gone from source → closes open row (hard delete handling)
- dbt adds `dbt_valid_from` (version start) and `dbt_valid_to` (version end, NULL for current)

---

#### `dbt/models/sources.yml`
**What it does:** Tells dbt where the raw source data lives. This is how dbt knows that `{{ source('raw', 'CUSTOMER_SRC_002') }}` refers to `SCD2_POC_002.RAW.CUSTOMER_SRC_002`.

Also defines basic data quality tests on the source (e.g. `CUSTOMER_BUSINESS_KEY` must be not-null and unique).

---

#### `dbt/models/staging/stg_dim_customers.sql`
**What it does:** Light cleaning of the raw source data. No SCD2 logic here — just normalisation:
- `TRIM()` — removes leading/trailing whitespace from all text columns
- `UPPER()` — standardises codes (e.g. `CARD_TYPE`, `REGION`, `RESTRICTED_FLAG`)
- `LOWER()` — normalises email addresses
- `INITCAP()` — title-cases names and city names

This model is a **view** (not a physical table) — it runs on the fly when queried.

---

#### `dbt/models/marts/dim_customers_current.sql`
**What it does:** Produces the current-state dimension table — **one row per active customer**.

Reads from the snapshot table and filters to `WHERE dbt_valid_to IS NULL` (the current version). Then maps dbt's internal column names to the standard DIM_CUSTOMERS conventions:

| dbt snapshot column | Output column | Notes |
|---|---|---|
| `dbt_valid_from` | `SCD_EFF_DTM` | When this version started |
| *(constant)* | `SCD_EXPN_DTM` | Always `'9999-12-31'` |
| *(constant)* | `SCD_CUR_IND` | Always `'Y'` |
| `CUSTOMER_BUSINESS_KEY` hash | `CUSTOMER_KEY` | Stable surrogate PK |
| SHA2 of 19 Type II cols | `SCD_HASH` | Change detection hash |

Hard-deleted customers (like C004 after T2) do **not** appear in this table.

---

#### `dbt/models/marts/dim_customers_history.sql`
**What it does:** Produces the **full SCD2 history table** — all versions of every customer.

Similar to `dim_customers_current.sql` but includes **all rows** (current and historical) with proper `SCD_EFF_DTM` / `SCD_EXPN_DTM` populated:

| Situation | `SCD_EFF_DTM` | `SCD_EXPN_DTM` | `SCD_CUR_IND` |
|---|---|---|---|
| Current version | When version started | `9999-12-31` | `Y` |
| Historical version | When version started | When it ended | `N` |
| Hard-deleted | When version started | When deletion was detected | `N` |

**This is the table to use for point-in-time joins:**
```sql
WHERE :as_of_timestamp >= SCD_EFF_DTM
  AND :as_of_timestamp  < SCD_EXPN_DTM
```

Also generates `CUSTOMER_VERSION_SK` — a surrogate key unique per version (useful as a FK from fact tables).

---

#### `dbt/models/staging/schema.yml` and `dbt/models/marts/schema.yml`
**What they do:** Define data quality tests that dbt runs after building the models.

Tests included:
- `not_null` — column must not contain NULL values
- `unique` — column must contain no duplicates
- `accepted_values` — column must only contain values from a specified list
- `assert_no_overlapping_periods` — custom SCD2 test (see below)

---

#### `dbt/tests/assert_no_overlapping_periods.sql`
**What it does:** A custom dbt test that verifies **no two SCD2 rows for the same customer overlap in time**.

This is critical for point-in-time correctness. If two versions overlapped, a lookup at a given timestamp could return two rows instead of one.

The test uses a SQL window function (`LEAD`) to compare each row's `SCD_EXPN_DTM` against the next row's `SCD_EFF_DTM`. It returns any rows that violate the rule — a passing test returns zero rows.

---

#### `demo_run.bat`
**What it does:** Automates the full demo from environment setup to final validation.

Steps the script performs:
1. Checks that `uv` is installed
2. Creates a Python virtual environment in `dbt\.venv`
3. Installs `dbt-snowflake` using `uv pip install`
4. Installs dbt packages (`dbt deps`)
5. Verifies the Snowflake connection (`dbt debug`)
6. **Pauses** and asks you to run the T0 SQL, then runs dbt pipeline (snapshot + run + test)
7. **Pauses** and asks you to run the T1 SQL, then runs dbt pipeline again
8. **Pauses** and asks you to run the T2 SQL, then runs dbt pipeline again
9. Generates dbt documentation
10. Prints final validation instructions

---

## 8. Step-by-Step Setup Guide

### Step 1 — Install uv

```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

Restart your terminal, verify with `uv --version`.

### Step 2 — Configure dbt Profile

Copy `scd2_poc_002\dbt\profiles.yml.example` to `C:\Users\YourName\.dbt\profiles.yml` and edit with your Snowflake details.

### Step 3 — Run Snowflake Setup Scripts

Open Snowflake (SnowSQL, Snowsight, or any SQL client) and run in order:

```sql
-- Run as ACCOUNTADMIN
@scd2_poc_002/snowflake/01_setup_database.sql
@scd2_poc_002/snowflake/02_create_raw_tables.sql
```

Then uncomment and run the GRANT line at the bottom of `01_setup_database.sql` to grant the role to your user:
```sql
GRANT ROLE SCD2_POC_002_ROLE TO USER YOUR_USER_NAME;
```

### Step 4 — Run the Demo

Open Command Prompt, navigate to the `scd2_poc_002` folder, and run:

```cmd
cd C:\git_claude\claude_scd2_snowflake_matillion\scd2_poc_002
demo_run.bat
```

The script will pause at each round and wait for you to run the corresponding Snowflake SQL script before continuing.

### Step 5 — Run Validation Queries

After the demo completes, run in Snowflake:

```sql
@scd2_poc_002/snowflake/06_validation_queries.sql
```

All failure-check queries should return **zero rows**.

### Step 6 — Explore dbt Docs (Optional)

```cmd
cd scd2_poc_002\dbt
.venv\Scripts\dbt.exe docs serve
```

Opens a browser with an interactive data lineage graph and model documentation.

---

## 9. Test Scenarios Explained

### Timeline Overview

```
T0 (2026-01-01)        T1 (2026-01-15)        T2 (2026-02-01)
      │                       │                       │
  Initial load            Round 1 changes         Round 2 changes
  5 customers inserted    ├─ C001: Type II ✱     ├─ C001: Type II ✱
                          └─ C002: Non-Type II   ├─ C004: Hard delete ✗
                                                 └─ C006: New customer ✚
```

### Use Case A — Type II Change Creates New Version

**What happens:** C001's city and tier change at T1.

**Before T1:**
```
C001 | Vancouver | Gold | EFF: 2026-01-01 | EXPN: 9999-12-31 | CUR: Y
```

**After T1 dbt run:**
```
C001 | Vancouver | Gold     | EFF: 2026-01-01 | EXPN: 2026-01-15 | CUR: N  ← closed
C001 | Victoria  | Platinum | EFF: 2026-01-15 | EXPN: 9999-12-31 | CUR: Y  ← new current
```

**After T2 dbt run** (RESTRICTED_FLAG change):
```
C001 | Vancouver | Gold     | RESTRICTED: N | EFF: 2026-01-01 | EXPN: 2026-01-15 | CUR: N
C001 | Victoria  | Platinum | RESTRICTED: N | EFF: 2026-01-15 | EXPN: 2026-02-01 | CUR: N
C001 | Victoria  | Platinum | RESTRICTED: Y | EFF: 2026-02-01 | EXPN: 9999-12-31 | CUR: Y
```

### Use Case B — Non-Type II Change (No New Version)

**What happens:** C002's first name changes at T1, but `FIRST_NAME` is not a tracked Type II column.

**Before T1:** `FIRST_NAME = 'Bob'`
**After T1 dbt run:** `FIRST_NAME = 'Robert'` — same row, updated in place, **no new version**

This shows the power of the `check` strategy — you control precisely which changes matter for history.

### Use Case C — Hard Delete Closes the Open Row

**What happens:** C004 is deleted from the source at T2.

**After T2 dbt run:**
```
C004 | Montreal | Gold | EFF: 2026-01-01 | EXPN: <snapshot run time> | CUR: N
```

C004 is gone from `DIM_CUSTOMERS_CURRENT` but preserved in `DIM_CUSTOMERS_HISTORY` with `SCD_CUR_IND = 'N'`.

---

## 10. How to Validate Results

After completing all three rounds, the expected state is:

| Customer | Versions | Current? | Notes |
|---|---|---|---|
| C001 | 3 | Yes | Vancouver/Gold → Victoria/Platinum → +RESTRICTED |
| C002 | 1 | Yes | Name change not tracked |
| C003 | 1 | Yes | No changes |
| C004 | 1 | **No** | Hard-deleted at T2 |
| C005 | 1 | Yes | No changes |
| C006 | 1 | Yes | New customer added at T2 |

Run `snowflake/06_validation_queries.sql` in Snowflake. All 10 checks should pass (zero rows returned for failure queries).

**Quick manual check (run in Snowflake):**
```sql
USE DATABASE SCD2_POC_002;

-- Should show C001=3, C004=1 with SCD_CUR_IND='N'
SELECT CUSTOMER_BUSINESS_KEY, COUNT(*) AS VERSIONS,
       MAX(SCD_CUR_IND) AS HAS_CURRENT
FROM MARTS.DIM_CUSTOMERS_HISTORY
GROUP BY 1 ORDER BY 1;

-- Should return 5 rows (no C004)
SELECT CUSTOMER_BUSINESS_KEY, CITY, CUSTOMER_TIER, SCD_EFF_DTM
FROM MARTS.DIM_CUSTOMERS_CURRENT
ORDER BY CUSTOMER_BUSINESS_KEY;
```

---

## 11. Troubleshooting

### `dbt debug` fails — connection error

- Check `~/.dbt/profiles.yml` exists and the profile name matches `scd2_poc_002`
- Verify your Snowflake account identifier format (e.g. `abc123.us-east-1` or `abc123.snowflakecomputing.com`)
- Make sure the role `SCD2_POC_002_ROLE` was granted to your user in `01_setup_database.sql`

### `dbt snapshot` fails with "table not found"

- Confirm you ran `01_setup_database.sql` and `02_create_raw_tables.sql` first
- Confirm you ran `03_load_initial_data.sql` so the source table has rows

### `dbt test` fails — overlapping periods

- This means the snapshot produced overlapping SCD2 intervals, which should not happen with a normal dbt snapshot. Check whether `CUSTOMER_BUSINESS_KEY` has duplicate rows in `CUSTOMER_SRC_002`.

### `uv not found` in demo_run.bat

- Close and reopen Command Prompt after installing uv (the PATH needs to refresh)
- Or run the install command again and make sure it completes without errors

### dbt generates wrong schema names (e.g. `SCD2_POC_002_MARTS` instead of `SCD2_POC_002.MARTS`)

- This is the default dbt Snowflake behavior — it prepends the profile's `schema` to the custom schema. This is expected and correct; all objects will be in `SCD2_POC_002`.

---

## 12. Glossary

| Term | Definition |
|---|---|
| **SCD** | Slowly Changing Dimension — a dimension table that changes over time |
| **SCD Type 2** | An SCD strategy that keeps full history by versioning rows |
| **Natural key / Business key** | The ID from the source system (e.g. `CUSTOMER_BUSINESS_KEY = 'C001'`) |
| **Surrogate key** | A generated ID internal to the data warehouse (e.g. `CUSTOMER_KEY`) that is stable and not dependent on the source |
| **Version key** | A surrogate key that changes per SCD2 version (e.g. `CUSTOMER_VERSION_SK`) |
| **Effectivity date** | `SCD_EFF_DTM` — when a version became active |
| **Expiry date** | `SCD_EXPN_DTM` — when a version was superseded; `9999-12-31` = still active |
| **Current indicator** | `SCD_CUR_IND = 'Y'` means this is the active version |
| **Hard delete** | A row that disappears from the source entirely — the SCD2 row is closed |
| **Point-in-time join** | A join that retrieves the dimension values active at a specific historical timestamp |
| **dbt snapshot** | A dbt feature that automatically manages SCD2 versioning |
| **check strategy** | dbt snapshot strategy where a hash of specified columns detects changes |
| **timestamp strategy** | dbt snapshot strategy where a `updated_at` timestamp column detects changes |
| **Surrogate key** | A system-generated identifier (hash) used as the primary key |
| **SCD_HASH** | SHA2-256 hash of all 19 Type II column values — used for fast change detection |
| **Half-open interval** | `[EFF, EXPN)` — EFF is included, EXPN is excluded; ensures no gaps or overlaps |
| **TIMESTAMP_NTZ** | Snowflake timestamp with no time zone; values stored in UTC by convention |
| **dbt_utils** | A dbt package providing helper macros like `generate_surrogate_key()` |
| **uv** | An extremely fast Python package manager (replacement for pip/venv) |
