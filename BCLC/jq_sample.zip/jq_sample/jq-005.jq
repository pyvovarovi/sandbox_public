.[] | .name as $job |
.stages[] | select(.category == "Database") |
{job: $job, stage: .name, type: .stage_type, properties: .properties}
