unique_by(.name)[] | {
    job:     .name,
    sources: ([.. | strings |
                select(test("FROM"; "i")) |
                scan("(?i)FROM[ \t]+([a-zA-Z0-9_.#@]+)") |
                .[0]] | unique),
    targets: ([.. | strings |
                select(test("INSERT[ \t]+INTO"; "i")) |
                scan("(?i)INSERT[ \t]+INTO[ \t]+([a-zA-Z0-9_.#@]+)") |
                .[0]] | unique)
}
