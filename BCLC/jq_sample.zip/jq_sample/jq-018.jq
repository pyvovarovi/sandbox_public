.. | strings | select(test("SELECT|INSERT|UPDATE|DELETE|MERGE"; "i"))
