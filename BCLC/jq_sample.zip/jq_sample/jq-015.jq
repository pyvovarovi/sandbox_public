[.. | strings |
    select(test("FROM|JOIN"; "i")) |
    scan("(?i)(?:FROM|JOIN)[ \t]+([a-zA-Z0-9_.#@]+)") |
    .[0]
] |
unique[] |
split(".") |
if   length >= 3 then {schema: .[-2], table: .[-1]}
elif length == 2 then {schema: .[0],  table: .[1]}
else                  {schema: null,  table: .[0]}
end
