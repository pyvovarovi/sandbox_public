"=== Connection parameters (param_type 13) ===",
([.[] | .name as $job |
    .parameters[] |
    select(.param_type == "13") |
    "\($job)  |  \(.name)  |  \(.prompt)"
] | unique[]),

"",
"=== Database/Schema from 3-part SQL names ===",
([.. | strings |
    select(test("FROM|JOIN"; "i")) |
    scan("(?i)(?:FROM|JOIN)[ \t]+([a-zA-Z0-9_]+[.][a-zA-Z0-9_]+)[.][a-zA-Z0-9_]") |
    .[0]
] | unique[])
