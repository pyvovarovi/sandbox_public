[.. | strings |
    select(test("FROM"; "i")) |
    scan("(?i)FROM[ \t]+([a-zA-Z0-9_.#@]+)") |
    .[0]
] | unique[]
