.. | strings | select(test("MERGE INTO"; "i"))
