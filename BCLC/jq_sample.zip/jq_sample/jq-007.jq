[.[].job_type] |
group_by(.) |
map({type: .[0], count: length})
