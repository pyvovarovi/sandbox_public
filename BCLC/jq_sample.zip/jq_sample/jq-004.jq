.[] | .name as $job |
.stages[] | .name as $stage | .stage_type as $type |
.properties | to_entries[] |
select(.value | type == "string") |
select(.value | test("SELECT|INSERT|UPDATE|DELETE"; "i")) |
{job: $job, stage: $stage, stage_type: $type, property: .key, sql: .value}
