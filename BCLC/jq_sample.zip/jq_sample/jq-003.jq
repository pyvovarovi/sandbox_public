.[] | .name as $job |
.stages[] | select(.stage_type == "CTransformerStage") |
{job: $job, stage: .name, inputs: .input_links, outputs: .output_links}
