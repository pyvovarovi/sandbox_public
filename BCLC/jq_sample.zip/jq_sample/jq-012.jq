[.[] | select(.. | strings | test($table; "i")) | .name] |
unique[]
