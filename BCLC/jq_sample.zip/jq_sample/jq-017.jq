[unique_by(.name)[].stages[].stage_type] |
group_by(.) |
map({type: .[0], count: length}) |
sort_by(-.count)
