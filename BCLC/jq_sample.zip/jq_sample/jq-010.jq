[.[] | {
    job: .name,
    tables: ([
        .stages[] |
        .properties | to_entries[] |
        select(.value | type == "string") |
        select(.value | test("FROM|JOIN"; "i")) |
        .value |
        scan("(?i)(?:FROM|JOIN)[ \t]+([a-zA-Z0-9_.#@]+)") |
        .[0]
    ] | unique)
}]
