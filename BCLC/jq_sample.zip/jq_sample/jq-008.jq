.[] | .stages[] |
select(.stage_type == "CTransformerStage") |
.name
