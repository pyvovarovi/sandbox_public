unique_by(.name)[] | .name as $job |
{
  job: $job,
  sql_sources: ([
    .stages[] | select(.stage_type == "Pxsqlsvr") |
    .properties as $p |
    ($p.query, $p.open, $p.close) | strings |
    scan("(?i)(?:FROM|JOIN)[ \t]+([a-zA-Z0-9_.#@]+)") | .[0]
  ] | unique),
  sql_targets: ([
    .stages[] | select(.stage_type == "Pxsqlsvr") |
    .properties as $p |
    ($p.query, $p.open, $p.close) | strings |
    scan("(?i)(?:INSERT[ \t]+INTO|UPDATE|DELETE[ \t]+FROM|DELETE[ \t]+[a-zA-Z])[ \t]+([a-zA-Z0-9_.#@]+)") | .[0]
  ] | unique),
  write_targets: ([
    .stages[] |
    select(.stage_type == "Pxsqlsvr" and .properties.tablename != null) |
    .properties.tablename
  ] | unique)
}
