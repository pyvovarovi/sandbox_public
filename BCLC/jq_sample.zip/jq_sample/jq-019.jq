unique_by(.name)[] |
.name as $job |
.stages[] |
.name as $stage |
.properties |
to_entries[] |
select(.value | type == "string" and test("SELECT|INSERT|UPDATE|DELETE|MERGE"; "i")) |
{job: $job, stage: $stage, property: .key, sql: .value}
