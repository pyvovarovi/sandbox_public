unique_by(.name)[] |
.name as $job |
.stages[] | select(.stage_type == "Pxsqlsvr") |
{
  job:        $job,
  stage:      .name,
  connection: .properties.data_source,
  operator:   .properties.operator,
  mode:       .properties.mode,
  tablename:  .properties.tablename,
  query:      .properties.query,
  open:       .properties.open,
  close:      .properties.close
}
