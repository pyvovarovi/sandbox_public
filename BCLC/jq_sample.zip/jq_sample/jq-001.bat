@echo off
cd /d "%~dp0\.."

:: Usage: jq-001.bat [path-to-json]
:: Default: output\demo-002-yaml\all_jobs_2026-04-11.json
set "JSON_FILE=%~1"
if "%JSON_FILE%"=="" set "JSON_FILE=output\demo-002-yaml\demo.json"

:: Locate jq — WinGet install path, then fall back to PATH
:: C:\Users\user\AppData\Local\Microsoft\WinGet\Packages\jqlang.jq_Microsoft.Winget.Source_8wekyb3d8bbwe\jq.exe
set "JQ=%LOCALAPPDATA%\Microsoft\WinGet\Packages\jqlang.jq_Microsoft.Winget.Source_8wekyb3d8bbwe\jq.exe"
if not exist "%JQ%" set "JQ=jq"

echo jq version:
"%JQ%" --version
echo.
echo Input: %JSON_FILE%
echo.

:: ── 1. Table names from FROM / JOIN ──────────────────────────────────────────
echo ============================================================
echo  1. Table names referenced in FROM / JOIN
echo ============================================================
pause
"%JQ%" -r -f jq_sample\jq-001.jq "%JSON_FILE%"
echo.

:: ── 2. All job names ─────────────────────────────────────────────────────────
echo ============================================================
echo  2. All job names
echo ============================================================
pause
"%JQ%" -r -f jq_sample\jq-002.jq "%JSON_FILE%"
echo.

:: ── 3. Transformer stages ────────────────────────────────────────────────────
echo ============================================================
echo  3. Transformer stages (CTransformerStage)
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-003.jq "%JSON_FILE%"
echo.

:: ── 4. SQL queries ───────────────────────────────────────────────────────────
echo ============================================================
echo  4. SQL queries (SELECT / INSERT / UPDATE / DELETE)
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-004.jq "%JSON_FILE%"
echo.

:: ── 5. Database stages ───────────────────────────────────────────────────────
echo ============================================================
echo  5. Database connection stages
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-005.jq "%JSON_FILE%"
echo.

:: ── 6. All job names (raw list) ──────────────────────────────────────────────
echo ============================================================
echo  6. All job names (raw)
echo ============================================================
pause
"%JQ%" -r -f jq_sample\jq-006.jq "%JSON_FILE%"
echo.

:: ── 7. Job types grouped with counts ─────────────────────────────────────────
echo ============================================================
echo  7. Job types — grouped with counts
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-007.jq "%JSON_FILE%"
echo.

:: ── 8. Transformer stage names ───────────────────────────────────────────────
echo ============================================================
echo  8. Transformer stage names (CTransformerStage)
echo ============================================================
pause
"%JQ%" -r -f jq_sample\jq-008.jq "%JSON_FILE%"
echo.

:: ── 9. FROM table names (unique, sorted) ─────────────────────────────────────
echo ============================================================
echo  9. Table names from FROM clauses (unique)
echo ============================================================
pause
"%JQ%" -r -f jq_sample\jq-009.jq "%JSON_FILE%"
echo.

:: ── 10. Per-job table map ─────────────────────────────────────────────────────
echo ============================================================
echo  10. Per-job table map (FROM / JOIN tables per job)
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-010.jq "%JSON_FILE%"
echo.

:: ── 11. Job inventory CSV ─────────────────────────────────────────────────────
echo ============================================================
echo  11. Job inventory — Job / Type / Stages / Complexity  [CSV]
echo ============================================================
set "CSV_OUT=output\inventory.csv"
pause
"%JQ%" -r -f jq_sample\jq-011.jq "%JSON_FILE%" > "%CSV_OUT%"
echo Saved: %CSV_OUT%
echo.
type "%CSV_OUT%"
echo.

:: ── 12. Find jobs using specific table ───────────────────────────────────────
echo ============================================================
echo  12. Find jobs using a specific table
echo ============================================================
set /p TABLE_NAME=Enter table name to search (e.g. tPlayerCard):
echo.
pause
"%JQ%" -r --arg table "%TABLE_NAME%" -f jq_sample\jq-012.jq "%JSON_FILE%"
echo.
pause

:: ── 13. Extract connection strings ───────────────────────────────────────────
echo ============================================================
echo  13. Connection parameters (param_type 13) + DB/Schema pairs
echo ============================================================
pause
"%JQ%" -r -f jq_sample\jq-013.jq "%JSON_FILE%"
echo.

:: ── 14. All table names from SQL ──────────────────────────────────────────────
echo ============================================================
echo  14. All table names from FROM / JOIN (unique, sorted)
echo ============================================================
pause
"%JQ%" -r -f jq_sample\jq-014.jq "%JSON_FILE%"
echo.

:: ── 15. Separate schema and table ────────────────────────────────────────────
echo ============================================================
echo  15. Schema + table separated (from FROM / JOIN)
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-015.jq "%JSON_FILE%"
echo.

:: ── 16. Build table lineage ───────────────────────────────────────────────────
echo ============================================================
echo  16. Table lineage — sources (FROM) and targets (INSERT INTO) per job
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-016.jq "%JSON_FILE%"
echo.

:: ── 17. Count stages by type ──────────────────────────────────────────────────
echo ============================================================
echo  17. Stage counts by type (sorted by count desc)
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-017.jq "%JSON_FILE%"
echo.

:: ── 18. Extract all SQL statements ───────────────────────────────────────────
echo ============================================================
echo  18. All SQL statements (SELECT / INSERT / UPDATE / DELETE / MERGE)
echo ============================================================
pause
"%JQ%" -r -f jq_sample\jq-018.jq "%JSON_FILE%"
echo.

:: ── 19. SQL with context (job / stage / property) ─────────────────────────────
echo ============================================================
echo  19. SQL statements with context — job, stage, property name
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-019.jq "%JSON_FILE%"
echo.

:: ── 20. Find specific SQL patterns (MERGE INTO) ───────────────────────────────
echo ============================================================
echo  20. Find specific SQL patterns (MERGE INTO)
echo ============================================================
pause
"%JQ%" -r -f jq_sample\jq-020.jq "%JSON_FILE%"
echo.

:: ── 21. Table names — Method 1: FROM clause only ─────────────────────────────
echo ============================================================
echo  21. Table names from FROM clause only (unique, sorted)
echo ============================================================
pause
"%JQ%" -r -f jq_sample\jq-021.jq "%JSON_FILE%"
echo.

:: ── 22. Pxsqlsvr SQL inventory (query / open / close per stage) ──────────────
echo ============================================================
echo  22. Pxsqlsvr SQL inventory — query, open, close per stage
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-022.jq "%JSON_FILE%"
echo.

:: ── 23. Pxsqlsvr source-target table map ─────────────────────────────────────
echo ============================================================
echo  23. Pxsqlsvr source/target table map per job
echo ============================================================
pause
"%JQ%" -f jq_sample\jq-023.jq "%JSON_FILE%"
echo.

:: ==================================================================================================================================================
pause
