(["Job", "Type", "Stages", "Complexity"] | @csv),
(unique_by(.name)[] | {
    job:        .name,
    type:       .job_type,
    stages:     (.stages | length),
    complexity: (.stages | length |
                 if . > 20 then "High"
                 elif . > 10 then "Medium"
                 else "Low" end)
} | [.job, .type, (.stages | tostring), .complexity] | @csv)
