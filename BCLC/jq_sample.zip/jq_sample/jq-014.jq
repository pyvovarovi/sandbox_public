([.. | strings |
    select(test("FROM|JOIN"; "i")) |
    scan("(?i)(?:FROM|JOIN)[ \t]+([a-zA-Z0-9_.#@]+)") |
    .[0]
] | unique[])
