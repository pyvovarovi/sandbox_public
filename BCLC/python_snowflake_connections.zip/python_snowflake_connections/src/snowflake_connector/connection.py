"""
connection.py — Typed Snowflake connection wrapper.

Provides SnowflakeConnection with factory class methods for every supported
authentication type. All factories accept **kwargs forwarded verbatim to
snowflake.connector.connect(), so callers can pass warehouse, database,
schema, role, session_parameters, etc. without any wrapper bloat.

Supported auth types
--------------------
1.  from_password               — username + password (default 'snowflake' authenticator)
2.  from_keypair_file           — key-pair via PEM file path (SNOWFLAKE_JWT)
3.  from_keypair_bytes          — key-pair via in-memory DER bytes (SNOWFLAKE_JWT)
4.  from_oauth_token            — pre-obtained OAuth access token
5.  from_browser_sso            — browser-based SSO (externalbrowser)
6.  from_okta                   — Okta native SSO (IdP-initiated SAML)
7.  from_mfa                    — MFA / Duo (username_password_mfa)
8.  from_oauth_client_credentials — OAuth client credentials flow (machine-to-machine)
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import snowflake.connector
import snowflake.connector.errors
from snowflake.connector import DictCursor
from snowflake.connector import SnowflakeConnection as _RawConn

logger: logging.Logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Authenticator string constants
# ---------------------------------------------------------------------------
_AUTH_SNOWFLAKE: str           = "snowflake"
_AUTH_SNOWFLAKE_JWT: str       = "snowflake_jwt"
_AUTH_OAUTH: str               = "oauth"
_AUTH_EXTERNALBROWSER: str     = "externalbrowser"
_AUTH_MFA: str                 = "username_password_mfa"
_AUTH_OAUTH_CLIENT_CREDS: str  = "oauth_client_credentials"

# Parameters whose values must never appear in logs
_SENSITIVE_PARAMS: frozenset[str] = frozenset({
    "password",
    "private_key",
    "private_key_file_pwd",
    "token",
    "oauth_client_secret",
    "passcode",
})


# ---------------------------------------------------------------------------
# Module-level helper
# ---------------------------------------------------------------------------

def _masked_kwargs(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of kwargs with sensitive values replaced by '***'."""
    return {k: "***" if k in _SENSITIVE_PARAMS else v for k, v in kwargs.items()}


# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------

class SnowflakeConnection:
    """
    Typed wrapper around snowflake.connector.connect().

    Do not call __init__ directly — use one of the factory class methods:

        conn = SnowflakeConnection.from_password(
            account="xy12345.us-east-1",
            user="alice",
            password="s3cr3t",
            warehouse="COMPUTE_WH",
        )
        with conn:
            with conn.cursor() as cur:
                cur.execute("SELECT CURRENT_VERSION()")
                row = cur.fetchone()
    """

    def __init__(self, raw: _RawConn) -> None:
        """
        Store an already-opened raw SnowflakeConnection.
        Prefer factory class methods over calling this directly.
        """
        self._raw: _RawConn = raw

    # ------------------------------------------------------------------
    # Internal connection helper (shared by all factories)
    # ------------------------------------------------------------------

    @classmethod
    def _connect(cls, **kwargs: Any) -> "SnowflakeConnection":
        """
        Log masked kwargs, call snowflake.connector.connect(**kwargs),
        and return a wrapped SnowflakeConnection.

        Raises:
            snowflake.connector.errors.DatabaseError:   Authentication failure.
            snowflake.connector.errors.OperationalError: Network / timeout issue.
        """
        logger.debug(
            "Connecting to Snowflake  account=%r  authenticator=%r  params=%r",
            kwargs.get("account"),
            kwargs.get("authenticator", _AUTH_SNOWFLAKE),
            _masked_kwargs(kwargs),
        )
        raw: _RawConn = snowflake.connector.connect(**kwargs)
        logger.info(
            "Connected to Snowflake  account=%r  user=%r  warehouse=%r",
            raw.account,
            raw.user,
            raw.warehouse,
        )
        return cls(raw)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    @property
    def raw(self) -> _RawConn:
        """The underlying snowflake.connector.SnowflakeConnection instance."""
        return self._raw

    def cursor(self, cursor_class: type = DictCursor) -> Any:
        """
        Return a cursor from the underlying connection.

        Defaults to DictCursor so rows come back as dicts.
        Pass cursor_class=snowflake.connector.cursor.SnowflakeCursor for tuple rows.
        """
        return self._raw.cursor(cursor_class)

    def close(self) -> None:
        """Close the underlying connection."""
        logger.debug("Closing Snowflake connection  account=%r", self._raw.account)
        self._raw.close()
        logger.info("Snowflake connection closed.")

    def __enter__(self) -> "SnowflakeConnection":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Factory class methods — one per auth type
    # ------------------------------------------------------------------

    @classmethod
    def from_password(
        cls,
        *,
        account: str,
        user: str,
        password: str,
        **kwargs: Any,
    ) -> "SnowflakeConnection":
        """
        Auth type 1: Password authentication (authenticator='snowflake', the default).

        Args:
            account:  Snowflake account identifier, e.g. 'xy12345.us-east-1'.
            user:     Snowflake username.
            password: Plaintext password. Never written to logs.
            **kwargs: Forwarded to snowflake.connector.connect().
                      Common extras: warehouse, database, schema, role,
                      login_timeout, client_session_keep_alive.

        Returns:
            Connected SnowflakeConnection instance.

        Raises:
            snowflake.connector.errors.DatabaseError: on wrong credentials.
        """
        return cls._connect(
            account=account,
            user=user,
            password=password,
            authenticator=_AUTH_SNOWFLAKE,
            **kwargs,
        )

    @classmethod
    def from_keypair_file(
        cls,
        *,
        account: str,
        user: str,
        private_key_file: str | Path,
        private_key_file_pwd: str | bytes | None = None,
        **kwargs: Any,
    ) -> "SnowflakeConnection":
        """
        Auth type 2: Key-pair authentication using a private key FILE path.

        The connector reads and decrypts the PEM/p8 file itself.

        Args:
            account:              Snowflake account identifier.
            user:                 Snowflake username.
            private_key_file:     Path to the PEM-encoded private key file (.p8).
            private_key_file_pwd: Passphrase to decrypt the key (str or bytes).
                                  Pass None for an unencrypted key. Never logged.
            **kwargs:             Forwarded to snowflake.connector.connect().

        Returns:
            Connected SnowflakeConnection instance.
        """
        connect_kwargs: dict[str, Any] = {
            "account": account,
            "user": user,
            "authenticator": _AUTH_SNOWFLAKE_JWT,
            "private_key_file": str(private_key_file),
        }
        if private_key_file_pwd is not None:
            connect_kwargs["private_key_file_pwd"] = private_key_file_pwd
        connect_kwargs.update(kwargs)
        return cls._connect(**connect_kwargs)

    @classmethod
    def from_keypair_bytes(
        cls,
        *,
        account: str,
        user: str,
        private_key: bytes,
        **kwargs: Any,
    ) -> "SnowflakeConnection":
        """
        Auth type 3: Key-pair authentication using in-memory DER-encoded bytes.

        The caller is responsible for loading and decrypting the key.
        Typical preparation using the `cryptography` package:

            from cryptography.hazmat.primitives.serialization import (
                Encoding, PrivateFormat, NoEncryption, load_pem_private_key,
            )
            with open("rsa_key.p8", "rb") as f:
                pem_bytes = f.read()
            key_obj = load_pem_private_key(pem_bytes, password=b"passphrase")
            der_bytes = key_obj.private_bytes(
                Encoding.DER, PrivateFormat.PKCS8, NoEncryption()
            )

        Args:
            account:     Snowflake account identifier.
            user:        Snowflake username.
            private_key: DER-encoded RSA private key bytes. Never logged.
            **kwargs:    Forwarded to snowflake.connector.connect().

        Returns:
            Connected SnowflakeConnection instance.
        """
        return cls._connect(
            account=account,
            user=user,
            authenticator=_AUTH_SNOWFLAKE_JWT,
            private_key=private_key,
            **kwargs,
        )

    @classmethod
    def from_oauth_token(
        cls,
        *,
        account: str,
        user: str,
        token: str,
        **kwargs: Any,
    ) -> "SnowflakeConnection":
        """
        Auth type 4: OAuth with a pre-obtained access token.

        The caller acquires the token externally (e.g. from an IdP) and passes
        it here. Snowflake validates it against a configured external OAuth
        security integration.

        Args:
            account: Snowflake account identifier.
            user:    Snowflake username the token grants access for.
            token:   OAuth access token string. Never logged.
            **kwargs: Forwarded to snowflake.connector.connect().

        Returns:
            Connected SnowflakeConnection instance.
        """
        return cls._connect(
            account=account,
            user=user,
            authenticator=_AUTH_OAUTH,
            token=token,
            **kwargs,
        )

    @classmethod
    def from_browser_sso(
        cls,
        *,
        account: str,
        user: str,
        **kwargs: Any,
    ) -> "SnowflakeConnection":
        """
        Auth type 5: Browser-based SSO (authenticator='externalbrowser').

        Opens a system browser window for the user to authenticate via their
        configured identity provider (Okta, Azure AD, Google, etc.).

        NOT suitable for headless or CI environments — requires interactive
        browser access. Guard with SF_BROWSER_SSO_ENABLED=1 in demo/scripts.

        Args:
            account:  Snowflake account identifier.
            user:     Username sent as a hint to the IdP for pre-fill.
            **kwargs: Forwarded to snowflake.connector.connect().
                      Use external_browser_timeout (default 120 s) to control
                      how long the connector waits for the browser callback.

        Returns:
            Connected SnowflakeConnection instance.
        """
        return cls._connect(
            account=account,
            user=user,
            authenticator=_AUTH_EXTERNALBROWSER,
            **kwargs,
        )

    @classmethod
    def from_okta(
        cls,
        *,
        account: str,
        user: str,
        password: str,
        okta_url: str,
        **kwargs: Any,
    ) -> "SnowflakeConnection":
        """
        Auth type 6: Okta native SSO (IdP-initiated SAML, no browser required).

        The Okta account URL is passed as the authenticator value — this is the
        Snowflake connector convention for native Okta SSO. Credentials are the
        user's Okta credentials, not their Snowflake credentials.

        Args:
            account:  Snowflake account identifier.
            user:     Okta username (typically an email address).
            password: Okta password. Never logged.
            okta_url: Full Okta organisation URL, e.g. 'https://myco.okta.com'.
                      This string IS the authenticator value sent to the connector.
            **kwargs: Forwarded to snowflake.connector.connect().

        Returns:
            Connected SnowflakeConnection instance.
        """
        return cls._connect(
            account=account,
            user=user,
            password=password,
            authenticator=okta_url,
            **kwargs,
        )

    @classmethod
    def from_mfa(
        cls,
        *,
        account: str,
        user: str,
        password: str,
        passcode: str | None = None,
        passcode_in_password: bool = False,
        **kwargs: Any,
    ) -> "SnowflakeConnection":
        """
        Auth type 7: Multi-factor authentication (authenticator='username_password_mfa').

        Three operational modes:
        - passcode=None, passcode_in_password=False  →  connector blocks and waits
          for a Duo push / interactive MFA approval on the registered device.
        - passcode='123456'  →  TOTP code passed programmatically (no device interaction).
        - passcode_in_password=True  →  passcode appended to password (legacy format).

        Guard with SF_MFA_ENABLED=1 in demo/CI to prevent indefinite blocking.

        Args:
            account:               Snowflake account identifier.
            user:                  Snowflake username.
            password:              Snowflake password. Never logged.
            passcode:              Optional TOTP passcode string. Never logged.
            passcode_in_password:  Whether the passcode is embedded in the password.
            **kwargs:              Forwarded to snowflake.connector.connect().

        Returns:
            Connected SnowflakeConnection instance.
        """
        connect_kwargs: dict[str, Any] = {
            "account": account,
            "user": user,
            "password": password,
            "authenticator": _AUTH_MFA,
            "passcode_in_password": passcode_in_password,
        }
        if passcode is not None:
            connect_kwargs["passcode"] = passcode
        connect_kwargs.update(kwargs)
        return cls._connect(**connect_kwargs)

    @classmethod
    def from_oauth_client_credentials(
        cls,
        *,
        account: str,
        user: str,
        oauth_client_id: str,
        oauth_client_secret: str,
        oauth_token_request_url: str,
        oauth_scope: str = "",
        oauth_credentials_in_body: bool = False,
        **kwargs: Any,
    ) -> "SnowflakeConnection":
        """
        Auth type 8: OAuth client credentials flow (machine-to-machine, no user interaction).

        The connector fetches a token from the IdP token endpoint using the
        client_id / client_secret pair, then presents it to Snowflake.
        Requires a Snowflake external OAuth security integration to be configured.

        Args:
            account:                   Snowflake account identifier.
            user:                      Snowflake username to impersonate.
            oauth_client_id:           Client ID from your IdP application registration.
            oauth_client_secret:       Client secret. Never logged.
            oauth_token_request_url:   Token endpoint on the IdP,
                                       e.g. 'https://myco.okta.com/oauth2/v1/token'.
            oauth_scope:               Space-separated OAuth scopes (may be empty).
            oauth_credentials_in_body: Send client_id/secret in request body rather
                                       than Authorization header (default False).
            **kwargs:                  Forwarded to snowflake.connector.connect().

        Returns:
            Connected SnowflakeConnection instance.
        """
        return cls._connect(
            account=account,
            user=user,
            authenticator=_AUTH_OAUTH_CLIENT_CREDS,
            oauth_client_id=oauth_client_id,
            oauth_client_secret=oauth_client_secret,
            oauth_token_request_url=oauth_token_request_url,
            oauth_scope=oauth_scope,
            oauth_credentials_in_body=oauth_credentials_in_body,
            **kwargs,
        )
