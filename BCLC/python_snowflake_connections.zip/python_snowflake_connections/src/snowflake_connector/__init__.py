"""snowflake_connector — typed Snowflake connection factory."""

from .connection import SnowflakeConnection

__all__ = ["SnowflakeConnection"]
