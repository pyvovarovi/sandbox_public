"""
demo.py — Demonstrates all 8 Snowflake authentication types.

Each scenario reads its required env vars from a .env file (or the environment).
If any required variable is missing or empty the scenario is skipped with a
WARNING log — no exception is raised. This makes demo.py safe to run in any
environment, even one with no Snowflake credentials configured at all.

Usage:
    uv run python demo.py                  # run all 8 scenarios
    uv run python demo.py <scenario>       # run a single scenario by name

Scenario names:
    password  keypair_file  keypair_bytes  oauth_token
    browser_sso  okta  mfa  oauth_client_credentials

Setup:
    Copy .env.example to .env, fill in the vars for the scenarios you want
    to test, then run demo.bat (or the command above directly).
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

# Load .env before importing connection module.
# override=False means already-set environment variables (e.g. CI secrets) win.
load_dotenv(Path(__file__).parent / ".env", override=False)

from src.snowflake_connector import SnowflakeConnection  # noqa: E402

# ---------------------------------------------------------------------------
# Logging — DEBUG level so _connect() debug lines are visible
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s  %(levelname)-8s  %(name)-35s  %(message)s",
    stream=sys.stdout,
)
logger: logging.Logger = logging.getLogger("demo")

# Silence noisy third-party loggers
for _noisy in ("urllib3", "botocore", "boto3", "snowflake.connector.network"):
    logging.getLogger(_noisy).setLevel(logging.WARNING)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _env(*names: str) -> dict[str, str] | None:
    """
    Return {name: value} for each env var name.
    Returns None and emits a WARNING if any name is unset or empty.
    """
    result: dict[str, str] = {}
    missing: list[str] = []
    for name in names:
        val: str = os.environ.get(name, "").strip()
        if not val:
            missing.append(name)
        else:
            result[name] = val
    if missing:
        logger.warning("SKIP — missing env vars: %s", ", ".join(missing))
        return None
    return result


def _run_query(conn: SnowflakeConnection, label: str) -> None:
    """Execute a basic sanity query and log the result row."""
    with conn.cursor() as cur:
        cur.execute(
            "SELECT CURRENT_USER() AS usr, CURRENT_ROLE() AS role, "
            "CURRENT_WAREHOUSE() AS wh, CURRENT_VERSION() AS ver"
        )
        row: dict[str, Any] = cur.fetchone()
        logger.info(
            "[%s] user=%s  role=%s  warehouse=%s  version=%s",
            label,
            row.get("USR") or row.get("usr"),
            row.get("ROLE") or row.get("role"),
            row.get("WH") or row.get("wh"),
            row.get("VER") or row.get("ver"),
        )


# ---------------------------------------------------------------------------
# Scenario 1: Password
# ---------------------------------------------------------------------------

def demo_password() -> None:
    """Auth type 1: Username + password (authenticator=snowflake)."""
    logger.info("=" * 60)
    logger.info("=== Scenario 1: Password (authenticator=snowflake) ===")
    env: dict[str, str] | None = _env("SF_ACCOUNT", "SF_USER", "SF_PASSWORD")
    if env is None:
        return
    with SnowflakeConnection.from_password(
        account=env["SF_ACCOUNT"],
        user=env["SF_USER"],
        password=env["SF_PASSWORD"],
        warehouse=os.environ.get("SF_WAREHOUSE") or None,
    ) as conn:
        _run_query(conn, "password")


# ---------------------------------------------------------------------------
# Scenario 2: Key-pair via file
# ---------------------------------------------------------------------------

def demo_keypair_file() -> None:
    """Auth type 2: Key-pair using a PEM private key file path."""
    logger.info("=" * 60)
    logger.info("=== Scenario 2: Key-pair (file path) ===")
    env: dict[str, str] | None = _env("SF_ACCOUNT", "SF_USER", "SF_PRIVATE_KEY_FILE")
    if env is None:
        return
    pwd: str | None = os.environ.get("SF_PRIVATE_KEY_FILE_PWD") or None
    with SnowflakeConnection.from_keypair_file(
        account=env["SF_ACCOUNT"],
        user=env["SF_USER"],
        private_key_file=env["SF_PRIVATE_KEY_FILE"],
        private_key_file_pwd=pwd,
        warehouse=os.environ.get("SF_WAREHOUSE") or None,
    ) as conn:
        _run_query(conn, "keypair_file")


# ---------------------------------------------------------------------------
# Scenario 3: Key-pair via in-memory DER bytes
# ---------------------------------------------------------------------------

def demo_keypair_bytes() -> None:
    """Auth type 3: Key-pair using in-memory DER bytes (loads from the same PEM file)."""
    logger.info("=" * 60)
    logger.info("=== Scenario 3: Key-pair (in-memory DER bytes) ===")
    env: dict[str, str] | None = _env("SF_ACCOUNT", "SF_USER", "SF_PRIVATE_KEY_FILE")
    if env is None:
        return

    from cryptography.hazmat.primitives.serialization import (
        Encoding,
        NoEncryption,
        PrivateFormat,
        load_pem_private_key,
    )

    pem_path: Path = Path(env["SF_PRIVATE_KEY_FILE"])
    if not pem_path.exists():
        logger.warning("SKIP — SF_PRIVATE_KEY_FILE not found: %s", pem_path)
        return

    passphrase_str: str | None = os.environ.get("SF_PRIVATE_KEY_FILE_PWD") or None
    passphrase_bytes: bytes | None = (
        passphrase_str.encode() if passphrase_str else None
    )

    with open(pem_path, "rb") as f:
        private_key_obj = load_pem_private_key(f.read(), password=passphrase_bytes)

    der_bytes: bytes = private_key_obj.private_bytes(
        Encoding.DER, PrivateFormat.PKCS8, NoEncryption()
    )

    with SnowflakeConnection.from_keypair_bytes(
        account=env["SF_ACCOUNT"],
        user=env["SF_USER"],
        private_key=der_bytes,
        warehouse=os.environ.get("SF_WAREHOUSE") or None,
    ) as conn:
        _run_query(conn, "keypair_bytes")


# ---------------------------------------------------------------------------
# Scenario 4: OAuth access token
# ---------------------------------------------------------------------------

def demo_oauth_token() -> None:
    """Auth type 4: OAuth with a pre-obtained access token."""
    logger.info("=" * 60)
    logger.info("=== Scenario 4: OAuth access token ===")
    env: dict[str, str] | None = _env("SF_ACCOUNT", "SF_USER", "SF_OAUTH_TOKEN")
    if env is None:
        return
    with SnowflakeConnection.from_oauth_token(
        account=env["SF_ACCOUNT"],
        user=env["SF_USER"],
        token=env["SF_OAUTH_TOKEN"],
        warehouse=os.environ.get("SF_WAREHOUSE") or None,
    ) as conn:
        _run_query(conn, "oauth_token")


# ---------------------------------------------------------------------------
# Scenario 5: Browser SSO
# ---------------------------------------------------------------------------

def demo_browser_sso() -> None:
    """Auth type 5: Browser-based SSO (externalbrowser). Skipped unless opted in."""
    logger.info("=" * 60)
    logger.info("=== Scenario 5: Browser SSO (externalbrowser) ===")
    env: dict[str, str] | None = _env(
        "SF_ACCOUNT", "SF_USER", "SF_BROWSER_SSO_ENABLED"
    )
    if env is None:
        return
    if env["SF_BROWSER_SSO_ENABLED"].lower() not in ("1", "true", "yes"):
        logger.warning(
            "SKIP — SF_BROWSER_SSO_ENABLED=%r (set to '1' to enable browser pop-up)",
            env["SF_BROWSER_SSO_ENABLED"],
        )
        return
    with SnowflakeConnection.from_browser_sso(
        account=env["SF_ACCOUNT"],
        user=env["SF_USER"],
        warehouse=os.environ.get("SF_WAREHOUSE") or None,
    ) as conn:
        _run_query(conn, "browser_sso")


# ---------------------------------------------------------------------------
# Scenario 6: Okta native SSO
# ---------------------------------------------------------------------------

def demo_okta() -> None:
    """Auth type 6: Okta native SSO (IdP-initiated SAML, no browser required)."""
    logger.info("=" * 60)
    logger.info("=== Scenario 6: Okta native SSO ===")
    env: dict[str, str] | None = _env(
        "SF_ACCOUNT", "SF_USER", "SF_PASSWORD", "SF_OKTA_URL"
    )
    if env is None:
        return
    with SnowflakeConnection.from_okta(
        account=env["SF_ACCOUNT"],
        user=env["SF_USER"],
        password=env["SF_PASSWORD"],
        okta_url=env["SF_OKTA_URL"],
        warehouse=os.environ.get("SF_WAREHOUSE") or None,
    ) as conn:
        _run_query(conn, "okta")


# ---------------------------------------------------------------------------
# Scenario 7: MFA
# ---------------------------------------------------------------------------

def demo_mfa() -> None:
    """Auth type 7: MFA / Duo (username_password_mfa). Skipped unless opted in."""
    logger.info("=" * 60)
    logger.info("=== Scenario 7: MFA (username_password_mfa) ===")
    env: dict[str, str] | None = _env(
        "SF_ACCOUNT", "SF_USER", "SF_PASSWORD", "SF_MFA_ENABLED"
    )
    if env is None:
        return
    if env["SF_MFA_ENABLED"].lower() not in ("1", "true", "yes"):
        logger.warning(
            "SKIP — SF_MFA_ENABLED=%r (set to '1' to enable MFA scenario)",
            env["SF_MFA_ENABLED"],
        )
        return
    passcode: str | None = os.environ.get("SF_MFA_PASSCODE") or None
    with SnowflakeConnection.from_mfa(
        account=env["SF_ACCOUNT"],
        user=env["SF_USER"],
        password=env["SF_PASSWORD"],
        passcode=passcode,
        warehouse=os.environ.get("SF_WAREHOUSE") or None,
    ) as conn:
        _run_query(conn, "mfa")


# ---------------------------------------------------------------------------
# Scenario 8: OAuth client credentials
# ---------------------------------------------------------------------------

def demo_oauth_client_credentials() -> None:
    """Auth type 8: OAuth client credentials flow (machine-to-machine)."""
    logger.info("=" * 60)
    logger.info("=== Scenario 8: OAuth client credentials flow ===")
    env: dict[str, str] | None = _env(
        "SF_ACCOUNT",
        "SF_USER",
        "SF_OAUTH_CLIENT_ID",
        "SF_OAUTH_CLIENT_SECRET",
        "SF_OAUTH_TOKEN_REQUEST_URL",
    )
    if env is None:
        return
    scope: str = os.environ.get("SF_OAUTH_SCOPE", "")
    with SnowflakeConnection.from_oauth_client_credentials(
        account=env["SF_ACCOUNT"],
        user=env["SF_USER"],
        oauth_client_id=env["SF_OAUTH_CLIENT_ID"],
        oauth_client_secret=env["SF_OAUTH_CLIENT_SECRET"],
        oauth_token_request_url=env["SF_OAUTH_TOKEN_REQUEST_URL"],
        oauth_scope=scope,
        warehouse=os.environ.get("SF_WAREHOUSE") or None,
    ) as conn:
        _run_query(conn, "oauth_client_credentials")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

_SCENARIOS: dict[str, Any] = {
    "password":                  demo_password,
    "keypair_file":              demo_keypair_file,
    "keypair_bytes":             demo_keypair_bytes,
    "oauth_token":               demo_oauth_token,
    "browser_sso":               demo_browser_sso,
    "okta":                      demo_okta,
    "mfa":                       demo_mfa,
    "oauth_client_credentials":  demo_oauth_client_credentials,
}


def _run_scenario(fn: Any) -> None:
    """Execute a scenario function, catching and logging any connector errors."""
    try:
        fn()
    except Exception as exc:
        logger.error("FAILED — %s: %s", type(exc).__name__, exc)


def run_all() -> None:
    """Run all 8 authentication scenarios in sequence."""
    logger.info("Starting Snowflake connection demo — 8 auth scenarios")
    for fn in _SCENARIOS.values():
        _run_scenario(fn)
    logger.info("=" * 60)
    logger.info("Demo complete. Scenarios without credentials were skipped (SKIP).")


def run_one(name: str) -> None:
    """Run a single scenario by name."""
    fn = _SCENARIOS.get(name)
    if fn is None:
        logger.error(
            "Unknown scenario %r. Available: %s", name, ", ".join(_SCENARIOS)
        )
        sys.exit(1)
    _run_scenario(fn)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        run_one(sys.argv[1])
    else:
        run_all()
