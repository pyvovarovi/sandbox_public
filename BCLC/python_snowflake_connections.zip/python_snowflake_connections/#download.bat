@echo off
setlocal EnableDelayedExpansion

:: Set to "curl" or "gh"
set DOWNLOADER=gh

set REPO=pyvovarovi/claude_snowflake
set BRANCH=main

:: List of files to download
:: Required to execute demo.bat:
::   pyproject.toml + uv.lock + .python-version  -> uv sync (installs dependencies)
::   src/snowflake_connector/*                    -> the connection class
::   demo.py                                      -> demo runner
::   env.demo / env.example                       -> credentials (copy env.demo to .env to run)
set FILES=pyproject.toml uv.lock .python-version demo.bat demo.py src/snowflake_connector/__init__.py src/snowflake_connector/connection.py src/snowflake_connector/py.typed env.demo env.example README.md

set TARGET_DIR=%~dp0
set BASE_URL=https://raw.githubusercontent.com/%REPO%/%BRANCH%
set ERRORS=0

echo Downloading files to %TARGET_DIR% using %DOWNLOADER%...
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

:: Create subdirectory structure required by the package
if not exist "%TARGET_DIR%src"                          mkdir "%TARGET_DIR%src"
if not exist "%TARGET_DIR%src\snowflake_connector"      mkdir "%TARGET_DIR%src\snowflake_connector"

if /i "%DOWNLOADER%"=="curl" (
    for %%F in (%FILES%) do (
        echo --------------------------------------------------------------------------
        curl -fsSL "%BASE_URL%/%%F" -o "%TARGET_DIR%\%%F"
        if errorlevel 1 ( echo FAILED: %%F [exit code !errorlevel!] & set /a ERRORS+=1 ) else ( echo Downloaded %%F )
    )
) else if /i "%DOWNLOADER%"=="gh" (
    for %%F in (%FILES%) do (
        echo --------------------------------------------------------------------------
        set "FPATH=%%F"
        set "FPATH=!FPATH:/=\!"
        gh api repos/%REPO%/contents/%%F --header "Accept: application/vnd.github.raw" > "%TARGET_DIR%!FPATH!"
        if errorlevel 1 ( echo FAILED: %%F [exit code !errorlevel!] & set /a ERRORS+=1 ) else ( echo Downloaded %%F )
    )
) else (
    echo ERROR: Unknown DOWNLOADER "%DOWNLOADER%". Set to "curl" or "gh".
    set /a ERRORS+=1
)

echo.
if %ERRORS%==0 (
    echo All files downloaded successfully.
) else (
    echo Done with %ERRORS% error(s). Window will stay open.
    pause
)

endlocal
