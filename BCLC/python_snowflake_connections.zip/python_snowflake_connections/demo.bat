@echo off
REM ============================================================
REM  demo.bat — Snowflake connection demo
REM
REM  Runs each of the 8 auth scenarios one at a time.
REM  Pauses after each so you can review the output.
REM  Scenarios skip gracefully if required env vars are missing.
REM  Copy .env.example to .env to configure credentials.
REM ============================================================

echo.
echo ============================================================
echo  [STEP 1] Syncing dependencies with uv...
echo ============================================================
uv sync
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: uv sync failed with exit code %ERRORLEVEL%. Aborting.
    exit /b %ERRORLEVEL%
)
echo uv sync OK.

echo.
echo ============================================================
echo  Scenario 1 of 8 - Password  (authenticator=snowflake)
echo ============================================================
uv run python demo.py password
echo.
pause

echo.
echo ============================================================
echo  Scenario 2 of 8 - Key-pair via file  (SNOWFLAKE_JWT)
echo ============================================================
uv run python demo.py keypair_file
echo.
pause

echo.
echo ============================================================
echo  Scenario 3 of 8 - Key-pair via in-memory bytes  (SNOWFLAKE_JWT)
echo ============================================================
uv run python demo.py keypair_bytes
echo.
pause

echo.
echo ============================================================
echo  Scenario 4 of 8 - OAuth access token  (oauth)
echo ============================================================
uv run python demo.py oauth_token
echo.
pause

echo.
echo ============================================================
echo  Scenario 5 of 8 - Browser SSO  (externalbrowser)  [opt-in: SF_BROWSER_SSO_ENABLED=1]
echo ============================================================
uv run python demo.py browser_sso
echo.
pause

echo.
echo ============================================================
echo  Scenario 6 of 8 - Okta native SSO  (SAML, no browser)
echo ============================================================
uv run python demo.py okta
echo.
pause

echo.
echo ============================================================
echo  Scenario 7 of 8 - MFA / Duo  (username_password_mfa)  [opt-in: SF_MFA_ENABLED=1]
echo ============================================================
uv run python demo.py mfa
echo.
pause

echo.
echo ============================================================
echo  Scenario 8 of 8 - OAuth client credentials  (machine-to-machine)
echo ============================================================
uv run python demo.py oauth_client_credentials
echo.
pause

echo.
echo ============================================================
echo  All 8 scenarios complete.
echo  SKIP = missing env vars   INFO = connected successfully
echo ============================================================
