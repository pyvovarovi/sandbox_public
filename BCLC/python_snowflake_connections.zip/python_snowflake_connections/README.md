# Snowflake Connector

Typed Python wrapper around `snowflake-connector-python` supporting all 8 authentication methods.
Uses [UV](https://docs.astral.sh/uv/) for package management.

---

## Features

- **8 authentication types** — password, key-pair (file & bytes), OAuth token, browser SSO, Okta native SSO, MFA, OAuth client credentials
- **Full type hints** on every method and variable
- **`**kwargs` passthrough** — any `snowflake.connector.connect()` parameter can be forwarded
- **Logger everywhere** — sensitive values (`password`, `token`, `private_key`, etc.) are masked automatically; no `print()` calls
- **Context manager** support — connections close automatically on exit
- **Demo runner** — `demo.bat` walks through all 8 scenarios one by one with a pause after each

---

## Project Structure

```
claude_snowflake/
├── src/
│   └── snowflake_connector/
│       ├── __init__.py          # re-exports SnowflakeConnection
│       └── connection.py        # main class — 8 factory methods
├── demo.py                      # demo runner (all 8 scenarios)
├── demo.bat                     # uv sync + runs each scenario with pause
├── pyproject.toml               # UV project manifest
├── uv.lock                      # dependency lockfile
├── .env.example                 # env var template (committed)
├── .env.demo                    # fake credentials for smoke-testing (committed)
└── prompt/
    └── conversation.md          # session log
```

---

## Quick Start

### Option A — Smoke-test with fake credentials (no Snowflake account needed)

`.env.demo` contains pre-filled fictitious credentials. Connections will fail at the network
level — that is intentional. Use this to verify the demo runner, auth flow logic, and logging
work correctly without any real account.

```bat
REM 1. Copy fake credentials
copy .env.demo .env

REM 2. Run all 8 scenarios (pauses after each)
demo.bat
```

**Expected results with `.env.demo`:**

| # | Scenario | Result |
|---|----------|--------|
| 1 | Password | Fails — fake account rejected by Snowflake |
| 2 | Key-pair (file) | Skips — `demo_rsa_key.p8` does not exist |
| 3 | Key-pair (bytes) | Skips — same file missing |
| 4 | OAuth token | Fails — fake token rejected |
| 5 | Browser SSO | Skips — `SF_BROWSER_SSO_ENABLED=0` |
| 6 | Okta native SSO | Fails — fake Okta URL unreachable |
| 7 | MFA | Skips — `SF_MFA_ENABLED=0` |
| 8 | OAuth client creds | Fails — fake token endpoint unreachable |

All failures are caught and logged — `demo.py` always exits with code `0`.

### Option B — Real Snowflake account

```bat
REM 1. Copy the template and fill in your real credentials
copy .env.example .env
REM    Edit .env — set SF_ACCOUNT, SF_USER, SF_PASSWORD (and others as needed)

REM 2. Run the demo
demo.bat
```

### Run a single scenario

```bat
uv run python demo.py password
uv run python demo.py keypair_file
uv run python demo.py keypair_bytes
uv run python demo.py oauth_token
uv run python demo.py browser_sso
uv run python demo.py okta
uv run python demo.py mfa
uv run python demo.py oauth_client_credentials
```

---

## Authentication Types

### 1. Password
```python
from src.snowflake_connector import SnowflakeConnection

with SnowflakeConnection.from_password(
    account="xy12345.us-east-1",
    user="alice",
    password="s3cr3t",
    warehouse="COMPUTE_WH",
    database="MY_DB",
    schema="PUBLIC",
) as conn:
    with conn.cursor() as cur:
        cur.execute("SELECT CURRENT_VERSION()")
        print(cur.fetchone())
```

### 2. Key-pair — file path
```python
with SnowflakeConnection.from_keypair_file(
    account="xy12345.us-east-1",
    user="svc_account",
    private_key_file="/path/to/rsa_key.p8",
    private_key_file_pwd="key_passphrase",   # omit if unencrypted
    warehouse="COMPUTE_WH",
) as conn: ...
```

### 3. Key-pair — in-memory DER bytes
```python
from cryptography.hazmat.primitives.serialization import (
    Encoding, NoEncryption, PrivateFormat, load_pem_private_key,
)

with open("rsa_key.p8", "rb") as f:
    key = load_pem_private_key(f.read(), password=b"passphrase")
der = key.private_bytes(Encoding.DER, PrivateFormat.PKCS8, NoEncryption())

with SnowflakeConnection.from_keypair_bytes(
    account="xy12345.us-east-1",
    user="svc_account",
    private_key=der,
) as conn: ...
```

### 4. OAuth — pre-obtained access token
```python
with SnowflakeConnection.from_oauth_token(
    account="xy12345.us-east-1",
    user="alice",
    token="eyJhbGciOiJSUzI1NiIs...",
) as conn: ...
```

### 5. Browser SSO (externalbrowser)
```python
# Opens a browser window — interactive environments only
with SnowflakeConnection.from_browser_sso(
    account="xy12345.us-east-1",
    user="alice",
) as conn: ...
```

### 6. Okta native SSO
```python
# No browser — uses Okta credentials directly
with SnowflakeConnection.from_okta(
    account="xy12345.us-east-1",
    user="alice@mycompany.com",
    password="okta_password",
    okta_url="https://mycompany.okta.com",
) as conn: ...
```

### 7. MFA / Duo
```python
# Triggers a Duo push (passcode=None) or accepts a TOTP code
with SnowflakeConnection.from_mfa(
    account="xy12345.us-east-1",
    user="alice",
    password="s3cr3t",
    passcode="123456",   # omit to use Duo push
) as conn: ...
```

### 8. OAuth client credentials (machine-to-machine)
```python
with SnowflakeConnection.from_oauth_client_credentials(
    account="xy12345.us-east-1",
    user="svc_account",
    oauth_client_id="0oa1b2c3d4e5f6g7h8i9",
    oauth_client_secret="abc123secret",
    oauth_token_request_url="https://myidp.okta.com/oauth2/v1/token",
    oauth_scope="session:role:MYROLE",
) as conn: ...
```

---

## Common `**kwargs`

All factory methods forward extra keyword arguments to `snowflake.connector.connect()`:

| Parameter | Type | Description |
|-----------|------|-------------|
| `warehouse` | `str` | Default warehouse |
| `database` | `str` | Default database |
| `schema` | `str` | Default schema |
| `role` | `str` | Default role |
| `login_timeout` | `int` | Login timeout in seconds (default 120) |
| `network_timeout` | `int` | Network timeout in seconds |
| `client_session_keep_alive` | `bool` | Keep session alive between queries |
| `session_parameters` | `dict` | Snowflake session parameters |

---

## Environment Variables

Configure via a `.env` file at the project root. See [.env.example](.env.example) for the full
list. Use [.env.demo](.env.demo) for a pre-filled fake-credential file to test the demo runner.

| Variable | Used by |
|----------|---------|
| `SF_ACCOUNT` | All scenarios |
| `SF_USER` | All scenarios |
| `SF_WAREHOUSE` | All scenarios (optional) |
| `SF_PASSWORD` | Scenarios 1, 6, 7 |
| `SF_PRIVATE_KEY_FILE` | Scenarios 2, 3 |
| `SF_PRIVATE_KEY_FILE_PWD` | Scenarios 2, 3 (optional) |
| `SF_OAUTH_TOKEN` | Scenario 4 |
| `SF_BROWSER_SSO_ENABLED` | Scenario 5 (set `1` to enable) |
| `SF_OKTA_URL` | Scenario 6 |
| `SF_MFA_ENABLED` | Scenario 7 (set `1` to enable) |
| `SF_MFA_PASSCODE` | Scenario 7 (optional) |
| `SF_OAUTH_CLIENT_ID` | Scenario 8 |
| `SF_OAUTH_CLIENT_SECRET` | Scenario 8 |
| `SF_OAUTH_TOKEN_REQUEST_URL` | Scenario 8 |
| `SF_OAUTH_SCOPE` | Scenario 8 (optional) |

---

## Running a Single Scenario

```bat
uv run python demo.py password
uv run python demo.py keypair_file
uv run python demo.py keypair_bytes
uv run python demo.py oauth_token
uv run python demo.py browser_sso
uv run python demo.py okta
uv run python demo.py mfa
uv run python demo.py oauth_client_credentials
```

---

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `snowflake-connector-python` | ≥4.3.0 | Snowflake Python connector |
| `python-dotenv` | ≥1.2.2 | Load `.env` files |
| `cryptography` | ≥46.0.5 | Load/decrypt PEM private keys for key-pair auth |

Install / sync:
```bat
uv sync
```

---

## GitHub Repository

https://github.com/pyvovarovi/claude_snowflake
