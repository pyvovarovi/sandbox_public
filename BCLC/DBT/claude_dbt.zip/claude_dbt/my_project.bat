@echo off
setlocal

set PROJECT=my_project
set BASE_DIR=%~dp0%PROJECT%
set SCRIPT=%~dp0my_project_setup.ps1
set DBT=%~dp0.venv\Scripts\dbt.exe

echo ============================================================
echo  dbt my_project — default example models with DuckDB
echo ============================================================

:: ── pre-flight: dbt ──────────────────────────────────────────
where dbt >nul 2>&1 || (
    echo ERROR: dbt not found. Run install_dbt.bat first.
    pause & exit /b 1
)

:: ── pre-flight: duckdb CLI ───────────────────────────────────
where duckdb >nul 2>&1
if errorlevel 1 (
    echo DuckDB CLI not found. Installing via winget...
    winget install --id DuckDB.cli --silent --accept-package-agreements --accept-source-agreements
    for /f "tokens=*" %%i in ('powershell -NoProfile -Command "[System.Environment]::GetEnvironmentVariable(\"PATH\",\"Machine\")+\";\" + [System.Environment]::GetEnvironmentVariable(\"PATH\",\"User\")"') do set "PATH=%%i"
)

:: ─────────────────────────────────────────────────────────────
echo.
echo [1/5] Checking dbt project folder...
:: ─────────────────────────────────────────────────────────────
if exist "%BASE_DIR%" (
    echo   Folder already exists — skipping dbt init.
) else (
    "%DBT%" init %PROJECT% --skip-profile-setup
)

:: ─────────────────────────────────────────────────────────────
echo.
echo [2/5] Writing profiles.yml + patching dbt_project.yml...
:: ─────────────────────────────────────────────────────────────
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -BaseDir "%BASE_DIR%" -Project "%PROJECT%"
if errorlevel 1 ( echo ERROR: setup script failed. & pause & exit /b 1 )

:: ─────────────────────────────────────────────────────────────
echo.
echo [3/5] dbt debug...
:: ─────────────────────────────────────────────────────────────
cd /d "%BASE_DIR%"
echo -- dbt debug --
"%DBT%" debug --profiles-dir . --no-version-check
pause

:: ─────────────────────────────────────────────────────────────
echo.
echo [4/5] dbt run + test + docs generate...
:: ─────────────────────────────────────────────────────────────
echo -- dbt run --
"%DBT%" run --profiles-dir . --no-version-check
pause

echo.
echo -- dbt test --
"%DBT%" test --profiles-dir . --no-version-check
pause

echo.
echo -- dbt docs generate --
"%DBT%" docs generate --profiles-dir . --no-version-check
pause

:: ─────────────────────────────────────────────────────────────
echo.
echo [5/5] Query results...
:: ─────────────────────────────────────────────────────────────
echo   my_first_dbt_model (2 rows — id 1 and NULL):
duckdb "%BASE_DIR%\demo.duckdb" "SELECT * FROM my_first_dbt_model ORDER BY id;"
pause

echo.
echo   my_second_dbt_model (1 row — NULL filtered out):
duckdb "%BASE_DIR%\demo.duckdb" "SELECT * FROM my_second_dbt_model ORDER BY id;"
pause

echo.
echo ============================================================
echo  Done!
echo   Project  : %BASE_DIR%
echo   Database : %BASE_DIR%\demo.duckdb
echo   Models   : my_first_dbt_model (table), my_second_dbt_model (view)
echo   Docs     : cd %PROJECT% ^& "%DBT%" docs serve --profiles-dir .
echo ============================================================
echo.

endlocal
pause
