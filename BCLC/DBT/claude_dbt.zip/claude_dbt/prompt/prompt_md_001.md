# dbt SCD2 Demo — DuckDB (dbt_demo_duckdb_scd2)

Session: 2026-03-22

---

## Issues fixed

### 1. `dim_customers` table not found (step 6 ran before dbt run)
`dim_customers` is a dbt model that only exists after `dbt run`, but it was queried in step 6 before step 7's `dbt run`.
- **Fix:** replaced the `dim_customers` query in step 6 with an inline query against `snap_customers WHERE dbt_valid_to IS NULL`.

### 2. `dbt_project.yml` warning — unused config path `models.dbt_demo_duckdb_scd2.example`
`dbt init` generates an `example:` block in `dbt_project.yml`; setup script deleted the `example/` folder but left the config.
- **Fix:** `dbt_demo_duckdb_scd2_setup.ps1` now patches `dbt_project.yml` to remove the stale `example:` block via regex.

### 3. Setup script: `$utf8` was null when used
`[System.IO.File]::WriteAllText` was called before `$utf8 = New-Object System.Text.UTF8Encoding $false` was defined.
- **Fix:** moved `$utf8` definition and `wf` helper function above the patch block in `dbt_demo_duckdb_scd2_setup.ps1`.

### 4. `Could not find profile named 'my_project'` — wrong working directory
`set BASE_DIR=%CD%\%PROJECT%` used `%CD%` (launch directory), so running the bat from a different folder pointed dbt at the wrong `dbt_project.yml`.
- **Fix:** changed to `set BASE_DIR=%~dp0%PROJECT%` (bat file's own directory) in `dbt_demo_duckdb_scd2.bat`.

---

## New files created

### `my_project.bat`
Runs the default `dbt init` example project (`my_project/`) with DuckDB.
Steps: pre-flight → setup PS1 → dbt debug → dbt run → dbt test → dbt docs generate → query results.

### `my_project_setup.ps1`
Writes `profiles.yml` for `my_project` and patches `dbt_project.yml` to remove the `example:` config block.

### `my_project/.vscode/settings.json`
```json
{ "dbt.profilesDir": "${workspaceFolder}" }
```
**Why this is needed:**
`profiles.yml` existed and was correct, but the error came from the **dbt VS Code extension (LSP)**, not from the bat file.
The extension looks for profiles in `~/.dbt/profiles.yml` by default — it has no knowledge of the `--profiles-dir .` flag used in the bat file (that flag only applies to the dbt CLI).
Setting `dbt.profilesDir` to `${workspaceFolder}` tells the extension to look for `profiles.yml` in the project folder instead of the global default.
Open VS Code with `my_project/` as the workspace root for this setting to take effect.

---

## `my_project` — test failure resolved
`not_null_my_first_dbt_model_id` failed because `my_first_dbt_model.sql` intentionally inserts `SELECT NULL AS id`.
- **Fix:** uncommented `where id is not null` in [my_project/models/example/my_first_dbt_model.sql](../my_project/models/example/my_first_dbt_model.sql).

---

## `.gitignore` — dbt artifacts added
Added standard dbt ignores:
```
target/
dbt_packages/
logs/
```
`target/` covers `manifest.json`, `catalog.json`, `run_results.json`, and compiled SQL.
`*.duckdb` already existed and covers all database files.
