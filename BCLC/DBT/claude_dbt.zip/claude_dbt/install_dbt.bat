@echo off
setlocal

echo ============================================================
echo  Install dbt packages via uv
echo ============================================================

:: ── Prerequisites: ODBC driver + C++ Build Tools ─────────────
echo.
echo [1/4] Installing prerequisites...

winget install --id Microsoft.ODBCDriver18forSQLServer --silent --accept-package-agreements --accept-source-agreements
if errorlevel 1 echo WARNING: ODBC Driver install failed. Download from: https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server

:: C++ Build Tools required by pyodbc (dbt-sqlserver dependency)
winget install --id Microsoft.VisualStudio.2022.BuildTools --silent --accept-package-agreements --accept-source-agreements
if errorlevel 1 echo WARNING: Build Tools install failed. pyodbc may not compile.

:: ── dbt core + adapters (uv tool — global CLI) ───────────────
echo.
echo [2/4] Installing dbt-core with adapters (global tool)...

uv tool install --with dbt-snowflake --with dbt-sqlserver --with dbt-duckdb dbt-core

:: ── dbt adapters (uv add — project dependencies) ─────────────
echo.
echo [3/4] Adding dbt adapters to project via uv add...

uv add dbt-core dbt-snowflake dbt-duckdb

:: dbt-sqlserver requires pyodbc (C++ build); add separately so failures don't block others
uv add dbt-sqlserver
if errorlevel 1 echo WARNING: dbt-sqlserver failed. Ensure Visual C++ Build Tools are installed, then re-run: uv add dbt-sqlserver

:: ── Add uv tools bin to PATH ──────────────────────────────────
echo.
echo [4/4] Adding uv tools bin to PATH...

for /f "delims=" %%i in ('uv tool dir --bin 2^>nul') do set "UV_BIN=%%i"

if not defined UV_BIN (
    echo WARNING: Could not determine uv tools bin directory.
    goto :done
)

echo uv tools bin: %UV_BIN%

powershell -NoProfile -Command "$bin='%UV_BIN%'; $p=[System.Environment]::GetEnvironmentVariable('PATH','User'); if ($p -notlike ('*'+$bin+'*')) { [System.Environment]::SetEnvironmentVariable('PATH',$p+';'+$bin,'User'); Write-Host 'PATH updated.' } else { Write-Host 'Already in PATH.' }"

set "PATH=%PATH%;%UV_BIN%"

:done
echo.
echo [Done] Open a new terminal, then verify with: dbt --version
echo.

endlocal
pause
