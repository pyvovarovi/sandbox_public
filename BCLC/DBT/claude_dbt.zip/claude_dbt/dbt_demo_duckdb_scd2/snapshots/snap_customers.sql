{% snapshot snap_customers %}

{{
    config(
        target_schema='main',
        unique_key='id',
        strategy='timestamp',
        updated_at='updated_at',
    )
}}

select
    id,
    name,
    email,
    city,
    plan,
    updated_at
from {{ source('raw', 'raw_customers') }}

{% endsnapshot %}