-- Staging layer: light rename / cast on the raw source.
-- NOTE: this reflects the CURRENT state of raw_customers.
--       For full history, query snap_customers directly.
with source as (
    select * from {{ source('raw', 'raw_customers') }}
)
select
    id          as customer_id,
    name,
    email,
    city,
    plan,
    updated_at
from source