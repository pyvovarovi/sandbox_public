-- Current-state dimension built on top of the SCD2 snapshot.
-- Filters to active rows only (dbt_valid_to IS NULL).
-- Join snap_customers directly when you need historical versions.
with snapshot as (
    select * from {{ ref('snap_customers') }}
)
select
    id                  as customer_id,
    name,
    email,
    city,
    plan,
    dbt_valid_from      as effective_from,
    dbt_scd_id          as scd_key
from snapshot
where dbt_valid_to is null