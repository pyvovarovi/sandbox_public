@echo off
setlocal

set PROJECT=dbt_demo_duckdb_scd2
set BASE_DIR=%~dp0%PROJECT%
set SCRIPT=%~dp0dbt_demo_duckdb_scd2_setup.ps1
set DBT=%~dp0.venv\Scripts\dbt.exe

echo ============================================================
echo  dbt SCD2 Demo Project with DuckDB
echo  Slowly Changing Dimensions Type 2 via dbt Snapshots
echo ============================================================

:: ── pre-flight: dbt ──────────────────────────────────────────
where dbt >nul 2>&1 || (
    echo ERROR: dbt not found. Run install_dbt.bat first.
    pause & exit /b 1
)

:: ── pre-flight: duckdb CLI ───────────────────────────────────
where duckdb >nul 2>&1
if errorlevel 1 (
    echo DuckDB CLI not found. Installing via winget...
    winget install --id DuckDB.cli --silent --accept-package-agreements --accept-source-agreements
    for /f "tokens=*" %%i in ('powershell -NoProfile -Command "[System.Environment]::GetEnvironmentVariable(\"PATH\",\"Machine\")+\";\" + [System.Environment]::GetEnvironmentVariable(\"PATH\",\"User\")"') do set "PATH=%%i"
)

:: ─────────────────────────────────────────────────────────────
echo.
echo [1/7] Initialising dbt project...
:: ─────────────────────────────────────────────────────────────
if exist "%BASE_DIR%" (
    echo   Folder already exists — skipping dbt init.
) else (
    "%DBT%" init %PROJECT% --skip-profile-setup
)

:: ─────────────────────────────────────────────────────────────
echo.
echo [2/7] Writing profiles.yml + models + snapshots (via setup script)...
:: ─────────────────────────────────────────────────────────────
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -BaseDir "%BASE_DIR%" -Project "%PROJECT%"
if errorlevel 1 ( echo ERROR: setup script failed. & pause & exit /b 1 )

:: ─────────────────────────────────────────────────────────────
echo.
echo [3/7] Loading INITIAL raw customer data (Day 0 — 5 customers)...
:: ─────────────────────────────────────────────────────────────
duckdb "%BASE_DIR%\demo.duckdb" "CREATE OR REPLACE TABLE raw_customers (id INTEGER PRIMARY KEY, name VARCHAR, email VARCHAR, city VARCHAR, plan VARCHAR, updated_at TIMESTAMP); INSERT INTO raw_customers VALUES (1,'Alice Smith','alice@example.com','New York','free','2024-01-01 09:00:00'),(2,'Bob Jones','bob@example.com','Chicago','pro','2024-01-01 09:00:00'),(3,'Carol White','carol@example.com','Houston','free','2024-01-01 09:00:00'),(4,'Dave Brown','dave@example.com','Phoenix','enterprise','2024-01-01 09:00:00'),(5,'Eve Davis','eve@example.com','Seattle','pro','2024-01-01 09:00:00');"

echo   Initial raw_customers:
duckdb "%BASE_DIR%\demo.duckdb" "SELECT id, name, city, plan, updated_at FROM raw_customers ORDER BY id;"

:: ─────────────────────────────────────────────────────────────
echo.
echo [4/7] dbt debug + dbt snapshot LOAD 1 (initial snapshot — all 5 rows current)...
:: ─────────────────────────────────────────────────────────────
cd /d "%BASE_DIR%"

echo -- dbt debug --
"%DBT%" debug --profiles-dir . --no-version-check
pause

echo.
echo -- dbt snapshot (Load 1) --
echo    All 5 rows inserted. dbt_valid_to = NULL for every row (all current).
"%DBT%" snapshot --profiles-dir . --no-version-check
pause

echo.
echo   snap_customers after LOAD 1 — 5 rows, all active (dbt_valid_to IS NULL):
duckdb "%BASE_DIR%\demo.duckdb" "SELECT id, name, city, plan, dbt_valid_from, dbt_valid_to FROM snap_customers ORDER BY id, dbt_valid_from;"
pause

:: ─────────────────────────────────────────────────────────────
echo.
echo [5/7] Simulating source-system changes (Day 30)...
echo   Alice  : plan  free  -^> pro
echo   Carol  : city  Houston -^> Austin
echo   Eve    : email updated + plan pro -^> enterprise
:: ─────────────────────────────────────────────────────────────
duckdb "%BASE_DIR%\demo.duckdb" "UPDATE raw_customers SET plan='pro', updated_at='2024-02-01 10:00:00' WHERE id=1; UPDATE raw_customers SET city='Austin', updated_at='2024-02-01 11:00:00' WHERE id=3; UPDATE raw_customers SET email='eve.davis@example.com', plan='enterprise', updated_at='2024-02-01 12:00:00' WHERE id=5;"

echo   raw_customers after updates (id 1, 3, 5 changed):
duckdb "%BASE_DIR%\demo.duckdb" "SELECT id, name, city, plan, email, updated_at FROM raw_customers ORDER BY id;"
pause

:: ─────────────────────────────────────────────────────────────
echo.
echo [6/7] dbt snapshot LOAD 2 (SCD2 kicks in)...
echo   Expect: 3 old rows expire (dbt_valid_to set), 3 new rows inserted.
echo   Total rows = 8 (5 original + 3 new versions).
:: ─────────────────────────────────────────────────────────────
echo -- dbt snapshot (Load 2) --
"%DBT%" snapshot --profiles-dir . --no-version-check
pause

echo.
echo   snap_customers full SCD2 history (8 rows — expired rows have dbt_valid_to set):
duckdb "%BASE_DIR%\demo.duckdb" "SELECT id, name, city, plan, email, CAST(dbt_valid_from AS VARCHAR) AS valid_from, CAST(dbt_valid_to AS VARCHAR) AS valid_to FROM snap_customers ORDER BY id, dbt_valid_from;"
pause

echo.
echo   Current records only (dbt_valid_to IS NULL — 5 active rows):
duckdb "%BASE_DIR%\demo.duckdb" "SELECT id, name, city, plan, email, CAST(dbt_valid_from AS VARCHAR) AS valid_from FROM snap_customers WHERE dbt_valid_to IS NULL ORDER BY id;"
pause

echo.
echo   Historical query — what was Alice's plan BEFORE the change?
duckdb "%BASE_DIR%\demo.duckdb" "SELECT id, name, plan, dbt_valid_from, dbt_valid_to FROM snap_customers WHERE id = 1 ORDER BY dbt_valid_from;"
pause

:: ─────────────────────────────────────────────────────────────
echo.
echo [7/7] Running dbt run + test + docs generate...
:: ─────────────────────────────────────────────────────────────
echo -- dbt run --
"%DBT%" run --profiles-dir . --no-version-check
pause

echo.
echo   dim_customers model (current records only, built by dbt run):
duckdb "%BASE_DIR%\demo.duckdb" "SELECT * FROM dim_customers ORDER BY customer_id;"
pause

echo.
echo -- dbt test --
"%DBT%" test --profiles-dir . --no-version-check
pause

echo.
echo -- dbt docs generate --
"%DBT%" docs generate --profiles-dir . --no-version-check
pause

echo.
echo ============================================================
echo  Done!
echo   Project  : %BASE_DIR%
echo   Database : %BASE_DIR%\demo.duckdb
echo.
echo   SCD2 Objects:
echo     snap_customers   -- snapshot: full history with dbt_valid_from/to
echo     dim_customers    -- model:    current-state view (dbt_valid_to IS NULL)
echo.
echo   Key SCD2 columns added by dbt:
echo     dbt_scd_id      surrogate key for each historical row
echo     dbt_valid_from  when this version became active
echo     dbt_valid_to    when this version expired (NULL = still current)
echo     dbt_updated_at  source updated_at at time of snapshot
echo.
echo   Serve docs: cd %PROJECT% ^& "%DBT%" docs serve --profiles-dir .
echo ============================================================
echo.

endlocal
pause
