https://docs.getdbt.com/docs/local/install-dbt?version=2.0&installation=windows#installation

C:\Users\user>dbt --version
Core:
  - installed: 1.11.7
  - latest:    1.11.7 - Up to date!

