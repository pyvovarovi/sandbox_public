# dbt Demo — DuckDB

End-to-end dbt demo project using DuckDB as the local database engine.
Runs entirely on a single machine with no cloud credentials required.

---

## Files

| File | Purpose |
|------|---------|
| `dbt_demo_duckdb.bat` | Main orchestrator — runs all steps in sequence |
| `dbt_demo_duckdb_setup.ps1` | Writes project files (profiles, models, schema) as UTF-8 without BOM |
| `dbt_demo_duckdb/demo.duckdb` | DuckDB database file (created at runtime) |
| `dbt_demo_duckdb/profiles.yml` | dbt connection profile (local to project, not `~/.dbt/`) |

---

## Prerequisites

| Tool | How to install |
|------|---------------|
| dbt-core + dbt-duckdb | `c:\claude_dbt\.venv\Scripts\dbt.exe` (installed via `uv`) |
| DuckDB CLI | `winget install DuckDB.cli` |
| PowerShell 5+ | Built into Windows |

> The bat uses `%~dp0.venv\Scripts\dbt.exe` explicitly to avoid picking up
> **dbt-fusion** (the VS Code extension binary), which does not support `dbt docs`.

---

## Steps Executed by `dbt_demo_duckdb.bat`

### Step 1 — Initialise dbt Project
```bat
dbt init dbt_demo_duckdb --skip-profile-setup
```
Skipped if the folder already exists. Creates the standard dbt project scaffold
(`dbt_project.yml`, `models/`, `tests/`, etc.).

---

### Step 2 — Write Project Files (via setup script)
```bat
powershell -ExecutionPolicy Bypass -File dbt_demo_duckdb_setup.ps1 -BaseDir ... -Project ...
```
The PowerShell script writes all files as **UTF-8 without BOM** using
`System.IO.File::WriteAllText` (PowerShell 5.x `Set-Content -Encoding UTF8`
adds a BOM that breaks dbt-fusion's SQL parser).

Files written:

| File | Description |
|------|-------------|
| `profiles.yml` | DuckDB connection — type `duckdb`, path `demo.duckdb`, 4 threads |
| `models/sources.yml` | Declares `raw.raw_customers` and `raw.raw_orders` with `unique`/`not_null` tests |
| `models/stg_customers.sql` | Staging view — renames `id → customer_id`, concatenates `full_name` |
| `models/stg_orders.sql` | Staging view — renames `id → order_id` |
| `models/fct_orders.sql` | Fact view — joins orders to customers |
| `models/mart_customers.sql` | Mart view — aggregates per customer (totals, lifetime value) |
| `models/schema.yml` | Model-level `unique`/`not_null` tests for all 4 models |

---

### Step 3 — Create Demo Data (DuckDB CLI)

Two raw tables are created directly in `demo.duckdb`:

#### `raw_customers` — 5 rows
| id | first_name | last_name | email | created_at |
|----|-----------|-----------|-------|------------|
| 1 | Alice | Smith | alice@example.com | 2023-01-10 |
| 2 | Bob | Jones | bob@example.com | 2023-02-14 |
| 3 | Carol | White | carol@example.com | 2023-03-05 |
| 4 | Dave | Brown | dave@example.com | 2023-04-20 |
| 5 | Eve | Davis | eve@example.com | 2023-05-30 |

#### `raw_orders` — 8 rows
| id | customer_id | amount | status | order_date |
|----|-------------|--------|--------|------------|
| 1 | 1 | 100.00 | completed | 2024-01-01 |
| 2 | 1 | 200.00 | completed | 2024-02-01 |
| 3 | 2 | 150.00 | shipped | 2024-01-15 |
| 4 | 3 | 75.00 | pending | 2024-03-01 |
| 5 | 4 | 300.00 | completed | 2024-01-20 |
| 6 | 2 | 50.00 | completed | 2024-02-10 |
| 7 | 5 | 420.00 | shipped | 2024-03-15 |
| 8 | 1 | 90.00 | pending | 2024-04-01 |

---

### Step 4 — Run dbt

All commands use `--profiles-dir .` (profiles.yml lives inside the project folder).

```bash
dbt debug    # verify connection
dbt run      # build all 4 views
dbt test     # run 14 data tests
dbt docs generate  # write catalog.json to target/
```

**Model execution order** (resolved from `ref()` dependencies):

```
raw_customers  ──┐
                  ├── stg_customers ──┐
raw_orders     ──┤                    ├── fct_orders ── mart_customers
                  └── stg_orders  ────┘
```

**Test results:** 14 tests across 4 models + 2 sources — all pass on demo data.

---

### Step 5 — Query mart_customers

```sql
SELECT * FROM mart_customers ORDER BY lifetime_value DESC;
```

Expected output:

| customer_id | full_name | total_orders | lifetime_value | completed_revenue |
|-------------|-----------|-------------|----------------|-------------------|
| 1 | Alice Smith | 3 | 390.00 | 300.00 |
| 5 | Eve Davis | 1 | 420.00 | 0.00 |
| 4 | Dave Brown | 1 | 300.00 | 300.00 |
| 2 | Bob Jones | 2 | 200.00 | 50.00 |
| 3 | Carol White | 1 | 75.00 | 0.00 |

---

## After Running

**Browse docs in browser:**
```bat
cd dbt_demo_duckdb
c:\claude_dbt\.venv\Scripts\dbt.exe docs serve --profiles-dir .
```
Opens at `http://localhost:8080` — includes lineage DAG, model descriptions, and test results.

**Query the database directly:**
```bat
duckdb dbt_demo_duckdb\demo.duckdb
```

**Re-run from scratch:**
Delete `dbt_demo_duckdb\demo.duckdb` and re-run the bat — the setup script uses
`CREATE OR REPLACE TABLE` so existing data is always replaced.

---

## Known Issues & Fixes Applied

| Issue | Cause | Fix |
|-------|-------|-----|
| `'dbt' is not recognized` | `uv tool` bin not in PATH | Use full path `%~dp0.venv\Scripts\dbt.exe` |
| `error: unrecognized subcommand 'docs'` | dbt-fusion picked up instead of dbt-core | Explicit venv path bypasses fusion binary |
| `extraneous input '﻿'` (BOM error) | PowerShell 5.x adds UTF-8 BOM | Use `System.IO.File::WriteAllText` with `UTF8Encoding($false)` |
| `pyodbc build failed` | Missing MSVC build tools | dbt-sqlserver requires Visual C++ Build Tools or pre-built wheel |
| `No package found: DuckDB.DuckDB` | Wrong winget ID | Correct ID is `DuckDB.cli` |
