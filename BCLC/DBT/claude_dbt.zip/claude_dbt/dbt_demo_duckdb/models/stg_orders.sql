with source as (
    select * from {{ source('raw', 'raw_orders') }}
)
select
    id          as order_id,
    customer_id,
    amount,
    status,
    order_date
from source