with orders as (
    select * from {{ ref('fct_orders') }}
)
select
    customer_id,
    full_name,
    email,
    count(*)                                                    as total_orders,
    sum(amount)                                                 as lifetime_value,
    min(order_date)                                             as first_order_date,
    max(order_date)                                             as latest_order_date,
    sum(case when status = 'completed' then amount else 0 end)  as completed_revenue
from orders
group by customer_id, full_name, email