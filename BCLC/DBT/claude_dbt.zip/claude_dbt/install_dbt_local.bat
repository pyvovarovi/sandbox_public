@echo off
setlocal enabledelayedexpansion

echo ============================================================
echo  Install dbt on local computer (system Python + pip)
echo ============================================================

:: ── [0/4] Check for dbt-fusion conflict ─────────────────────
echo.
echo [0/4] Checking for dbt-fusion conflict...
for /f "tokens=*" %%v in ('dbt --version 2^>^&1') do set "DBT_VER=%%v"
echo %DBT_VER% | findstr /i "dbt-fusion" >nul
if not errorlevel 1 (
    echo.
    echo   WARNING: dbt-fusion detected: %DBT_VER%
    echo   dbt-fusion ^(dbt Labs preview^) conflicts with dbt-core.
    echo   You must uninstall it before installing dbt-core adapters.
    echo.
    set /p UNINSTALL=   Uninstall dbt-fusion now? [Y/N]:
    if /i "!UNINSTALL!"=="Y" (
        echo   Uninstalling dbt-fusion...
        %PY% -m pip uninstall dbt-fusion -y 2>nul
        winget uninstall --id dbt-labs.dbt-fusion --silent 2>nul
        echo   dbt-fusion removed. Continuing...
    ) else (
        echo   Aborted. Uninstall dbt-fusion manually, then re-run this script.
        pause & exit /b 1
    )
) else (
    echo   OK — dbt-fusion not detected.
)

:: ── [1/4] Python 3.12 (dbt requires <= 3.12) ─────────────────
echo.
echo [1/4] Checking Python 3.12...
echo   NOTE: dbt-core requires Python 3.8-3.12. Python 3.13+ is not supported.

:: Prefer py launcher to get exactly 3.12
set "PY="
py -3.12 --version >nul 2>&1
if not errorlevel 1 (
    set "PY=py -3.12"
    for /f "tokens=*" %%v in ('py -3.12 --version 2^>^&1') do echo   Found: %%v
) else (
    echo   Python 3.12 not found — installing via winget...
    winget install --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo ERROR: Python 3.12 install failed.
        pause & exit /b 1
    )
    for /f "tokens=*" %%i in ('powershell -NoProfile -Command "[System.Environment]::GetEnvironmentVariable(\"PATH\",\"Machine\")+\";\" + [System.Environment]::GetEnvironmentVariable(\"PATH\",\"User\")"') do set "PATH=%%i"
    set "PY=py -3.12"
    for /f "tokens=*" %%v in ('py -3.12 --version 2^>^&1') do echo   Installed: %%v
)

:: ── [2/4] Prerequisites (ODBC + C++ Build Tools) ─────────────
echo.
echo [2/4] Installing prerequisites...

winget install --id Microsoft.ODBCDriver18forSQLServer --silent --accept-package-agreements --accept-source-agreements
if errorlevel 1 echo   WARNING: ODBC Driver install failed (may already be installed — continuing).

winget install --id Microsoft.VisualStudio.2022.BuildTools --silent --accept-package-agreements --accept-source-agreements
if errorlevel 1 echo   WARNING: VS C++ Build Tools install failed (pyodbc / dbt-sqlserver may not compile).

:: ── [3/4] Install dbt via pip ────────────────────────────────
echo.
echo [3/4] Installing dbt adapters via pip...

%PY% -m pip install --upgrade pip
if errorlevel 1 echo   WARNING: pip upgrade failed — continuing with existing pip.

echo   Installing dbt-core, dbt-duckdb, dbt-snowflake...
%PY% -m pip install dbt-core dbt-duckdb dbt-snowflake
if errorlevel 1 ( echo ERROR: dbt install failed. & pause & exit /b 1 )

echo   Installing dbt-sqlserver...
%PY% -m pip install dbt-sqlserver --only-binary pyodbc
if errorlevel 1 echo   WARNING: dbt-sqlserver failed (no pre-built pyodbc wheel for this Python version — skipping).

:: ── [3b/4] Optional packages ─────────────────────────────────
echo.
echo [3b/4] Optional dbt ecosystem packages...
echo   (Press Y to install each, any other key to skip)
echo.

set "OPT_PKGS="

echo   elementary-data — observability dashboard + data alerts
set /p OPT1=  Install elementary-data? [Y/N]:
if /i "!OPT1!"=="Y" set "OPT_PKGS=!OPT_PKGS! elementary-data"

echo.
echo   dbt-osmosis — YAML management + model compilation workbench
set /p OPT2=  Install dbt-osmosis? [Y/N]:
if /i "!OPT2!"=="Y" set "OPT_PKGS=!OPT_PKGS! dbt-osmosis"

echo.
echo   dbt-meshify — automate dbt Mesh groups, contracts and access
set /p OPT3=  Install dbt-meshify? [Y/N]:
if /i "!OPT3!"=="Y" set "OPT_PKGS=!OPT_PKGS! dbt-meshify"

echo.
echo   re-data — data reliability framework
set /p OPT4=  Install re-data? [Y/N]:
if /i "!OPT4!"=="Y" set "OPT_PKGS=!OPT_PKGS! re-data"

if defined OPT_PKGS (
    echo.
    echo   Installing selected packages in one pass ^(resolves shared dependencies^):
    echo   %PY% -m pip install !OPT_PKGS!
    %PY% -m pip install !OPT_PKGS!
    if errorlevel 1 ( echo   WARNING: one or more optional packages failed. ) else ( echo   OK. )
) else (
    echo   No optional packages selected.
)

:: ── [4/4] Verify ─────────────────────────────────────────────
echo.
echo [4/4] Verifying installation...

:: Locate dbt.exe — check both system and user Scripts folders
for /f "tokens=*" %%p in ('%PY% -c "import sysconfig; print(sysconfig.get_path(\"scripts\"))" 2^>nul') do set "PY_SCRIPTS_SYS=%%p"
for /f "tokens=*" %%p in ('%PY% -c "import sysconfig; print(sysconfig.get_path(\"scripts\",\"nt_user\"))" 2^>nul') do set "PY_SCRIPTS_USR=%%p"

set "DBT_EXE="
if exist "%PY_SCRIPTS_SYS%\dbt.exe" set "DBT_EXE=%PY_SCRIPTS_SYS%\dbt.exe"
if exist "%PY_SCRIPTS_USR%\dbt.exe" set "DBT_EXE=%PY_SCRIPTS_USR%\dbt.exe"

if defined DBT_EXE (
    for /f "tokens=*" %%v in ('"%DBT_EXE%" --version 2^>^&1') do echo   %%v
    echo   Path: %DBT_EXE%
    :: Add the Scripts folder to PATH for the current session
    for %%d in ("%DBT_EXE%") do set "DBT_SCRIPTS=%%~dpd"
    set "PATH=!DBT_SCRIPTS!;%PATH%"
    :: Persist to user PATH permanently
    powershell -NoProfile -Command "$s='!DBT_SCRIPTS!'.TrimEnd('\'); $p=[System.Environment]::GetEnvironmentVariable('PATH','User'); if ($p -notlike ('*'+$s+'*')) { [System.Environment]::SetEnvironmentVariable('PATH',$p+';'+$s,'User'); Write-Host '  PATH updated permanently.' } else { Write-Host '  Already in user PATH.' }"
) else (
    echo   WARNING: dbt.exe not found in system or user Scripts.
    echo   System Scripts : %PY_SCRIPTS_SYS%
    echo   User   Scripts : %PY_SCRIPTS_USR%
    echo   Open a new terminal and verify: dbt --version
)

echo.
echo ============================================================
echo  Done!
echo   dbt installed to system Python (available globally).
echo   Open a new terminal, then verify: dbt --version
echo ============================================================
echo.

endlocal
pause
