@echo off
setlocal

echo ============================================================
echo  Install Requirements
echo ============================================================

:: ── winget packages ──────────────────────────────────────────
echo.
echo [1/3] Installing winget packages...

winget install --id SQLite.SQLite          --silent --accept-package-agreements --accept-source-agreements
winget install --id dbeaver.dbeaver        --silent --accept-package-agreements --accept-source-agreements
winget install --id astral-sh.uv           --silent --accept-package-agreements --accept-source-agreements

:: Refresh PATH so uv is available in the same session
call refreshenv 2>nul || (
    for /f "tokens=*" %%i in ('powershell -NoProfile -Command "[System.Environment]::GetEnvironmentVariable(\"PATH\",\"Machine\") + \";\" + [System.Environment]::GetEnvironmentVariable(\"PATH\",\"User\")"') do set "PATH=%%i"
)

:: ── dbt packages via uv ──────────────────────────────────────
echo.
echo [2/3] Installing dbt packages via uv...

uv tool install "dbt-core[snowflake]"
uv tool install dbt-snowflake
uv tool install dbt-sqlserver

:: ── VS Code extensions ───────────────────────────────────────
echo.
echo [3/3] Installing VS Code extensions...

code --install-extension innoverio.vscode-dbt-power-user
code --install-extension dbtlabsinc.dbt
code --install-extension dorzey.vscode-sqlfluff
code --install-extension samuelcolvin.jinjahtml

:: ── Add dbt (uv tools bin) to system PATH ───────────────────
echo.
echo [4/4] Adding dbt to system PATH...

:: uv places tool executables in %USERPROFILE%\.local\bin
set "UV_TOOLS_BIN=%USERPROFILE%\.local\bin"

:: Add permanently to the User PATH (no admin required)
powershell -NoProfile -Command ^
  "$p = [System.Environment]::GetEnvironmentVariable('PATH','User'); ^
   if ($p -notlike '*%UV_TOOLS_BIN%*') { ^
     [System.Environment]::SetEnvironmentVariable('PATH', $p + ';%UV_TOOLS_BIN%', 'User'); ^
     Write-Host 'PATH updated: %UV_TOOLS_BIN% added.' ^
   } else { Write-Host 'PATH already contains %UV_TOOLS_BIN% — skipped.' }"

:: Also apply to the current session
set "PATH=%PATH%;%UV_TOOLS_BIN%"

:: ── dbt project init ─────────────────────────────────────────
echo.
echo [Done] To initialise a new dbt project run:
echo   dbt init my_project
echo.

endlocal
pause
