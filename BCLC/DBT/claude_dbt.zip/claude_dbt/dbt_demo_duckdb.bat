@echo off
setlocal

set PROJECT=dbt_demo_duckdb
set BASE_DIR=%CD%\%PROJECT%
set SCRIPT=%~dp0dbt_demo_duckdb_setup.ps1
set DBT=%~dp0.venv\Scripts\dbt.exe

echo ============================================================
echo  dbt Demo Project with DuckDB
echo ============================================================

:: ── pre-flight: dbt ──────────────────────────────────────────
where dbt >nul 2>&1 || (
    echo ERROR: dbt not found. Run install_dbt.bat first.
    pause & exit /b 1
)

:: ── pre-flight: duckdb CLI ───────────────────────────────────
where duckdb >nul 2>&1
if errorlevel 1 (
    echo DuckDB CLI not found. Installing via winget...
    winget install --id DuckDB.cli --silent --accept-package-agreements --accept-source-agreements
    for /f "tokens=*" %%i in ('powershell -NoProfile -Command "[System.Environment]::GetEnvironmentVariable(\"PATH\",\"Machine\")+\";\" + [System.Environment]::GetEnvironmentVariable(\"PATH\",\"User\")"') do set "PATH=%%i"
)

:: ─────────────────────────────────────────────────────────────
echo.
echo [1/5] Initialising dbt project...
:: ─────────────────────────────────────────────────────────────
if exist "%BASE_DIR%" (
    echo   Folder already exists — skipping dbt init.
) else (
    "%DBT%" init %PROJECT% --skip-profile-setup
)

:: ─────────────────────────────────────────────────────────────
echo.
echo [2/5] Writing profiles.yml + dbt models (via setup script)...
:: ─────────────────────────────────────────────────────────────
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -BaseDir "%BASE_DIR%" -Project "%PROJECT%"
if errorlevel 1 ( echo ERROR: setup script failed. & pause & exit /b 1 )

:: ─────────────────────────────────────────────────────────────
echo.
echo [3/5] Creating demo data in DuckDB...
:: ─────────────────────────────────────────────────────────────
duckdb "%BASE_DIR%\demo.duckdb" "CREATE OR REPLACE TABLE raw_customers (id INTEGER PRIMARY KEY, first_name VARCHAR, last_name VARCHAR, email VARCHAR, created_at DATE); INSERT INTO raw_customers VALUES (1,'Alice','Smith','alice@example.com','2023-01-10'),(2,'Bob','Jones','bob@example.com','2023-02-14'),(3,'Carol','White','carol@example.com','2023-03-05'),(4,'Dave','Brown','dave@example.com','2023-04-20'),(5,'Eve','Davis','eve@example.com','2023-05-30');"

duckdb "%BASE_DIR%\demo.duckdb" "CREATE OR REPLACE TABLE raw_orders (id INTEGER PRIMARY KEY, customer_id INTEGER, amount DECIMAL(10,2), status VARCHAR, order_date DATE); INSERT INTO raw_orders VALUES (1,1,100.00,'completed','2024-01-01'),(2,1,200.00,'completed','2024-02-01'),(3,2,150.00,'shipped','2024-01-15'),(4,3,75.00,'pending','2024-03-01'),(5,4,300.00,'completed','2024-01-20'),(6,2,50.00,'completed','2024-02-10'),(7,5,420.00,'shipped','2024-03-15'),(8,1,90.00,'pending','2024-04-01');"

echo   Tables created: raw_customers, raw_orders
duckdb "%BASE_DIR%\demo.duckdb" "SELECT 'raw_customers' AS tbl, COUNT(*) AS row_count FROM raw_customers UNION ALL SELECT 'raw_orders', COUNT(*) FROM raw_orders;"

:: ─────────────────────────────────────────────────────────────
echo.
echo [4/5] Running dbt (run + test + docs)...
:: ─────────────────────────────────────────────────────────────
cd /d "%BASE_DIR%"

echo -- dbt deps --    "%DBT%" deps --profiles-dir . --no-version-check
if exist "packages.yml" (
    "%DBT%" deps --profiles-dir . --no-version-check
    if errorlevel 1 ( echo WARNING: dbt deps failed — continuing without packages. )
) else (
    echo   No packages.yml found — skipping dbt deps.
)
pause

echo.
echo -- dbt debug --    "%DBT%" debug --profiles-dir . --no-version-check
"%DBT%" debug --profiles-dir . --no-version-check
pause

echo.
echo -- dbt run --  "%DBT%" run --profiles-dir . --no-version-check
"%DBT%" run --profiles-dir . --no-version-check
pause

echo.
echo -- dbt test -- "%DBT%" test --profiles-dir . --no-version-check
"%DBT%" test --profiles-dir . --no-version-check
pause

echo.
echo -- dbt docs generate --    "%DBT%" docs generate --profiles-dir . --no-version-check
"%DBT%" docs generate --profiles-dir . --no-version-check
pause

:: ─────────────────────────────────────────────────────────────
echo.
echo [5/5] Query results from mart_customers...
:: ─────────────────────────────────────────────────────────────
echo duckdb "%BASE_DIR%\demo.duckdb" "SELECT * FROM mart_customers ORDER BY lifetime_value DESC;"
duckdb "%BASE_DIR%\demo.duckdb" "SELECT * FROM mart_customers ORDER BY lifetime_value DESC;"
pause

echo.
echo ============================================================
echo  Done!
echo   Project  : %BASE_DIR%
echo   Database : %BASE_DIR%\demo.duckdb
echo   Models   : stg_customers, stg_orders, fct_orders, mart_customers
echo   Serve docs: cd %PROJECT% ^& "%DBT%" docs serve --profiles-dir .
echo ============================================================
echo.

endlocal
pause
