param(
    [string]$BaseDir,
    [string]$Project
)

# Helper: write UTF-8 without BOM (works on PowerShell 5.x)
$utf8 = New-Object System.Text.UTF8Encoding $false
function wf([string]$path, [string]$content) {
    [System.IO.File]::WriteAllText($path, $content, $utf8)
}

# ── profiles.yml ─────────────────────────────────────────────
wf "$BaseDir\profiles.yml" @"
${Project}:
  target: dev
  outputs:
    dev:
      type: duckdb
      path: demo.duckdb
      threads: 4
"@
Write-Host "  Written: profiles.yml"

# ── Remove stale 'example' config block from dbt_project.yml ─
$projectYml = "$BaseDir\dbt_project.yml"
if (Test-Path $projectYml) {
    $content = Get-Content $projectYml -Raw
    $content = $content -replace '(?m)^\s+example:\r?\n(\s+\+materialized:.*\r?\n)?', ''
    [System.IO.File]::WriteAllText($projectYml, $content, $utf8)
    Write-Host "  Patched: dbt_project.yml (removed unused example config)"
}
