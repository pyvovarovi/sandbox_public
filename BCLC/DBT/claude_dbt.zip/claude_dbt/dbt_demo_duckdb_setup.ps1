param(
    [string]$BaseDir,
    [string]$Project
)

$models = "$BaseDir\models"
if (-not (Test-Path $models)) { New-Item -ItemType Directory -Path $models | Out-Null }

# Remove example models shipped by dbt init
$example = "$models\example"
if (Test-Path $example) { Remove-Item $example -Recurse -Force }

# Helper: write UTF-8 without BOM (works on PowerShell 5.x)
$utf8 = New-Object System.Text.UTF8Encoding $false
function wf([string]$path, [string]$content) {
    [System.IO.File]::WriteAllText($path, $content, $utf8)
}

# ── profiles.yml ─────────────────────────────────────────────
wf "$BaseDir\profiles.yml" @"
${Project}:
  target: dev
  outputs:
    dev:
      type: duckdb
      path: demo.duckdb
      threads: 4
"@
Write-Host "  Written: profiles.yml"

# ── sources.yml ──────────────────────────────────────────────
wf "$models\sources.yml" @"
version: 2

sources:
  - name: raw
    schema: main
    tables:
      - name: raw_customers
        columns:
          - name: id
            tests: [unique, not_null]
      - name: raw_orders
        columns:
          - name: id
            tests: [unique, not_null]
          - name: customer_id
            tests: [not_null]
"@
Write-Host "  Written: sources.yml"

# ── stg_customers.sql ────────────────────────────────────────
wf "$models\stg_customers.sql" @"
with source as (
    select * from {{ source('raw', 'raw_customers') }}
)
select
    id                              as customer_id,
    first_name,
    last_name,
    first_name || ' ' || last_name  as full_name,
    email,
    created_at
from source
"@
Write-Host "  Written: stg_customers.sql"

# ── stg_orders.sql ───────────────────────────────────────────
wf "$models\stg_orders.sql" @"
with source as (
    select * from {{ source('raw', 'raw_orders') }}
)
select
    id          as order_id,
    customer_id,
    amount,
    status,
    order_date
from source
"@
Write-Host "  Written: stg_orders.sql"

# ── fct_orders.sql ───────────────────────────────────────────
wf "$models\fct_orders.sql" @"
with orders as (
    select * from {{ ref('stg_orders') }}
),
customers as (
    select * from {{ ref('stg_customers') }}
)
select
    o.order_id,
    o.order_date,
    o.amount,
    o.status,
    c.customer_id,
    c.full_name,
    c.email
from orders o
left join customers c on o.customer_id = c.customer_id
"@
Write-Host "  Written: fct_orders.sql"

# ── mart_customers.sql ───────────────────────────────────────
wf "$models\mart_customers.sql" @"
with orders as (
    select * from {{ ref('fct_orders') }}
)
select
    customer_id,
    full_name,
    email,
    count(*)                                                    as total_orders,
    sum(amount)                                                 as lifetime_value,
    min(order_date)                                             as first_order_date,
    max(order_date)                                             as latest_order_date,
    sum(case when status = 'completed' then amount else 0 end)  as completed_revenue
from orders
group by customer_id, full_name, email
"@
Write-Host "  Written: mart_customers.sql"

# ── schema.yml (model tests) ─────────────────────────────────
wf "$models\schema.yml" @"
version: 2

models:
  - name: stg_customers
    description: Cleaned customers from raw source
    columns:
      - name: customer_id
        tests: [unique, not_null]

  - name: stg_orders
    description: Cleaned orders from raw source
    columns:
      - name: order_id
        tests: [unique, not_null]
      - name: customer_id
        tests: [not_null]

  - name: fct_orders
    description: Orders enriched with customer details
    columns:
      - name: order_id
        tests: [unique, not_null]

  - name: mart_customers
    description: Customer summary with lifetime value and order aggregates
    columns:
      - name: customer_id
        tests: [unique, not_null]
"@
Write-Host "  Written: schema.yml"

Write-Host "  Setup complete."
