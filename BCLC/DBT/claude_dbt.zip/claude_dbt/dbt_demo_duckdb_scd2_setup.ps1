param(
    [string]$BaseDir,
    [string]$Project
)

$models    = "$BaseDir\models"
$snapshots = "$BaseDir\snapshots"

foreach ($dir in @($models, $snapshots)) {
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
}

# Helper: write UTF-8 without BOM (works on PowerShell 5.x)
$utf8 = New-Object System.Text.UTF8Encoding $false
function wf([string]$path, [string]$content) {
    [System.IO.File]::WriteAllText($path, $content, $utf8)
}

# Remove example models shipped by dbt init
$example = "$models\example"
if (Test-Path $example) { Remove-Item $example -Recurse -Force }

# Remove the stale 'example' config block from dbt_project.yml
$projectYml = "$BaseDir\dbt_project.yml"
if (Test-Path $projectYml) {
    $content = Get-Content $projectYml -Raw
    # Strip the indented 'example:' sub-block (two lines: key + materialized)
    $content = $content -replace '(?m)^\s+example:\r?\n\s+\+materialized:.*\r?\n?', ''
    [System.IO.File]::WriteAllText($projectYml, $content, $utf8)
    Write-Host "  Patched: dbt_project.yml (removed unused example config)"
}

# ── profiles.yml ─────────────────────────────────────────────
wf "$BaseDir\profiles.yml" @"
${Project}:
  target: dev
  outputs:
    dev:
      type: duckdb
      path: demo.duckdb
      threads: 4
"@
Write-Host "  Written: profiles.yml"

# ── sources.yml ──────────────────────────────────────────────
wf "$models\sources.yml" @"
version: 2

sources:
  - name: raw
    schema: main
    description: Raw source tables loaded from operational systems
    tables:
      - name: raw_customers
        description: Customer master data — mutable, tracked via SCD2 snapshot
        columns:
          - name: id
            tests: [unique, not_null]
          - name: name
            tests: [not_null]
          - name: email
            tests: [not_null]
          - name: updated_at
            tests: [not_null]
"@
Write-Host "  Written: sources.yml"

# ── snap_customers.sql (SCD2 snapshot) ───────────────────────
#
#  Strategy: timestamp
#    dbt compares updated_at to detect changed rows.
#    Changed rows get their old version expired (dbt_valid_to stamped)
#    and a new version inserted (dbt_valid_to = NULL).
#
#  Columns added by dbt snapshots:
#    dbt_scd_id      md5 surrogate key (unique per historical row)
#    dbt_updated_at  value of updated_at at snapshot time
#    dbt_valid_from  timestamp when this version became active
#    dbt_valid_to    timestamp when this version expired (NULL = current)
#
wf "$snapshots\snap_customers.sql" @"
{% snapshot snap_customers %}

{{
    config(
        target_schema='main',
        unique_key='id',
        strategy='timestamp',
        updated_at='updated_at',
    )
}}

select
    id,
    name,
    email,
    city,
    plan,
    updated_at
from {{ source('raw', 'raw_customers') }}

{% endsnapshot %}
"@
Write-Host "  Written: snapshots/snap_customers.sql"

# ── stg_customers.sql ────────────────────────────────────────
wf "$models\stg_customers.sql" @"
-- Staging layer: light rename / cast on the raw source.
-- NOTE: this reflects the CURRENT state of raw_customers.
--       For full history, query snap_customers directly.
with source as (
    select * from {{ source('raw', 'raw_customers') }}
)
select
    id          as customer_id,
    name,
    email,
    city,
    plan,
    updated_at
from source
"@
Write-Host "  Written: stg_customers.sql"

# ── dim_customers.sql ────────────────────────────────────────
#
#  This model reads from the snapshot and filters to current records
#  (dbt_valid_to IS NULL).  It is the "live" dimension table that
#  downstream reports join against when they only need the latest state.
#
wf "$models\dim_customers.sql" @"
-- Current-state dimension built on top of the SCD2 snapshot.
-- Filters to active rows only (dbt_valid_to IS NULL).
-- Join snap_customers directly when you need historical versions.
with snapshot as (
    select * from {{ ref('snap_customers') }}
)
select
    id                  as customer_id,
    name,
    email,
    city,
    plan,
    dbt_valid_from      as effective_from,
    dbt_scd_id          as scd_key
from snapshot
where dbt_valid_to is null
"@
Write-Host "  Written: dim_customers.sql"

# ── schema.yml (model tests + docs) ──────────────────────────
wf "$models\schema.yml" @"
version: 2

models:
  - name: stg_customers
    description: >
      Staging layer over raw_customers. Represents the CURRENT state
      of every customer. For historical versions use snap_customers.
    columns:
      - name: customer_id
        tests: [unique, not_null]
      - name: email
        tests: [not_null]
      - name: updated_at
        tests: [not_null]

  - name: dim_customers
    description: >
      Current-state customer dimension derived from the SCD2 snapshot.
      Contains exactly one row per customer (the active version).
      dbt_valid_to IS NULL for all rows in this model.
    columns:
      - name: customer_id
        tests: [unique, not_null]
      - name: email
        tests: [not_null]
      - name: scd_key
        description: Surrogate key from snap_customers (dbt_scd_id)
        tests: [unique, not_null]
"@
Write-Host "  Written: schema.yml"

Write-Host "  Setup complete."
