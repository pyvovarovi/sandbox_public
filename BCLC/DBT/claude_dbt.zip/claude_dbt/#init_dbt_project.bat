uv run dbt init my_project
:: cd my_project
:: uv run dbt debug