def main():
    print("Hello from claude-dbt!")


if __name__ == "__main__":
    main()
