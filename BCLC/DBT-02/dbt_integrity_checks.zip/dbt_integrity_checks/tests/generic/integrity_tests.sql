{#
    TEST: composite_unique
    ─────────────────────────────────────────────────────────────
    Generic test for multi-column uniqueness.
    Usage in schema.yml:
        models:
          - name: my_model
            tests:
              - composite_unique:
                  columns: ['col_a', 'col_b']
#}

{% test composite_unique(model, columns) %}

    SELECT {{ columns | join(', ') }}
    FROM {{ model }}
    GROUP BY {{ columns | join(', ') }}
    HAVING COUNT(*) > 1

{% endtest %}


{#
    TEST: referential_integrity
    ─────────────────────────────────────────────────────────────
    Generic test for multi-column FK validation.
    Usage in schema.yml:
        models:
          - name: my_model
            tests:
              - referential_integrity:
                  child_columns: ['order_id']
                  parent_model: ref('orders')
                  parent_columns: ['id']
#}

{% test referential_integrity(model, child_columns, parent_model, parent_columns) %}

    SELECT child.*
    FROM {{ model }} child
    WHERE NOT EXISTS (
        SELECT 1
        FROM {{ parent_model }} parent
        WHERE {% for i in range(child_columns | length) %}
            child.{{ child_columns[i] }} = parent.{{ parent_columns[i] }}
            {% if not loop.last %} AND {% endif %}
        {% endfor %}
    )
    AND {% for col in child_columns %}child.{{ col }} IS NOT NULL{% if not loop.last %} AND {% endif %}{% endfor %}

{% endtest %}
