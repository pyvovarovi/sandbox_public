{#
    MACRO: generate_schema_yml
    ─────────────────────────────────────────────────────────────
    Generates and prints a dbt schema.yml (sources) block for every
    table discovered in the configured schemas, annotated with the
    correct generic tests matching each constraint type.

    Usage:
        dbt run-operation generate_schema_yml

    Copy the output into models/staging/schema.yml to get standard
    dbt test coverage (runs via `dbt test`).
#}

{% macro generate_schema_yml() %}

    {% set database_name = var('target_database') %}
    {% set schema_list   = var('schema_list') %}

    {{ log("# ──────────────────────────────────────────────", info=true) }}
    {{ log("# Auto-generated sources with integrity tests",  info=true) }}
    {{ log("# Paste this into models/staging/schema.yml",   info=true) }}
    {{ log("# ──────────────────────────────────────────────", info=true) }}
    {{ log("version: 2",                                     info=true) }}
    {{ log("",                                               info=true) }}
    {{ log("sources:",                                       info=true) }}

    {% for schema_name in schema_list %}

        {{ log("  - name: " ~ schema_name | lower,           info=true) }}
        {{ log("    database: " ~ database_name,              info=true) }}
        {{ log("    schema: " ~ schema_name,                  info=true) }}
        {{ log("    tables:",                                 info=true) }}

        {% set tables = get_tables_in_schema(database_name, schema_name) %}

        {% for table_name in tables %}

            {{ log("      - name: " ~ table_name | lower,    info=true) }}

            {% set constraints = get_table_constraints(database_name, schema_name, table_name) %}

            {% set has_tests = false %}
            {% set processed = [] %}

            {% for c in constraints %}
                {% if c.constraint_name not in processed %}
                    {% do processed.append(c.constraint_name) %}

                    {# Collect columns for this constraint #}
                    {% set cols = [] %}
                    {% set ref_cols = [] %}
                    {% for cc in constraints %}
                        {% if cc.constraint_name == c.constraint_name %}
                            {% do cols.append(cc.column_name) %}
                            {% if cc.ref_column_name %}
                                {% do ref_cols.append(cc.ref_column_name) %}
                            {% endif %}
                        {% endif %}
                    {% endfor %}

                    {% if c.constraint_type in ['NOT NULL', 'UNIQUE', 'PRIMARY KEY', 'FOREIGN KEY'] %}
                        {% if not has_tests %}
                            {% set has_tests = true %}
                            {{ log("        columns:", info=true) }}
                        {% endif %}

                        {% if c.constraint_type == 'NOT NULL' %}
                            {{ log("          - name: " ~ c.column_name | lower, info=true) }}
                            {{ log("            tests:", info=true) }}
                            {{ log("              - not_null", info=true) }}
                        {% elif c.constraint_type == 'UNIQUE' and cols | length == 1 %}
                            {{ log("          - name: " ~ cols[0] | lower, info=true) }}
                            {{ log("            tests:", info=true) }}
                            {{ log("              - unique", info=true) }}
                        {% elif c.constraint_type == 'PRIMARY KEY' %}
                            {% for col in cols %}
                                {{ log("          - name: " ~ col | lower, info=true) }}
                                {{ log("            tests:", info=true) }}
                                {{ log("              - not_null", info=true) }}
                                {% if cols | length == 1 %}
                                    {{ log("              - unique", info=true) }}
                                {% endif %}
                            {% endfor %}
                        {% elif c.constraint_type == 'FOREIGN KEY' and cols | length == 1 %}
                            {{ log("          - name: " ~ cols[0] | lower, info=true) }}
                            {{ log("            tests:", info=true) }}
                            {{ log("              - relationships:", info=true) }}
                            {{ log("                  to: source('" ~ c.ref_table_schema | lower ~ "', '" ~ c.ref_table_name | lower ~ "')", info=true) }}
                            {{ log("                  field: " ~ ref_cols[0] | lower, info=true) }}
                        {% endif %}
                    {% endif %}
                {% endif %}
            {% endfor %}

        {% endfor %}
    {% endfor %}

{% endmacro %}
