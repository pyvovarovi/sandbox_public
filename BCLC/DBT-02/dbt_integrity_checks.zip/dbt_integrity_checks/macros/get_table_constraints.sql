{#
    MACRO: get_table_constraints
    ─────────────────────────────────────────────────────────────
    Queries Snowflake INFORMATION_SCHEMA to retrieve all integrity
    constraints defined on a table:

      • PRIMARY KEY   – column(s) forming the PK
      • UNIQUE        – unique constraints
      • FOREIGN KEY   – referential integrity (parent table + column)
      • NOT NULL      – pulled from COLUMNS (is_nullable = 'NO')
      • CHECK         – check constraints (Snowflake stores the clause)

    Returns a list of dicts, each with:
      constraint_type, constraint_name, column_name,
      ref_table_schema, ref_table_name, ref_column_name
#}

{% macro get_table_constraints(database_name, schema_name, table_name) %}

    {% set query %}
        -- ── PK / UNIQUE / FK / CHECK from TABLE_CONSTRAINTS + KEY_COLUMN_USAGE ──
        WITH base_constraints AS (
            SELECT
                tc.constraint_type,
                tc.constraint_name,
                kcu.column_name,
                kcu.ordinal_position,
                -- FK references (NULL for non-FK)
                rc.unique_constraint_schema   AS ref_table_schema,
                rc_kcu.table_name             AS ref_table_name,
                rc_kcu.column_name            AS ref_column_name
            FROM {{ database_name }}.information_schema.table_constraints      tc
            LEFT JOIN {{ database_name }}.information_schema.key_column_usage   kcu
                ON  tc.constraint_catalog = kcu.constraint_catalog
                AND tc.constraint_schema  = kcu.constraint_schema
                AND tc.constraint_name    = kcu.constraint_name
            LEFT JOIN {{ database_name }}.information_schema.referential_constraints rc
                ON  tc.constraint_catalog = rc.constraint_catalog
                AND tc.constraint_schema  = rc.constraint_schema
                AND tc.constraint_name    = rc.constraint_name
            LEFT JOIN {{ database_name }}.information_schema.key_column_usage   rc_kcu
                ON  rc.unique_constraint_catalog = rc_kcu.constraint_catalog
                AND rc.unique_constraint_schema  = rc_kcu.constraint_schema
                AND rc.unique_constraint_name    = rc_kcu.constraint_name
                AND kcu.ordinal_position         = rc_kcu.ordinal_position
            WHERE tc.table_schema = '{{ schema_name | upper }}'
              AND tc.table_name   = '{{ table_name | upper }}'
        ),

        -- ── NOT NULL from COLUMNS ──
        not_null_constraints AS (
            SELECT
                'NOT NULL'                           AS constraint_type,
                'NN_' || column_name                 AS constraint_name,
                column_name,
                1                                    AS ordinal_position,
                NULL                                 AS ref_table_schema,
                NULL                                 AS ref_table_name,
                NULL                                 AS ref_column_name
            FROM {{ database_name }}.information_schema.columns
            WHERE table_schema  = '{{ schema_name | upper }}'
              AND table_name    = '{{ table_name | upper }}'
              AND is_nullable   = 'NO'
        )

        SELECT * FROM base_constraints
        UNION ALL
        SELECT * FROM not_null_constraints
        ORDER BY constraint_type, constraint_name, ordinal_position
    {% endset %}

    {% set results = run_query(query) %}

    {% set constraints = [] %}
    {% if execute %}
        {% for row in results.rows %}
            {% do constraints.append({
                'constraint_type'  : row[0],
                'constraint_name'  : row[1],
                'column_name'      : row[2],
                'ordinal_position' : row[3],
                'ref_table_schema' : row[4],
                'ref_table_name'   : row[5],
                'ref_column_name'  : row[6]
            }) %}
        {% endfor %}
    {% endif %}

    {{ return(constraints) }}

{% endmacro %}
