{#
    MACRO: validate_all_constraints
    ─────────────────────────────────────────────────────────────
    Top-level orchestrator. Iterates every schema → table → constraint
    and runs the appropriate validation query for each type:

      NOT NULL     →  SELECT rows WHERE column IS NULL
      UNIQUE       →  SELECT column(s) HAVING COUNT(*) > 1
      PRIMARY KEY  →  NULL check + uniqueness on PK columns
      FOREIGN KEY  →  SELECT child rows with no matching parent
      CHECK        →  (logged as info — Snowflake enforces at DDL)

    Returns: a list of violation result dicts.
    Designed to be called from the run-operation CLI:
        dbt run-operation validate_all_constraints
#}

{% macro validate_all_constraints() %}

    {% set database_name = var('target_database') %}
    {% set schema_list   = var('schema_list') %}

    {% set all_violations = [] %}

    {{ log("", info=true) }}
    {{ log("═══════════════════════════════════════════════════════════", info=true) }}
    {{ log("  INTEGRITY CONSTRAINT VALIDATION", info=true) }}
    {{ log("  Database : " ~ database_name, info=true) }}
    {{ log("  Schemas  : " ~ schema_list | join(', '), info=true) }}
    {{ log("═══════════════════════════════════════════════════════════", info=true) }}

    {# ── iterate schemas ── #}
    {% for schema_name in schema_list %}

        {{ log("", info=true) }}
        {{ log("┌─ SCHEMA: " ~ schema_name, info=true) }}

        {% set tables = get_tables_in_schema(database_name, schema_name) %}

        {% if tables | length == 0 %}
            {{ log("│  ⚠  No tables found — skipping", info=true) }}
        {% endif %}

        {# ── iterate tables ── #}
        {% for table_name in tables %}

            {{ log("│", info=true) }}
            {{ log("├── TABLE: " ~ schema_name ~ "." ~ table_name, info=true) }}

            {% set constraints = get_table_constraints(database_name, schema_name, table_name) %}

            {% if constraints | length == 0 %}
                {{ log("│   └─ (no constraints found)", info=true) }}
            {% endif %}

            {# Group constraints by name (composite keys have multiple rows) #}
            {% set processed_constraints = [] %}

            {% for c in constraints %}

                {# Skip if we already processed this constraint_name #}
                {% if c.constraint_name not in processed_constraints %}

                    {% do processed_constraints.append(c.constraint_name) %}

                    {# Gather all columns for this constraint #}
                    {% set cols = [] %}
                    {% set ref_cols = [] %}
                    {% for cc in constraints %}
                        {% if cc.constraint_name == c.constraint_name %}
                            {% do cols.append(cc.column_name) %}
                            {% if cc.ref_column_name %}
                                {% do ref_cols.append(cc.ref_column_name) %}
                            {% endif %}
                        {% endif %}
                    {% endfor %}


                    {# ─────── NOT NULL ─────── #}
                    {% if c.constraint_type == 'NOT NULL' %}

                        {% set test_query %}
                            SELECT COUNT(*) AS violation_count
                            FROM {{ database_name }}.{{ schema_name }}.{{ table_name }}
                            WHERE {{ c.column_name }} IS NULL
                        {% endset %}

                        {% set result = run_query(test_query) %}
                        {% set violation_count = result.columns[0].values()[0] %}

                        {% if violation_count > 0 %}
                            {{ log("│   ├─ ✗ NOT NULL on [" ~ c.column_name ~ "] — " ~ violation_count ~ " violations", info=true) }}
                            {% do all_violations.append({
                                'schema': schema_name, 'table': table_name,
                                'constraint_type': 'NOT NULL', 'columns': c.column_name,
                                'violation_count': violation_count
                            }) %}
                        {% else %}
                            {{ log("│   ├─ ✓ NOT NULL on [" ~ c.column_name ~ "]", info=true) }}
                        {% endif %}


                    {# ─────── UNIQUE ─────── #}
                    {% elif c.constraint_type == 'UNIQUE' %}

                        {% set col_csv = cols | join(', ') %}
                        {% set test_query %}
                            SELECT COUNT(*) AS violation_count FROM (
                                SELECT {{ col_csv }}, COUNT(*) AS cnt
                                FROM {{ database_name }}.{{ schema_name }}.{{ table_name }}
                                WHERE {% for col in cols %}{{ col }} IS NOT NULL{% if not loop.last %} AND {% endif %}{% endfor %}

                                GROUP BY {{ col_csv }}
                                HAVING COUNT(*) > 1
                            ) dupes
                        {% endset %}

                        {% set result = run_query(test_query) %}
                        {% set violation_count = result.columns[0].values()[0] %}

                        {% if violation_count > 0 %}
                            {{ log("│   ├─ ✗ UNIQUE on [" ~ col_csv ~ "] — " ~ violation_count ~ " duplicate groups", info=true) }}
                            {% do all_violations.append({
                                'schema': schema_name, 'table': table_name,
                                'constraint_type': 'UNIQUE', 'columns': col_csv,
                                'violation_count': violation_count
                            }) %}
                        {% else %}
                            {{ log("│   ├─ ✓ UNIQUE on [" ~ col_csv ~ "]", info=true) }}
                        {% endif %}


                    {# ─────── PRIMARY KEY ─────── #}
                    {% elif c.constraint_type == 'PRIMARY KEY' %}

                        {% set col_csv = cols | join(', ') %}

                        {# PK = NOT NULL + UNIQUE on all PK columns #}
                        {% set null_query %}
                            SELECT COUNT(*) AS violation_count
                            FROM {{ database_name }}.{{ schema_name }}.{{ table_name }}
                            WHERE {% for col in cols %}{{ col }} IS NULL{% if not loop.last %} OR {% endif %}{% endfor %}
                        {% endset %}

                        {% set result = run_query(null_query) %}
                        {% set null_violations = result.columns[0].values()[0] %}

                        {% set dup_query %}
                            SELECT COUNT(*) AS violation_count FROM (
                                SELECT {{ col_csv }}, COUNT(*) AS cnt
                                FROM {{ database_name }}.{{ schema_name }}.{{ table_name }}
                                GROUP BY {{ col_csv }}
                                HAVING COUNT(*) > 1
                            ) dupes
                        {% endset %}

                        {% set result = run_query(dup_query) %}
                        {% set dup_violations = result.columns[0].values()[0] %}

                        {% set total = null_violations + dup_violations %}

                        {% if total > 0 %}
                            {{ log("│   ├─ ✗ PRIMARY KEY on [" ~ col_csv ~ "] — nulls: " ~ null_violations ~ ", duplicate groups: " ~ dup_violations, info=true) }}
                            {% do all_violations.append({
                                'schema': schema_name, 'table': table_name,
                                'constraint_type': 'PRIMARY KEY', 'columns': col_csv,
                                'violation_count': total,
                                'detail': 'nulls=' ~ null_violations ~ ' dupes=' ~ dup_violations
                            }) %}
                        {% else %}
                            {{ log("│   ├─ ✓ PRIMARY KEY on [" ~ col_csv ~ "]", info=true) }}
                        {% endif %}


                    {# ─────── FOREIGN KEY ─────── #}
                    {% elif c.constraint_type == 'FOREIGN KEY' %}

                        {% set col_csv     = cols | join(', ') %}
                        {% set ref_col_csv = ref_cols | join(', ') %}
                        {% set ref_schema  = c.ref_table_schema %}
                        {% set ref_table   = c.ref_table_name %}

                        {% set test_query %}
                            SELECT COUNT(*) AS violation_count
                            FROM {{ database_name }}.{{ schema_name }}.{{ table_name }} child
                            WHERE NOT EXISTS (
                                SELECT 1
                                FROM {{ database_name }}.{{ ref_schema }}.{{ ref_table }} parent
                                WHERE {% for i in range(cols | length) %}
                                    child.{{ cols[i] }} = parent.{{ ref_cols[i] }}
                                    {% if not loop.last %} AND {% endif %}
                                {% endfor %}
                            )
                            AND {% for col in cols %}child.{{ col }} IS NOT NULL{% if not loop.last %} AND {% endif %}{% endfor %}
                        {% endset %}

                        {% set result = run_query(test_query) %}
                        {% set violation_count = result.columns[0].values()[0] %}

                        {% if violation_count > 0 %}
                            {{ log("│   ├─ ✗ FOREIGN KEY [" ~ col_csv ~ "] → " ~ ref_schema ~ "." ~ ref_table ~ " [" ~ ref_col_csv ~ "] — " ~ violation_count ~ " orphan rows", info=true) }}
                            {% do all_violations.append({
                                'schema': schema_name, 'table': table_name,
                                'constraint_type': 'FOREIGN KEY',
                                'columns': col_csv,
                                'ref_table': ref_schema ~ '.' ~ ref_table ~ '(' ~ ref_col_csv ~ ')',
                                'violation_count': violation_count
                            }) %}
                        {% else %}
                            {{ log("│   ├─ ✓ FOREIGN KEY [" ~ col_csv ~ "] → " ~ ref_schema ~ "." ~ ref_table, info=true) }}
                        {% endif %}


                    {# ─────── CHECK (informational) ─────── #}
                    {% elif c.constraint_type == 'CHECK' %}
                        {{ log("│   ├─ ℹ CHECK constraint [" ~ c.constraint_name ~ "] — enforced by Snowflake at DML time", info=true) }}

                    {% endif %}

                {% endif %}
            {% endfor %}

        {% endfor %}

        {{ log("└─ Done: " ~ schema_name, info=true) }}

    {% endfor %}

    {# ── Summary ── #}
    {{ log("", info=true) }}
    {{ log("═══════════════════════════════════════════════════════════", info=true) }}
    {{ log("  SUMMARY", info=true) }}
    {{ log("═══════════════════════════════════════════════════════════", info=true) }}

    {% if all_violations | length == 0 %}
        {{ log("  ✅ ALL CONSTRAINTS PASSED — no violations found.", info=true) }}
    {% else %}
        {{ log("  ❌ VIOLATIONS FOUND: " ~ all_violations | length ~ " constraint(s) failed", info=true) }}
        {{ log("", info=true) }}
        {% for v in all_violations %}
            {{ log("  • " ~ v.schema ~ "." ~ v.table ~ " | " ~ v.constraint_type ~ " on [" ~ v.columns ~ "] — " ~ v.violation_count ~ " violations", info=true) }}
        {% endfor %}
    {% endif %}

    {{ log("═══════════════════════════════════════════════════════════", info=true) }}

{% endmacro %}
