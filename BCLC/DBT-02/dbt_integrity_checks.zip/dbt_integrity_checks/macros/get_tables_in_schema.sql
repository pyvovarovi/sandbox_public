{#
    MACRO: get_tables_in_schema
    ─────────────────────────────────────────────────────────────
    Queries Snowflake INFORMATION_SCHEMA to return all BASE TABLE
    names within a given schema.

    Args:
        database_name : str – Snowflake database name
        schema_name   : str – schema to scan

    Returns:
        list[str] – table names
#}

{% macro get_tables_in_schema(database_name, schema_name) %}

    {% set query %}
        SELECT table_name
        FROM {{ database_name }}.information_schema.tables
        WHERE table_schema = '{{ schema_name | upper }}'
          AND table_type   = 'BASE TABLE'
        ORDER BY table_name
    {% endset %}

    {% set results = run_query(query) %}

    {% if execute %}
        {% set table_list = results.columns[0].values() %}
    {% else %}
        {% set table_list = [] %}
    {% endif %}

    {{ return(table_list) }}

{% endmacro %}
