{{
    config(
        materialized = 'table',
        tags         = ['integrity'],
        schema       = 'audit'
    )
}}

{#
    MODEL: constraint_violation_report
    ─────────────────────────────────────────────────────────────
    Scans all configured schemas/tables and produces one row
    per violated constraint. Materializes as a table so results
    can be queried in BI tools, Slack alerts, etc.

    Run with:
        dbt run --select constraint_violation_report
#}

{% set database_name = var('target_database') %}
{% set schema_list   = var('schema_list') %}

{% set union_queries = [] %}

{% for schema_name in schema_list %}
    {% set tables = get_tables_in_schema(database_name, schema_name) %}

    {% for table_name in tables %}
        {% set constraints = get_table_constraints(database_name, schema_name, table_name) %}
        {% set processed = [] %}

        {% for c in constraints %}
            {% if c.constraint_name not in processed %}
                {% do processed.append(c.constraint_name) %}

                {% set cols = [] %}
                {% set ref_cols = [] %}
                {% for cc in constraints %}
                    {% if cc.constraint_name == c.constraint_name %}
                        {% do cols.append(cc.column_name) %}
                        {% if cc.ref_column_name %}
                            {% do ref_cols.append(cc.ref_column_name) %}
                        {% endif %}
                    {% endfor %}
                {% endfor %}

                {# ── NOT NULL ── #}
                {% if c.constraint_type == 'NOT NULL' %}
                    {% set q %}
                        SELECT
                            '{{ schema_name }}'        AS schema_name,
                            '{{ table_name }}'         AS table_name,
                            'NOT NULL'                 AS constraint_type,
                            '{{ c.constraint_name }}'  AS constraint_name,
                            '{{ c.column_name }}'      AS columns_tested,
                            NULL                       AS reference_target,
                            COUNT(*)                   AS violation_count,
                            CURRENT_TIMESTAMP()        AS tested_at
                        FROM {{ database_name }}.{{ schema_name }}.{{ table_name }}
                        WHERE {{ c.column_name }} IS NULL
                        HAVING COUNT(*) > 0
                    {% endset %}
                    {% do union_queries.append(q) %}
                {% endif %}

                {# ── UNIQUE ── #}
                {% if c.constraint_type == 'UNIQUE' %}
                    {% set col_csv = cols | join(', ') %}
                    {% set q %}
                        SELECT
                            '{{ schema_name }}'        AS schema_name,
                            '{{ table_name }}'         AS table_name,
                            'UNIQUE'                   AS constraint_type,
                            '{{ c.constraint_name }}'  AS constraint_name,
                            '{{ col_csv }}'            AS columns_tested,
                            NULL                       AS reference_target,
                            COUNT(*)                   AS violation_count,
                            CURRENT_TIMESTAMP()        AS tested_at
                        FROM (
                            SELECT {{ col_csv }}
                            FROM {{ database_name }}.{{ schema_name }}.{{ table_name }}
                            GROUP BY {{ col_csv }}
                            HAVING COUNT(*) > 1
                        ) dupes
                        HAVING COUNT(*) > 0
                    {% endset %}
                    {% do union_queries.append(q) %}
                {% endif %}

                {# ── PRIMARY KEY (nulls) ── #}
                {% if c.constraint_type == 'PRIMARY KEY' %}
                    {% set col_csv = cols | join(', ') %}
                    {% set q %}
                        SELECT
                            '{{ schema_name }}'        AS schema_name,
                            '{{ table_name }}'         AS table_name,
                            'PRIMARY KEY (null)'       AS constraint_type,
                            '{{ c.constraint_name }}'  AS constraint_name,
                            '{{ col_csv }}'            AS columns_tested,
                            NULL                       AS reference_target,
                            COUNT(*)                   AS violation_count,
                            CURRENT_TIMESTAMP()        AS tested_at
                        FROM {{ database_name }}.{{ schema_name }}.{{ table_name }}
                        WHERE {% for col in cols %}{{ col }} IS NULL{% if not loop.last %} OR {% endif %}{% endfor %}

                        HAVING COUNT(*) > 0
                    {% endset %}
                    {% do union_queries.append(q) %}

                    {# PK uniqueness #}
                    {% set q %}
                        SELECT
                            '{{ schema_name }}'        AS schema_name,
                            '{{ table_name }}'         AS table_name,
                            'PRIMARY KEY (duplicate)'  AS constraint_type,
                            '{{ c.constraint_name }}'  AS constraint_name,
                            '{{ col_csv }}'            AS columns_tested,
                            NULL                       AS reference_target,
                            COUNT(*)                   AS violation_count,
                            CURRENT_TIMESTAMP()        AS tested_at
                        FROM (
                            SELECT {{ col_csv }}
                            FROM {{ database_name }}.{{ schema_name }}.{{ table_name }}
                            GROUP BY {{ col_csv }}
                            HAVING COUNT(*) > 1
                        ) dupes
                        HAVING COUNT(*) > 0
                    {% endset %}
                    {% do union_queries.append(q) %}
                {% endif %}

                {# ── FOREIGN KEY ── #}
                {% if c.constraint_type == 'FOREIGN KEY' %}
                    {% set col_csv     = cols | join(', ') %}
                    {% set ref_col_csv = ref_cols | join(', ') %}
                    {% set q %}
                        SELECT
                            '{{ schema_name }}'                                                 AS schema_name,
                            '{{ table_name }}'                                                  AS table_name,
                            'FOREIGN KEY'                                                       AS constraint_type,
                            '{{ c.constraint_name }}'                                           AS constraint_name,
                            '{{ col_csv }}'                                                     AS columns_tested,
                            '{{ c.ref_table_schema }}.{{ c.ref_table_name }}({{ ref_col_csv }})' AS reference_target,
                            COUNT(*)                                                            AS violation_count,
                            CURRENT_TIMESTAMP()                                                 AS tested_at
                        FROM {{ database_name }}.{{ schema_name }}.{{ table_name }} child
                        WHERE NOT EXISTS (
                            SELECT 1
                            FROM {{ database_name }}.{{ c.ref_table_schema }}.{{ c.ref_table_name }} parent
                            WHERE {% for i in range(cols | length) %}
                                child.{{ cols[i] }} = parent.{{ ref_cols[i] }}
                                {% if not loop.last %} AND {% endif %}
                            {% endfor %}
                        )
                        AND {% for col in cols %}child.{{ col }} IS NOT NULL{% if not loop.last %} AND {% endif %}{% endfor %}

                        HAVING COUNT(*) > 0
                    {% endset %}
                    {% do union_queries.append(q) %}
                {% endif %}

            {% endif %}
        {% endfor %}
    {% endfor %}
{% endfor %}


{# ── Final UNION ALL ── #}
{% if union_queries | length > 0 %}
    {{ union_queries | join('\nUNION ALL\n') }}
{% else %}
    -- No constraints discovered; return empty result set
    SELECT
        NULL::VARCHAR AS schema_name,
        NULL::VARCHAR AS table_name,
        NULL::VARCHAR AS constraint_type,
        NULL::VARCHAR AS constraint_name,
        NULL::VARCHAR AS columns_tested,
        NULL::VARCHAR AS reference_target,
        NULL::INT     AS violation_count,
        NULL::TIMESTAMP_NTZ AS tested_at
    WHERE 1 = 0
{% endif %}
