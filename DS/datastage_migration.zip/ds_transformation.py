#!/usr/bin/env python3
"""DataStage Transformation Tool

Reads IBM DataStage .dsd / .xml backup files and produces:
  Output 1: Markdown lineage + job documentation  (*_lineage.md)
  Output 2: Matillion ETL import JSON              (*_matillion_etl.json)
  Output 3: Matillion Claude AI-context JSON       (*_matillion_claude.json)

Batch processing is driven by a YAML configuration file.

Usage:
    uv run ds_transformation.py --config batch_config.yaml
    uv run ds_transformation.py --file ds_sample/demo.dsd --output output/
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
import uuid
import zlib
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional
import xml.etree.ElementTree as ET

import yaml

log = logging.getLogger("ds_transform")

# ─── SQL type map ──────────────────────────────────────────────────────────────
SQL_TYPES: dict[str, str] = {
    "1": "CHAR", "2": "NUMERIC", "3": "DECIMAL", "4": "INTEGER",
    "5": "SMALLINT", "6": "FLOAT", "7": "REAL", "8": "DOUBLE",
    "9": "DATE", "10": "TIME", "11": "TIMESTAMP", "12": "VARCHAR",
    "-1": "LONGVARCHAR", "-2": "BINARY", "-3": "VARBINARY",
    "-4": "LONGVARBINARY", "-5": "BIGINT", "-6": "TINYINT",
    "-7": "BIT", "-8": "WCHAR", "-9": "WVARCHAR", "-10": "WLONGVARCHAR",
}

# ─── Stage category map ────────────────────────────────────────────────────────
STAGE_CATEGORY: dict[str, str] = {
    "PxSequentialFile": "File",
    "PxDataSet": "File",
    "PxFTP": "File",
    "Pxsqlsvr": "Database",
    "PxODBC": "Database",
    "PxOracle": "Database",
    "PxDB2": "Database",
    "PxTeradata": "Database",
    "CTransformerStage": "Transform",
    "PxJoin": "Join",
    "PxMerge": "Join",
    "PxLookup": "Lookup",
    "PxSort": "Transform",
    "PxFilter": "Transform",
    "PxAggregator": "Transform",
    "PxPeek": "Debug",
    "PxRowGenerator": "Source",
    "CSequencer": "Control",
    "CRoutineActivity": "Control",
    "CJobActivity": "Control",
    "CExecCommandActivity": "Control",
    "CWaitForFileActivity": "Control",
}

# Matillion component type mapping from DataStage stage types
MATILLION_COMPONENT_MAP: dict[str, str] = {
    "PxSequentialFile": "fixed-width-file-input",
    "Pxsqlsvr": "sql-server-query",
    "PxODBC": "generic-query",
    "PxOracle": "oracle-query",
    "PxDB2": "db2-query",
    "PxTeradata": "teradata-query",
    "CTransformerStage": "calculator",
    "PxJoin": "join",
    "PxMerge": "union",
    "PxLookup": "lookup",
    "PxSort": "sort",
    "PxFilter": "filter-rows",
    "PxAggregator": "aggregate",
    "PxDataSet": "table-input",
}


# ─── Data models ───────────────────────────────────────────────────────────────

@dataclass
class DSParameter:
    name: str
    prompt: str = ""
    default: str = ""
    param_type: str = "0"


@dataclass
class DSColumn:
    name: str
    sql_type: str = ""
    nullable: bool = True
    length: int = 0
    scale: int = 0
    derivation: str = ""
    source_column: str = ""


@dataclass
class DSLink:
    name: str
    source_stage_id: str = ""
    target_stage_id: str = ""
    source_stage_name: str = ""
    target_stage_name: str = ""
    columns: list[DSColumn] = field(default_factory=list)


@dataclass
class DSStage:
    id: str
    name: str
    stage_type: str = ""
    category: str = ""
    input_links: list[str] = field(default_factory=list)
    output_links: list[str] = field(default_factory=list)
    properties: dict[str, str] = field(default_factory=dict)


@dataclass
class DSJob:
    identifier: str
    name: str
    date_modified: str = ""
    time_modified: str = ""
    job_type: str = "Parallel"
    server_name: str = ""
    server_version: str = ""
    category: str = ""
    parameters: list[DSParameter] = field(default_factory=list)
    stages: list[DSStage] = field(default_factory=list)
    links: list[DSLink] = field(default_factory=list)
    source_file: str = ""
    source_format: str = ""


# ─── DSD Parser ────────────────────────────────────────────────────────────────

class DSDParser:
    """Parses IBM DataStage .dsd export files."""

    _KV_RE    = re.compile(r'^\s*(\w+)\s+"(.*?)"\s*$')
    _ML_START = re.compile(r'^\s*(\w+)\s+=\+=\+=\+=\s*$')

    def parse(self, path: Path) -> list[DSJob]:
        text = path.read_text(encoding="cp1252", errors="replace")
        lines = text.splitlines()

        header: dict[str, str] = {}
        i = 0
        while i < len(lines):
            stripped = lines[i].strip()
            if stripped == "BEGIN HEADER":
                block, i = self._collect_block(lines, i + 1, "HEADER")
                header = self._parse_props(block)
            elif stripped == "BEGIN DSJOB":
                break
            else:
                i += 1

        jobs: list[DSJob] = []
        while i < len(lines):
            stripped = lines[i].strip()
            if stripped == "BEGIN DSJOB":
                job_block, i = self._collect_block(lines, i + 1, "DSJOB")
                job = self._parse_job(job_block, header)
                job.source_file = str(path)
                job.source_format = "DSD"
                jobs.append(job)
            else:
                i += 1
        return jobs

    def _collect_block(self, lines: list[str], start: int, end_type: str) -> tuple[list[str], int]:
        block: list[str] = []
        depth = 0
        i = start
        while i < len(lines):
            stripped = lines[i].strip()
            if stripped == f"END {end_type}" and depth == 0:
                return block, i + 1
            if stripped.startswith("BEGIN "):
                depth += 1
            elif stripped.startswith("END ") and depth > 0:
                depth -= 1
            block.append(lines[i])
            i += 1
        return block, i

    def _parse_props(self, lines: list[str]) -> dict[str, str]:
        props: dict[str, str] = {}
        for line in lines:
            m = self._KV_RE.match(line)
            if m:
                props[m.group(1)] = m.group(2)
        return props

    def _parse_props_ml(self, lines: list[str]) -> dict[str, str]:
        """Parse key-value pairs including multi-line =+=+=+= delimited values."""
        props: dict[str, str] = {}
        i = 0
        while i < len(lines):
            m = self._KV_RE.match(lines[i])
            if m:
                props[m.group(1)] = m.group(2)
                i += 1
                continue
            m = self._ML_START.match(lines[i])
            if m:
                key = m.group(1)
                i += 1
                parts: list[str] = []
                while i < len(lines) and "=+=+=+=" not in lines[i]:
                    parts.append(lines[i].rstrip("\n"))
                    i += 1
                props[key] = "\n".join(parts).strip()
                i += 1  # skip closing =+=+=+=
                continue
            i += 1
        return props

    def _parse_subblocks(self, lines: list[str]) -> tuple[dict[str, str], list[tuple[str, list[str]]]]:
        """Return (props, [(block_type, block_lines), ...])."""
        props: dict[str, str] = {}
        subblocks: list[tuple[str, list[str]]] = []
        i = 0
        while i < len(lines):
            stripped = lines[i].strip()
            m = self._KV_RE.match(lines[i])
            if m:
                props[m.group(1)] = m.group(2)
                i += 1
            elif stripped.startswith("BEGIN "):
                block_type = stripped[6:]
                block_lines, i = self._collect_block(lines, i + 1, block_type)
                subblocks.append((block_type, block_lines))
            else:
                i += 1
        return props, subblocks

    def _parse_job(self, job_lines: list[str], header: dict[str, str]) -> DSJob:
        props, subblocks = self._parse_subblocks(job_lines)
        job = DSJob(
            identifier=props.get("Identifier", ""),
            name="",
            date_modified=props.get("DateModified", ""),
            time_modified=props.get("TimeModified", ""),
            server_name=header.get("ServerName", ""),
            server_version=header.get("ServerVersion", ""),
        )

        # Collect all DSRECORD blocks by their Identifier
        records: dict[str, dict[str, str]] = {}
        record_subblocks: dict[str, list[tuple[str, list[str]]]] = {}
        for btype, blines in subblocks:
            if btype == "DSRECORD":
                rprops, rsubs = self._parse_subblocks(blines)
                rid = rprops.get("Identifier", "")
                records[rid] = rprops
                record_subblocks[rid] = rsubs

        # ROOT record — job metadata + parameters
        root = records.get("ROOT", {})
        job.name = root.get("Name", job.identifier)
        job.category = root.get("Category", "")
        job.job_type = "Sequence" if root.get("JobType", "3") == "1" else "Parallel"

        for btype, blines in record_subblocks.get("ROOT", []):
            if btype == "DSSUBRECORD":
                pprops = self._parse_props(blines)
                if pprops.get("Name") and pprops.get("Name") not in ("APT",):
                    job.parameters.append(DSParameter(
                        name=pprops.get("Name", ""),
                        prompt=pprops.get("Prompt", ""),
                        default=pprops.get("Default", ""),
                        param_type=pprops.get("ParamType", "0"),
                    ))

        # V0 container — stage and link topology
        v0 = records.get("V0", {})
        stage_ids_raw = v0.get("StageList", "").split("|")
        stage_names_raw = v0.get("StageNames", "").split("|")
        stage_type_ids_raw = v0.get("StageTypeIDs", "").split("|")
        link_names_raw = v0.get("LinkNames", "").split("|")
        target_ids_raw = v0.get("TargetStageIDs", "").split("|")
        source_pin_ids_raw = v0.get("LinkSourcePinIDs", "").split("|")

        stage_map: dict[str, DSStage] = {}
        for idx, sid in enumerate(stage_ids_raw):
            sid = sid.strip()
            if not sid:
                continue
            sname = stage_names_raw[idx].strip() if idx < len(stage_names_raw) else sid
            stype = stage_type_ids_raw[idx].strip() if idx < len(stage_type_ids_raw) else ""
            if not sname or not stype:          # skip palette annotations (blank name/type)
                continue
            stage_map[sid] = DSStage(
                id=sid,
                name=sname,
                stage_type=stype,
                category=STAGE_CATEGORY.get(stype, "Unknown"),
            )

        link_map: dict[str, DSLink] = {}
        for idx, lname in enumerate(link_names_raw):
            lname = lname.strip()
            if not lname:
                continue
            src_pin = source_pin_ids_raw[idx].strip() if idx < len(source_pin_ids_raw) else ""
            tgt_id = target_ids_raw[idx].strip() if idx < len(target_ids_raw) else ""
            src_id = re.sub(r"P\d+$", "", src_pin) if src_pin else ""
            src_stage = stage_map.get(src_id)
            tgt_stage = stage_map.get(tgt_id)
            link = DSLink(
                name=lname,
                source_stage_id=src_id,
                target_stage_id=tgt_id,
                source_stage_name=src_stage.name if src_stage else src_id,
                target_stage_name=tgt_stage.name if tgt_stage else tgt_id,
            )
            link_map[lname] = link
            if src_stage:
                src_stage.output_links.append(lname)
            if tgt_stage:
                tgt_stage.input_links.append(lname)

        # Extract columns and SQL custom properties from pin records (e.g. V0S34P2)
        for rid, rprops in records.items():
            if not re.match(r"^V\d+S\d+P\d+$", rid):
                continue
            link_name = rprops.get("Name", "")
            stage_id = re.sub(r"P\d+$", "", rid)
            stage = stage_map.get(stage_id)
            for btype, blines in record_subblocks.get(rid, []):
                if btype != "DSSUBRECORD":
                    continue
                pprops = self._parse_props_ml(blines)
                cname = pprops.get("Name", "")
                # Column data
                if link_name in link_map and cname and pprops.get("SqlType"):
                    link_map[link_name].columns.append(DSColumn(
                        name=cname,
                        sql_type=SQL_TYPES.get(pprops.get("SqlType", ""), pprops.get("SqlType", "")),
                        nullable=pprops.get("Nullable", "1") == "1",
                        length=int(pprops.get("Precision", "0") or "0"),
                        scale=int(pprops.get("Scale", "0") or "0"),
                        derivation=pprops.get("Derivation", ""),
                        source_column=pprops.get("SourceColumn", ""),
                    ))
                # SQL custom properties for Pxsqlsvr stages
                if stage and stage.stage_type == "Pxsqlsvr":
                    pval = pprops.get("Value", "")
                    if cname in ("selection", "query") and pval:
                        stage.properties[cname] = pval

        job.stages = list(stage_map.values())
        job.links = list(link_map.values())
        return job


# ─── XML Parser ────────────────────────────────────────────────────────────────

class XMLParser:
    """Parses IBM DataStage .xml export files."""

    def parse(self, path: Path) -> list[DSJob]:
        tree = ET.parse(str(path))
        root = tree.getroot()

        header_el = root.find("Header")
        header: dict[str, str] = header_el.attrib if header_el is not None else {}

        jobs: list[DSJob] = []
        for job_el in root.findall("Job"):
            job = self._parse_job(job_el, header)
            job.source_file = str(path)
            job.source_format = "XML"
            jobs.append(job)
        return jobs

    def _get_props(self, el: ET.Element) -> dict[str, str]:
        """Extract all <Property Name="...">value</Property> children."""
        return {
            p.get("Name", ""): (p.text or "")
            for p in el.findall("Property")
        }

    def _parse_job(self, job_el: ET.Element, header: dict[str, str]) -> DSJob:
        job = DSJob(
            identifier=job_el.get("Identifier", ""),
            name="",
            date_modified=job_el.get("DateModified", ""),
            time_modified=job_el.get("TimeModified", ""),
            server_name=header.get("ServerName", ""),
            server_version=header.get("ServerVersion", ""),
        )

        records: dict[str, ET.Element] = {
            r.get("Identifier", ""): r
            for r in job_el.findall("Record")
        }

        # ROOT
        root_el = records.get("ROOT")
        if root_el is not None:
            rprops = self._get_props(root_el)
            job.name = rprops.get("Name", job.identifier)
            job.category = rprops.get("Category", "")
            job.job_type = "Sequence" if rprops.get("JobType") == "1" else "Parallel"
            for col in root_el.findall("Collection"):
                if col.get("Name") == "Parameters":
                    for sr in col.findall("SubRecord"):
                        pprops = self._get_props(sr)
                        if pprops.get("Name"):
                            job.parameters.append(DSParameter(
                                name=pprops.get("Name", ""),
                                prompt=pprops.get("Prompt", ""),
                                default=pprops.get("Default", ""),
                                param_type=pprops.get("ParamType", "0"),
                            ))

        # V0 container — topology
        v0_el = records.get("V0")
        if v0_el is None:
            return job

        v0_props = self._get_props(v0_el)
        stage_ids_raw = v0_props.get("StageList", "").split("|")
        stage_names_raw = v0_props.get("StageNames", "").split("|")
        stage_type_ids_raw = v0_props.get("StageTypeIDs", "").split("|")
        link_names_raw = v0_props.get("LinkNames", "").split("|")
        target_ids_raw = v0_props.get("TargetStageIDs", "").split("|")
        source_pin_ids_raw = v0_props.get("LinkSourcePinIDs", "").split("|")

        stage_map: dict[str, DSStage] = {}
        for idx, sid in enumerate(stage_ids_raw):
            sid = sid.strip()
            if not sid:
                continue
            sname = stage_names_raw[idx].strip() if idx < len(stage_names_raw) else sid
            stype = stage_type_ids_raw[idx].strip() if idx < len(stage_type_ids_raw) else ""
            if not sname or not stype:          # skip palette annotations (blank name/type)
                continue
            stage_map[sid] = DSStage(
                id=sid,
                name=sname,
                stage_type=stype,
                category=STAGE_CATEGORY.get(stype, "Unknown"),
            )

        link_map: dict[str, DSLink] = {}
        for idx, lname in enumerate(link_names_raw):
            lname = lname.strip()
            if not lname:
                continue
            src_pin = source_pin_ids_raw[idx].strip() if idx < len(source_pin_ids_raw) else ""
            tgt_id = target_ids_raw[idx].strip() if idx < len(target_ids_raw) else ""
            src_id = re.sub(r"P\d+$", "", src_pin) if src_pin else ""
            src_stage = stage_map.get(src_id)
            tgt_stage = stage_map.get(tgt_id)
            link = DSLink(
                name=lname,
                source_stage_id=src_id,
                target_stage_id=tgt_id,
                source_stage_name=src_stage.name if src_stage else src_id,
                target_stage_name=tgt_stage.name if tgt_stage else tgt_id,
            )
            link_map[lname] = link
            if src_stage:
                src_stage.output_links.append(lname)
            if tgt_stage:
                tgt_stage.input_links.append(lname)

        # Columns from pin records
        for rid, rec_el in records.items():
            if not re.match(r"^V\d+S\d+P\d+$", rid):
                continue
            rprops = self._get_props(rec_el)
            link_name = rprops.get("Name", "")
            if link_name not in link_map:
                continue
            link = link_map[link_name]
            for col_coll in rec_el.findall("Collection"):
                if col_coll.get("Type") in ("OutputColumn", "InputColumn"):
                    for sr in col_coll.findall("SubRecord"):
                        cprops = self._get_props(sr)
                        cname = cprops.get("Name", "")
                        if cname and cprops.get("SqlType"):
                            link.columns.append(DSColumn(
                                name=cname,
                                sql_type=SQL_TYPES.get(cprops.get("SqlType", ""), cprops.get("SqlType", "")),
                                nullable=cprops.get("Nullable", "1") == "1",
                                length=int(cprops.get("Precision", "0") or "0"),
                                scale=int(cprops.get("Scale", "0") or "0"),
                                derivation=cprops.get("Derivation", ""),
                                source_column=cprops.get("SourceColumn", ""),
                            ))

        # Extract SQL custom properties from Pxsqlsvr pin records
        for rid, rec_el in records.items():
            if not re.match(r"^V\d+S\d+P\d+$", rid):
                continue
            stage_id = re.sub(r"P\d+$", "", rid)
            stage = stage_map.get(stage_id)
            if stage is None or stage.stage_type != "Pxsqlsvr":
                continue
            for coll in rec_el.findall("Collection"):
                if coll.get("Type") != "CustomProperty":
                    continue
                for sr in coll.findall("SubRecord"):
                    srprops = self._get_props(sr)
                    pname = srprops.get("Name", "")
                    pval = srprops.get("Value", "")
                    if pname in ("selection", "query") and pval:
                        stage.properties[pname] = pval

        job.stages = list(stage_map.values())
        job.links = list(link_map.values())
        return job


# ─── Markdown Exporter ─────────────────────────────────────────────────────────

class MarkdownExporter:
    """Output 1: Markdown lineage document."""

    def export(self, jobs: list[DSJob], output_path: Path) -> None:
        lines: list[str] = []
        lines.append(f"# DataStage Job Lineage Report\n")
        lines.append(f"_Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}_\n")
        lines.append(f"**Total jobs:** {len(jobs)}\n")
        lines.append("---\n")

        for job in jobs:
            lines.extend(self._render_job(job))

        output_path.write_text("\n".join(lines), encoding="utf-8")
        log.info("Markdown written → %s", output_path)

    def _render_job(self, job: DSJob) -> list[str]:
        lines: list[str] = []
        lines.append(f"## Job: `{job.name}`\n")

        # Summary table
        lines.append("### Summary\n")
        lines.append("| Field | Value |")
        lines.append("|-------|-------|")
        lines.append(f"| **Identifier** | `{job.identifier}` |")
        lines.append(f"| **Server** | {job.server_name} |")
        lines.append(f"| **Server Version** | {job.server_version} |")
        lines.append(f"| **Date Modified** | {job.date_modified} |")
        lines.append(f"| **Job Type** | {job.job_type} |")
        lines.append(f"| **Category** | {job.category} |")
        lines.append(f"| **Source File** | `{job.source_file}` |")
        lines.append(f"| **Source Format** | {job.source_format} |")
        lines.append("")

        # Parameters
        if job.parameters:
            lines.append("### Parameters\n")
            lines.append("| Name | Prompt | Default | Type |")
            lines.append("|------|--------|---------|------|")
            for p in job.parameters:
                ptype = {"0": "String", "1": "Encrypted", "13": "List"}.get(p.param_type, p.param_type)
                lines.append(f"| `{p.name}` | {p.prompt} | `{p.default}` | {ptype} |")
            lines.append("")

        # Stages
        if job.stages:
            lines.append("### Stages\n")
            lines.append("| Stage Name | Type | Category | Inputs | Outputs |")
            lines.append("|-----------|------|----------|--------|---------|")
            for s in job.stages:
                ins = ", ".join(f"`{l}`" for l in s.input_links) or "—"
                outs = ", ".join(f"`{l}`" for l in s.output_links) or "—"
                lines.append(f"| **{s.name}** | `{s.stage_type}` | {s.category} | {ins} | {outs} |")
            lines.append("")

        # Data flow diagram (Mermaid)
        if job.links:
            lines.append("### Data Flow\n")
            lines.append("```mermaid")
            lines.append("graph LR")

            def _mid(n: str) -> str:
                """Sanitize a stage name into a valid Mermaid node ID."""
                s = re.sub(r"[^\w]", "_", n)
                return ("n_" + s) if (s and s[0].isdigit()) else (s or "node")

            def _mlabel(n: str) -> str:
                """Escape a name for use inside Mermaid quoted label ["..."]."""
                return n.replace('"', "#quot;")

            def _medge(n: str) -> str:
                """Strip characters that break Mermaid |edge label| syntax."""
                return re.sub(r'[|\\()\[\]{}"<>]', "_", n)

            # Declare unique nodes with quoted display labels (preserves original name)
            seen: set[str] = set()
            for lnk in job.links:
                for sn in (lnk.source_stage_name, lnk.target_stage_name):
                    if sn not in seen:
                        seen.add(sn)
                        lines.append(f'    {_mid(sn)}["{_mlabel(sn)}"]')

            # Write connections using sanitized IDs and edge labels
            for lnk in job.links:
                src = _mid(lnk.source_stage_name)
                tgt = _mid(lnk.target_stage_name)
                lines.append(f"    {src} -->|{_medge(lnk.name)}| {tgt}")
            lines.append("```\n")

        # Column lineage per link
        links_with_cols = [lnk for lnk in job.links if lnk.columns]
        if links_with_cols:
            lines.append("### Column Lineage\n")
            for lnk in links_with_cols:
                lines.append(f"#### Link `{lnk.name}`: `{lnk.source_stage_name}` → `{lnk.target_stage_name}`\n")
                lines.append("| Column | SQL Type | Length | Nullable | Derivation | Source Column |")
                lines.append("|--------|----------|--------|----------|------------|---------------|")
                for col in lnk.columns:
                    deriv = f"`{col.derivation}`" if col.derivation else "—"
                    src_col = f"`{col.source_column}`" if col.source_column else "—"
                    null_str = "Yes" if col.nullable else "No"
                    length_str = str(col.length) if col.length > 0 else "—"
                    lines.append(f"| `{col.name}` | {col.sql_type} | {length_str} | {null_str} | {deriv} | {src_col} |")
                lines.append("")

        lines.append("---\n")
        return lines


# ─── Matillion ETL Exporter ────────────────────────────────────────────────────

class MatillionETLExporter:
    """Output 2: Matillion ETL import JSON matching the native Matillion export format.

    implementationID values are taken from the real Matillion component registry
    (verified against mattilion_sample/sample-001.json).
    """

    _JOB_BASE  = 1_000_000
    _COMP_BASE = 2_000_000
    _CONN_BASE = 3_000_000
    _TREE_BASE = 4_000_000

    def __init__(self, format_sql: bool = False) -> None:
        self._format_sql = format_sql

    def _fmt_sql(self, sql: str) -> str:
        """Format SQL with SQLFluff (T-SQL dialect) when format_sql=True.
        Returns the original SQL unchanged if formatting is disabled or fails.
        """
        if not self._format_sql or not sql.strip():
            return sql
        try:
            import logging as _logging
            # Suppress SQLFluff's verbose output (including "Rust extensions" notice)
            # Must happen before import so propagation is disabled at import time
            _sf = _logging.getLogger("sqlfluff")
            _sf.setLevel(_logging.CRITICAL)
            _sf.propagate = False
            import sqlfluff
            result = sqlfluff.fix(sql, dialect="tsql")
            return result if result.strip() else sql
        except Exception as exc:
            log.warning("SQLFluff formatting failed: %s", exc)
            return sql

    # Real Matillion implementationID values (from sample-001.json)
    _IMPL = {
        "table_input":  1354890871,   # Table Input  (ZERO inputs,  MANY outputs)
        "table_output":  335239555,   # Table Output (ONE  input,   ZERO outputs)
        "calculator":   1716658327,   # Calculator   (ONE  input,   MANY outputs)
        "join":         -629958239,   # Join         (MANY inputs,  MANY outputs)
        "filter":      -1760161015,   # Filter Rows  (ONE  input,   MANY outputs)
        "distinct":     1744268877,   # Distinct     (ONE  input,   MANY outputs)
        "rename":        128170095,   # Rename       (ONE  input,   MANY outputs)
        # implementationID verified from mattilion_sample/sample-002.json (Database Query component)
        "sql_query":  -741198691,     # SQL Query / Database Query (ZERO inputs, MANY outputs)
    }

    # DataStage stage type → Matillion component key
    _DS_MAP: dict[str, str] = {
        "CTransformerStage": "calculator",
        "PxJoin":            "join",
        "PxMerge":           "join",
        "PxLookup":          "join",
        "PxFilter":          "filter",
        "PxSort":            "distinct",
        "PxAggregator":      "distinct",
    }

    # ── public ─────────────────────────────────────────────────────────────────

    def export(self, jobs: list[DSJob], output_path: Path) -> None:
        now_ms = int(datetime.now().timestamp() * 1000)

        job_entries = []
        orchestration_jobs: list = []
        transformation_jobs: list = []
        for idx, job in enumerate(jobs):
            job_id = self._JOB_BASE + idx
            is_orch = self._is_orchestration(job)
            job_type = "ORCHESTRATION" if is_orch else "TRANSFORMATION"
            job_entries.append({
                "id": job_id,
                "name": job.name,
                "description": f"Migrated from DataStage ({job.source_format}) — {job.source_file}",
                "type": job_type,
                "tag": str(uuid.uuid4()),
            })
            if is_orch:
                orchestration_jobs.append(self._render_orchestration_job(job, job_id, now_ms))
            else:
                transformation_jobs.append(self._render_job(job, job_id, now_ms))

        category = jobs[0].category if jobs else ""
        folder_name = category.replace("\\", "/").strip("/").split("/")[-1] or "DataStage"

        seen: set[str] = set()
        global_vars = []
        for job in jobs:
            for p in job.parameters:
                if p.name not in seen:
                    seen.add(p.name)
                    global_vars.append({
                        "name": p.name, "type": "TEXT", "scope": "BRANCH",
                        "description": p.prompt, "visibility": "PUBLIC",
                    })

        payload = {
            "dbEnvironment": "snowflake",
            "version": "1.68.27",
            "jobsTree": {
                "id": self._TREE_BASE,
                "name": "ROOT",
                "children": [{
                    "id": self._TREE_BASE + 1,
                    "name": folder_name,
                    "children": [],
                    "jobs": job_entries,
                }],
                "jobs": [],
            },
            "orchestrationJobs": orchestration_jobs,
            "transformationJobs": transformation_jobs,
            "variables": global_vars,
            "environments": [],
        }
        output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        log.info("Matillion ETL JSON written → %s", output_path)

    # ── implementationID + cardinality resolution ──────────────────────────────
    # Cardinality is a FIXED property of each Matillion component type,
    # NOT derived from the actual number of connected links.

    _FIXED_CARDINALITY: dict[str, tuple[str, str]] = {
        "table_input":  ("ZERO", "MANY"),
        "table_output": ("ONE",  "ZERO"),
        "calculator":   ("ONE",  "MANY"),
        "join":         ("MANY", "MANY"),
        "filter":       ("ONE",  "MANY"),
        "distinct":     ("ONE",  "MANY"),
        "rename":       ("ONE",  "MANY"),
        "sql_query":    ("ZERO", "MANY"),
    }

    def _resolve_key(self, stage: DSStage) -> str:
        """Return the component-type key that drives both implementationID and cardinality."""
        # SQL Server Enterprise with user-defined SQL → SQL Query component
        if stage.stage_type == "Pxsqlsvr" and stage.properties.get("selection") == "userquery":
            return "sql_query"
        if not stage.input_links:
            return "table_input"
        if not stage.output_links:
            return "table_output"
        return self._DS_MAP.get(stage.stage_type, "calculator")

    def _resolve_impl_id(self, stage: DSStage) -> int:
        return self._IMPL[self._resolve_key(stage)]

    def _cardinality(self, stage: DSStage) -> tuple[str, str]:
        return self._FIXED_CARDINALITY[self._resolve_key(stage)]

    # ── parameter builders ─────────────────────────────────────────────────────

    @staticmethod
    def _p1(slot: int, name: str, value: str) -> dict:
        """Single-value parameter element."""
        return {str(slot): {
            "slot": slot, "name": name,
            "elements": {"1": {"slot": 1, "values": {
                "1": {"slot": 1, "type": "STRING", "value": value}
            }}},
            "visible": True,
        }}

    @staticmethod
    def _p_list(slot: int, name: str, values: list[str]) -> dict:
        """Multi-element parameter, one value per element (e.g. Column Names)."""
        elements = {str(i): {"slot": i, "values": {
            "1": {"slot": 1, "type": "STRING", "value": v}
        }} for i, v in enumerate(values, 1)}
        return {str(slot): {"slot": slot, "name": name, "elements": elements, "visible": True}}

    @staticmethod
    def _p_pairs(slot: int, name: str, pairs: list[tuple[str, str]]) -> dict:
        """Multi-element parameter, two values per element (e.g. Calculations: expr, col)."""
        elements = {str(i): {"slot": i, "values": {
            "1": {"slot": 1, "type": "STRING", "value": a},
            "2": {"slot": 2, "type": "STRING", "value": b},
        }} for i, (a, b) in enumerate(pairs, 1)}
        return {str(slot): {"slot": slot, "name": name, "elements": elements, "visible": True}}

    @staticmethod
    def _p_triples(slot: int, name: str, triples: list[tuple[str, str, str]]) -> dict:
        """Multi-element parameter, three values per element (e.g. Joins: table, alias, type)."""
        elements = {str(i): {"slot": i, "values": {
            "1": {"slot": 1, "type": "STRING", "value": a},
            "2": {"slot": 2, "type": "STRING", "value": b},
            "3": {"slot": 3, "type": "STRING", "value": c},
        }} for i, (a, b, c) in enumerate(triples, 1)}
        return {str(slot): {"slot": slot, "name": name, "elements": elements, "visible": True}}

    # ── component parameter assembly ───────────────────────────────────────────

    def _build_params(
        self, stage: DSStage, link_map: dict[str, "DSLink"]
    ) -> dict:
        params: dict = {}
        params.update(self._p1(1, "Name", stage.name))

        is_source = not stage.input_links
        is_target = not stage.output_links

        # SQL Server Enterprise with user-defined SQL → SQL Query component
        if stage.stage_type == "Pxsqlsvr" and stage.properties.get("selection") == "userquery":
            params.update(self._p1(2, "SQL", self._fmt_sql(stage.properties.get("query", ""))))
            return params

        if is_source:
            # Table Input: Name, Target Table, Column Names
            params.update(self._p1(2, "Target Table", stage.name))
            cols = [
                c.name
                for lname in stage.output_links
                for c in (link_map[lname].columns if lname in link_map else [])
            ]
            if cols:
                params.update(self._p_list(3, "Column Names", cols))

        elif is_target:
            # Table Output: Name, Target Table
            params.update(self._p1(2, "Target Table", stage.name))

        elif stage.stage_type == "CTransformerStage":
            # Calculator: Name, Include Input Columns, Calculations
            params.update(self._p1(2, "Include Input Columns", "Yes"))
            calcs = [
                (col.derivation, col.name)
                for lname in stage.output_links
                for col in (link_map[lname].columns if lname in link_map else [])
                if col.derivation
            ]
            if calcs:
                params.update(self._p_pairs(3, "Calculations", calcs))

        elif stage.stage_type in ("PxJoin", "PxMerge", "PxLookup"):
            # Join: Name, Main Table, Main Table Alias, Joins, Join Expressions
            main_lnk = link_map.get(stage.input_links[0]) if stage.input_links else None
            main_src = main_lnk.source_stage_name if main_lnk else stage.name
            params.update(self._p1(2, "Main Table", main_src))
            params.update(self._p1(3, "Main Table Alias", "main"))
            joins = [
                (
                    (link_map[lname].source_stage_name if lname in link_map else lname),
                    "lookup",
                    "Inner",
                )
                for lname in stage.input_links[1:]
            ]
            if joins:
                params.update(self._p_triples(4, "Joins", joins))
            # Output Columns from output links
            out_cols = [
                c.name
                for lname in stage.output_links
                for c in (link_map[lname].columns if lname in link_map else [])
            ]
            if out_cols:
                params.update(self._p_list(6, "Output Columns", out_cols))

        elif stage.stage_type == "PxFilter":
            # Filter Rows: Name, Filter Conditions
            params.update(self._p1(2, "Combine Conditions", "AND"))

        return params

    # ── layout ─────────────────────────────────────────────────────────────────

    @staticmethod
    def _layout_x(stage: DSStage) -> int:
        if not stage.input_links:
            return 96
        if not stage.output_links:
            return 576
        return 272

    # ── orchestration job support ──────────────────────────────────────────────
    # Based on mattilion_sample/sample-002.json pattern:
    #   Start → start_process (rev.1) → Database Query (MSSQL → Snowflake)

    _ORCH_START_IMPL         = 444132438    # "Start" component
    _ORCH_START_PROCESS_IMPL = 1383291531   # "start_process (rev.1)"
    _ORCH_DB_QUERY_IMPL      = -741198691   # "Database Query" (same as _IMPL["sql_query"])

    def _is_orchestration(self, job: DSJob) -> bool:
        """True when the job contains a Pxsqlsvr source stage with user-defined SQL."""
        return any(
            s.stage_type == "Pxsqlsvr" and s.properties.get("selection") == "userquery"
            for s in job.stages
        )

    def _db_query_params(self, name: str, sql: str) -> dict:
        """Build Database Query parameters from the BINGO_TBL_HALL_AGR_NBR sample template.

        All parameter slots are copied from mattilion_sample/sample-002.json.
        slot 1 (Name) and slot 14 (Target Table) use the original DataStage stage name.
        Only slot 8 (SQL Query) is replaced with the actual DataStage query.
        """
        def _s(slot, name, value, visible=True, vtype="STRING"):
            return {str(slot): {
                "slot": slot, "name": name,
                "elements": {"1": {"slot": 1, "values": {
                    "1": {"slot": 1, "type": vtype, "value": value}
                }}},
                "visible": visible,
            }}

        def _empty(slot, name, visible=True):
            return {str(slot): {"slot": slot, "name": name, "elements": {}, "visible": visible}}

        params: dict = {}
        params.update(_s(1,   "Name",                   name))
        params.update(_s(2,   "Database Type",           "SQL Server (Microsoft Driver)"))
        params.update(_s(3,   "Connection URL",          "${BINGO_SRC_CONN_STR}"))
        params.update(_s(6,   "Username",                "${BINGO_SRC_USER_NAME}"))
        params.update(_s(7,   "Password",                "${BINGO_SRC_PWD}",         vtype="PASSWORD"))
        params.update(_s(8,   "SQL Query",               self._fmt_sql(sql)))         # ← actual SQL
        params.update(_s(9,   "Database",                "${LND_DB_NAME}"))
        params.update(_empty(11, "Connection Options"))
        params.update(_s(12,  "Concurrency",             "2",   visible=False, vtype="INTEGER"))
        params.update(_s(13,  "Schema",                  "${BINGO_SCHEMA_NAME}"))
        params.update(_s(14,  "Target Table",            name))
        params.update(_s(15,  "Warehouse",               "${VWH_NAME}"))
        params.update(_s(16,  "S3 Staging Area",         "cac1-dev-s3-mssql",        visible=False))
        params.update(_empty(17, "Primary Keys"))
        params.update(_s(20,  "Data Schema",             "",    visible=False))
        params.update(_s(101, "Basic/Advanced Mode",     "Advanced"))
        params.update(_s(102, "Data Source",             "",    visible=False))
        params.update(_empty(103, "Data Selection",      False))
        params.update(_empty(104, "Data Source Filter",  False))
        params.update(_s(105, "Combine Filters",         "And", visible=False))
        params.update(_s(106, "Limit",                   "100", visible=False, vtype="INTEGER"))
        params.update(_empty(1001, "",                   False))
        params.update(_s(1992, "Warehouse",              "[Environment Default]", visible=False))
        params.update(_s(1993, "Use Accelerated Endpoint", "False",             visible=False))
        params.update(_s(1994, "Stage",                  "",    visible=False))
        params.update(_s(1995, "Stage Schema",           "[Environment Default]", visible=False))
        params.update(_s(1996, "Stage Database",         "[Environment Default]", visible=False))
        params.update(_s(1997, "New Table Name",         "",    visible=False))
        params.update(_s(1998, "Schema",                 "[Environment Default]", visible=False))
        params.update(_s(1999, "Database",               "[Environment Default]", visible=False))
        params.update(_s(2000, "Type",                   "Standard"))
        params.update(_s(40000, "Encryption",            "None", visible=False))
        params.update(_s(40001, "KMS Key ID",            "",    visible=False))
        params.update(_empty(40501, "",                  False))
        params.update({"40502": {
            "slot": 40502, "name": "Load Options",
            "elements": {
                "1": {"slot": 1, "values": {"1": {"slot": 1, "type": "STRING", "value": "On"}}},
                "2": {"slot": 2, "values": {"1": {"slot": 1, "type": "STRING", "value": "Off"}}},
                "3": {"slot": 3, "values": {"1": {"slot": 1, "type": "STRING", "value": "On"}}},
                "4": {"slot": 4, "values": {"1": {"slot": 1, "type": "STRING", "value": ""}}},
                "5": {"slot": 5, "values": {"1": {"slot": 1, "type": "STRING", "value": "On"}}},
                "6": {"slot": 6, "values": {"1": {"slot": 1, "type": "STRING", "value": "Gzip"}}},
            },
            "visible": True,
        }})
        params.update(_s(63319, "Stage Authentication",  "Credentials", visible=False))
        params.update(_s(63320, "Storage Account",       "",    visible=False))
        params.update(_s(63321, "Blob Container",        "",    visible=False))
        params.update(_s(63322, "Storage Integration",   "",    visible=False))
        params.update(_s(84533, "Storage Integration",   "",    visible=False))
        params.update(_empty(88340, "",                  False))
        params.update(_s(88341, "Stage Platform",        "Snowflake Managed"))
        params.update(_s(88342, "Stage Authentication",  "Credentials", visible=False))
        params.update(_s(88343, "Storage Integration",   "",    visible=False))
        params.update(_s(88344, "Use Accelerated Endpoint", "False", visible=False))
        params.update(_s(88345, "Stage",                 "[Custom]"))
        params.update(_s(98776, "GCS Staging Area",      "",    visible=False))
        return params

    def _render_orchestration_job(self, job: DSJob, job_id: int, now_ms: int) -> dict:
        """Render a Matillion ORCHESTRATION job matching the sample-002.json pattern.

        Pattern: Start 0 →(unconditional)→ start_process (rev.1) →(success)→ [all DS stages]
        Stages are ordered: sources → transforms → targets.
        Each DS stage is chained to the next via a success connector.
        Pxsqlsvr+userquery stages use the Database Query component (BINGO template);
        all other stages use their mapped Matillion component with _build_params().
        Original DataStage stage names are preserved in slot 1 of every component.
        """
        offset   = (job_id - self._JOB_BASE) * 10_000
        link_map = {lnk.name: lnk for lnk in job.links}

        # Sort stages: sources (no inputs) → transforms (both) → targets (no outputs)
        def _stage_order(s: DSStage) -> int:
            if not s.input_links:  return 0
            if not s.output_links: return 2
            return 1
        stages = sorted(job.stages, key=_stage_order)

        start_id = self._COMP_BASE + offset + 1
        sp_id    = self._COMP_BASE + offset + 2
        # DS stage component IDs start at offset+3
        stage_cids = {s.id: self._COMP_BASE + offset + 3 + i for i, s in enumerate(stages)}

        # Connector IDs:
        #   CONN_BASE+offset+1 : Start →(unc)→ start_process
        #   CONN_BASE+offset+2 : start_process →(succ)→ stages[0]
        #   CONN_BASE+offset+3 : stages[0] →(succ)→ stages[1]  …
        #   CONN_BASE+offset+2+i : connector INTO stages[i]
        unc_cid = self._CONN_BASE + offset + 1

        def _make_comp(cid, impl, inp_card, out_card, hint, exec_hint, x, params,
                       input_cids=(), out_succ=(), out_unc=()):
            return {
                "id": cid,
                "inputCardinality": inp_card, "outputCardinality": out_card,
                "connectorHint": hint, "executionHint": exec_hint,
                "implementationID": impl,
                "x": x, "y": -16, "width": 32, "height": 32,
                "inputConnectorIDs":               list(input_cids),
                "outputSuccessConnectorIDs":       list(out_succ),
                "outputFailureConnectorIDs":       [],
                "outputUnconditionalConnectorIDs": list(out_unc),
                "outputTrueConnectorIDs": [], "outputFalseConnectorIDs": [],
                "exportMappings": {}, "parameters": params,
                "expectedFailure": None, "activationStatus": "ENABLED",
                "outputIterationConnectorIDs": [], "inputIterationConnectorIDs": [],
            }

        # ── fixed components: Start + start_process ────────────────────────────
        sp_in_cid = self._CONN_BASE + offset + 2     # start_process → stages[0]
        start_params = {"1": {
            "slot": 1, "name": "Start",
            "elements": {"1": {"slot": 1, "values": {"1": {"slot": 1, "type": "STRING", "value": "Start 0"}}}},
            "visible": True,
        }}
        sp_params = {
            "1": {"slot": 1, "name": "Name",    "elements": {"1": {"slot": 1, "values": {"1": {"slot": 1, "type": "STRING", "value": "start_process"}}}}, "visible": True},
            "2": {"slot": 2, "name": "JobName", "elements": {"1": {"slot": 1, "values": {"1": {"slot": 1, "type": "STRING", "value": "${job_name}"}}}},    "visible": True},
        }
        components: dict = {
            str(start_id): _make_comp(start_id, self._ORCH_START_IMPL,         "ZERO", "MANY",
                                      "UNCONDITIONAL", "FLOW", -1360, start_params, out_unc=(unc_cid,)),
            str(sp_id):    _make_comp(sp_id,    self._ORCH_START_PROCESS_IMPL, "ONE",  "MANY",
                                      "SUCCESS_FAIL", "EXECUTE", -1168, sp_params,
                                      input_cids=(unc_cid,),
                                      out_succ=(sp_in_cid,) if stages else ()),
        }

        # ── DataStage stage components ──────────────────────────────────────────
        success_connectors: dict = {}
        if stages:
            first_cid = stage_cids[stages[0].id]
            success_connectors[str(sp_in_cid)] = {"id": sp_in_cid, "sourceID": sp_id, "targetID": first_cid}

        for i, stage in enumerate(stages):
            comp_id  = stage_cids[stage.id]
            in_cid   = self._CONN_BASE + offset + 2 + i           # connector INTO this stage
            out_cid  = self._CONN_BASE + offset + 3 + i           # connector OUT to next (if any)
            out_succ = (out_cid,) if i < len(stages) - 1 else ()

            if i < len(stages) - 1:
                next_cid = stage_cids[stages[i + 1].id]
                success_connectors[str(out_cid)] = {"id": out_cid, "sourceID": comp_id, "targetID": next_cid}

            is_sql = stage.stage_type == "Pxsqlsvr" and stage.properties.get("selection") == "userquery"
            if is_sql:
                sql    = stage.properties.get("query", "")
                params = self._db_query_params(stage.name, sql)
                impl   = self._ORCH_DB_QUERY_IMPL
            else:
                comp_key = self._resolve_key(stage)
                params   = self._build_params(stage, link_map)
                impl     = self._IMPL[comp_key]

            components[str(comp_id)] = _make_comp(
                comp_id, impl, "ONE", "MANY", "SUCCESS_FAIL", "EXECUTE",
                -960 + i * 192, params, input_cids=(in_cid,), out_succ=out_succ,
            )

        # ── notes + connectors ─────────────────────────────────────────────────
        note_id = job_id + 1
        notes = {str(note_id): {
            "id": note_id, "x": -1343, "y": -232, "width": 605, "height": 96,
            "text": (
                f"Job: {job.name}\n"
                f"Source: {job.source_file} ({job.source_format})\n"
                f"Server: {job.server_name} v{job.server_version} | "
                f"Modified: {job.date_modified} | Category: {job.category}"
            ),
            "colour": "e6e63c",
        }}

        return {
            "id": job_id, "revision": 1,
            "created": now_ms, "timestamp": now_ms,
            "components": components,
            "successConnectors":       success_connectors,
            "failureConnectors":       {},
            "unconditionalConnectors": {str(unc_cid): {"id": unc_cid, "sourceID": start_id, "targetID": sp_id}},
            "trueConnectors": {}, "falseConnectors": {}, "iterationConnectors": {},
            "noteConnectors": {},
            "canUndo": False, "undoCommand": "", "undoCreated": 0,
            "canRedo": False, "redoCommand": "", "redoCreated": -1,
            "notes": notes, "variables": {}, "grids": {},
        }

    # ── main job renderer ──────────────────────────────────────────────────────

    def _render_job(self, job: DSJob, job_id: int, now_ms: int) -> dict:
        offset = (job_id - self._JOB_BASE) * 10_000

        # Build a link name → DSLink lookup for parameter building
        link_map: dict[str, DSLink] = {lnk.name: lnk for lnk in job.links}

        # Assign component IDs
        stage_comp: dict[str, int] = {
            stage.id: self._COMP_BASE + offset + idx + 1
            for idx, stage in enumerate(job.stages)
        }

        # Build components
        components: dict[str, dict] = {}
        for idx, stage in enumerate(job.stages):
            comp_id = stage_comp[stage.id]
            comp_key = self._resolve_key(stage)
            inp_card, out_card = self._FIXED_CARDINALITY[comp_key]
            components[str(comp_id)] = {
                "id": comp_id,
                "inputCardinality": inp_card,
                "outputCardinality": out_card,
                "implementationID": self._IMPL[comp_key],
                "x": self._layout_x(stage),
                "y": 96 + idx * 96,
                "width": 32,
                "height": 32,
                "inputConnectorIDs": [],
                "outputConnectorIDs": [],
                "parameters": self._build_params(stage, link_map),
                "exportMappings": {},
                "expectedFailure": None,
                "activationStatus": "ENABLED",
            }

        # Build connectors and wire up IDs on components
        connectors: dict[str, dict] = {}
        for idx, link in enumerate(job.links):
            src_id = stage_comp.get(link.source_stage_id)
            tgt_id = stage_comp.get(link.target_stage_id)
            if src_id is None or tgt_id is None:
                continue
            conn_id = self._CONN_BASE + offset + idx + 1
            connectors[str(conn_id)] = {"id": conn_id, "sourceID": src_id, "targetID": tgt_id}
            components[str(src_id)]["outputConnectorIDs"].append(conn_id)
            components[str(tgt_id)]["inputConnectorIDs"].append(conn_id)

        # Variables from DataStage parameters
        variables: dict[str, dict] = {
            p.name: {
                "definition": {
                    "name": p.name, "type": "TEXT", "scope": "BRANCH",
                    "description": p.prompt, "visibility": "PUBLIC",
                },
                "value": p.default,
            }
            for p in job.parameters
        }

        note_id = job_id + 1
        notes = {str(note_id): {
            "id": note_id, "x": 0, "y": -80, "width": 600, "height": 80,
            "text": (
                f"Job: {job.name}\n"
                f"Source: {job.source_file} ({job.source_format})\n"
                f"Server: {job.server_name} v{job.server_version} | "
                f"Modified: {job.date_modified} | Category: {job.category}"
            ),
            "colour": "e6e63c",
        }}

        return {
            "id": job_id, "revision": 1,
            "created": now_ms, "timestamp": now_ms,
            "components": components, "connectors": connectors,
            "canUndo": False, "undoCommand": "", "undoCreated": 0,
            "canRedo": False, "redoCommand": "", "redoCreated": 0,
            "notes": notes, "noteConnectors": {}, "variables": variables, "grids": {},
        }


# ─── Matillion Claude Exporter ─────────────────────────────────────────────────

class MatillionClaudeExporter:
    """Output 3: Matillion Claude AI-context JSON for migration assistance."""

    def export(self, jobs: list[DSJob], output_path: Path) -> None:
        payload = {
            "version": "1.0",
            "format": "matillion-claude-context",
            "purpose": "DataStage to Matillion AI-assisted migration",
            "metadata": {
                "exported_at": datetime.now().isoformat(),
                "job_count": len(jobs),
            },
            "jobs": [self._render_job(job) for job in jobs],
        }
        output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        log.info("Matillion Claude JSON written → %s", output_path)

    def _render_job(self, job: DSJob) -> dict:
        sources = [s for s in job.stages if s.category in ("File", "Database", "Source")]
        targets = [s for s in job.stages if s.category in ("File", "Database") and s.output_links == []]
        transforms = [s for s in job.stages if s.category in ("Transform", "Join", "Lookup")]

        # Build column lineage list
        lineage_entries = []
        for lnk in job.links:
            for col in lnk.columns:
                if col.derivation or col.source_column:
                    lineage_entries.append({
                        "target_stage": lnk.target_stage_name,
                        "link": lnk.name,
                        "column": col.name,
                        "sql_type": col.sql_type,
                        "derivation": col.derivation,
                        "source": col.source_column,
                    })

        # Migration notes
        notes = []
        for stage in job.stages:
            if stage.stage_type == "CTransformerStage":
                notes.append(f"Stage '{stage.name}' (Transformer) — review column derivations and map to Matillion Calculator component.")
            elif stage.stage_type in ("Pxsqlsvr",):
                notes.append(f"Stage '{stage.name}' (SQL Server) — extract and parameterise SQL query for Matillion SQL component.")
            elif stage.stage_type == "PxJoin":
                notes.append(f"Stage '{stage.name}' (Join) — identify join keys and join type (inner/left/right) for Matillion Join component.")

        return {
            "job_name": job.name,
            "identifier": job.identifier,
            "job_type": job.job_type,
            "server": job.server_name,
            "category": job.category,
            "summary": (
                f"{job.job_type} job with {len(job.stages)} stage(s) and "
                f"{len(job.links)} link(s). "
                f"Sources: {len(sources)}, Targets: {len(targets)}, Transforms: {len(transforms)}."
            ),
            "parameters": [
                {"name": p.name, "prompt": p.prompt, "default": p.default}
                for p in job.parameters
            ],
            "data_sources": [
                {"name": s.name, "type": s.stage_type, "outputs": s.output_links}
                for s in sources
            ],
            "data_targets": [
                {"name": s.name, "type": s.stage_type, "inputs": s.input_links}
                for s in targets
            ],
            "transformations": [
                {"name": s.name, "type": s.stage_type, "inputs": s.input_links, "outputs": s.output_links}
                for s in transforms
            ],
            "column_lineage": lineage_entries,
            "migration_notes": notes,
        }


# ─── Batch Processor ───────────────────────────────────────────────────────────

def _safe_name(name: str, max_len: int = 80) -> str:
    """Convert a job name to a filesystem-safe string."""
    safe = re.sub(r"[^\w\-]", "_", name)
    safe = re.sub(r"_+", "_", safe).strip("_")
    return safe[:max_len]


def detect_format(path: Path) -> str:
    ext = path.suffix.lower()
    if ext == ".dsd":
        return "dsd"
    if ext == ".xml":
        return "xml"
    # Peek at first line
    try:
        first = path.read_text(encoding="cp1252", errors="replace")[:50]
        if first.strip().startswith("<?xml"):
            return "xml"
        if "BEGIN HEADER" in first or "BEGIN DSJOB" in first:
            return "dsd"
    except Exception:
        pass
    return "unknown"


def load_jobs(path: Path, fmt: str = "auto") -> list[DSJob]:
    if fmt == "auto":
        fmt = detect_format(path)
    if fmt == "dsd":
        return DSDParser().parse(path)
    if fmt == "xml":
        return XMLParser().parse(path)
    raise ValueError(f"Unsupported format '{fmt}' for file: {path}")


def _write_structured_log(
    log_path: Path,
    input_path: Path,
    jobs: list[DSJob],
    skipped: Optional[list[tuple[str, str]]] = None,
    format_sql: bool = False,
) -> None:
    """Write a tab-indented structured log: File → Job → Component → Metadata/Parameters."""
    _etl = MatillionETLExporter()
    lines: list[str] = []
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    sql_note = "  [SQL formatted with SQLFluff/tsql]" if format_sql else ""
    lines.append(f"[{ts}] File: {input_path}{sql_note}")

    # Skipped jobs (filtered by inclusion/exclusion lists)
    for job_name, reason in (skipped or []):
        lines.append(f"\tJob: {job_name}  [SKIPPED: {reason}]")

    for job in jobs:
        link_map: dict[str, DSLink] = {lnk.name: lnk for lnk in job.links}
        lines.append(f"\tJob: {job.name}")
        lines.append(f"\t\ttype: {job.job_type}  modified: {job.date_modified}  server: {job.server_name}")

        for stage in job.stages:
            comp_key = _etl._resolve_key(stage)
            inp_card, out_card = _etl._FIXED_CARDINALITY[comp_key]
            impl_id = _etl._IMPL[comp_key]
            params = _etl._build_params(stage, link_map)

            lines.append(f"\t\tComponent: {stage.name}  ({stage.stage_type})")
            lines.append(f"\t\t\tMetadata:")
            lines.append(f"\t\t\t\tmatillion-key:     {comp_key}")
            lines.append(f"\t\t\t\timplementationID:  {impl_id}")
            lines.append(f"\t\t\t\tinputCardinality:  {inp_card}")
            lines.append(f"\t\t\t\toutputCardinality: {out_card}")
            lines.append(f"\t\t\t\tcategory:          {stage.category}")
            if stage.input_links:
                lines.append(f"\t\t\t\tinput-links:       {', '.join(stage.input_links)}")
            if stage.output_links:
                lines.append(f"\t\t\t\toutput-links:      {', '.join(stage.output_links)}")

            lines.append(f"\t\t\tParameters:")
            for _slot, param in sorted(params.items(), key=lambda x: int(x[0])):
                pname = param.get("name", "")
                elements = param.get("elements", {})
                multi = len(elements) > 1
                for eidx, (_ekey, elem) in enumerate(
                    sorted(elements.items(), key=lambda x: int(x[0])), 1
                ):
                    vals = [
                        v.get("value", "")
                        for v in sorted(
                            elem.get("values", {}).values(), key=lambda v: v.get("slot", 0)
                        )
                        if v.get("value", "")
                    ]
                    val_str = " | ".join(vals)
                    label = f"{pname}[{eidx}]" if multi else pname
                    # Multi-line values (e.g. SQL) — indent continuation lines
                    if "\n" in val_str:
                        first, *rest = val_str.splitlines()
                        lines.append(f"\t\t\t\t{label}: {first}")
                        for cont in rest:
                            lines.append(f"\t\t\t\t\t{cont}")
                    else:
                        lines.append(f"\t\t\t\t{label}: {val_str}")

    lines.append("")  # blank separator between files

    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    log.info("Structured log appended → %s", log_path)


def process_file(
    input_path: Path,
    output_dir: Path,
    fmt: str = "auto",
    prefix: str = "",
    do_markdown: bool = True,
    do_etl: bool = True,
    do_claude: bool = True,
    split: bool = True,
    log_file: Optional[Path] = None,
    include_jobs: Optional[list[str]] = None,
    exclude_jobs: Optional[list[str]] = None,
    format_sql: bool = False,
) -> None:
    log.info("Processing: %s", input_path)
    jobs = load_jobs(input_path, fmt)
    if not jobs:
        log.warning("No jobs found in: %s", input_path)
        return
    log.info("  Found %d job(s)", len(jobs))

    # Apply inclusion / exclusion filters
    active: list[DSJob] = []
    skipped: list[tuple[str, str]] = []
    for job in jobs:
        if include_jobs is not None and job.name not in include_jobs:
            skipped.append((job.name, "not in job_inclusion_list"))
            log.info("  Skipping job (not in job_inclusion_list): %s", job.name)
            continue
        if exclude_jobs is not None and job.name in exclude_jobs:
            skipped.append((job.name, "in job_exclusion_list"))
            log.info("  Skipping job (in job_exclusion_list): %s", job.name)
            continue
        active.append(job)
    jobs = active

    output_dir.mkdir(parents=True, exist_ok=True)

    if split:
        # One set of output files per job, named after the job
        for job in jobs:
            stem = prefix + _safe_name(job.name)
            if do_markdown:
                MarkdownExporter().export([job], output_dir / f"{stem}_lineage.md")
            if do_etl:
                MatillionETLExporter(format_sql=format_sql).export([job], output_dir / f"{stem}_matillion_etl.json")
            if do_claude:
                MatillionClaudeExporter().export([job], output_dir / f"{stem}_matillion_claude.json")
    else:
        # All jobs from the source file combined into one output file
        stem = prefix + input_path.stem
        if do_markdown:
            MarkdownExporter().export(jobs, output_dir / f"{stem}_lineage.md")
        if do_etl:
            MatillionETLExporter(format_sql=format_sql).export(jobs, output_dir / f"{stem}_matillion_etl.json")
        if do_claude:
            MatillionClaudeExporter().export(jobs, output_dir / f"{stem}_matillion_claude.json")

    if log_file:
        _write_structured_log(log_file, input_path, jobs, skipped=skipped, format_sql=format_sql)


def run_batch(config_path: Path) -> None:
    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8"))

    log.info("Batch config: %s", config_path)

    g = cfg.get("global", {})

    # Apply log_level from global section if present
    log_level_cfg = g.get("log_level", "INFO")
    logging.getLogger("ds_transform").setLevel(getattr(logging, log_level_cfg, logging.INFO))

    input_dir = Path(g.get("input_directory", "."))
    output_dir = Path(g.get("output_directory", "output"))
    prefix = g.get("output_prefix", "")

    outputs = g.get("outputs", {})
    do_md = outputs.get("markdown", True)
    do_etl = outputs.get("matillion_etl", True)
    do_claude = outputs.get("matillion_claude", True)
    split = bool(g.get("split", True))
    recursive = bool(g.get("recursive", False))
    log_file_cfg = g.get("log_file")
    log_file = Path(datetime.now().strftime(log_file_cfg)) if log_file_cfg else None
    format_sql = bool(g.get("format_sql", False))

    incl_cfg = cfg.get("job_inclusion_list", {})
    excl_cfg = cfg.get("job_exclusion_list", {})
    include_jobs: Optional[list[str]] = incl_cfg.get("jobs") if incl_cfg.get("process") else None
    exclude_jobs: Optional[list[str]] = excl_cfg.get("jobs") if excl_cfg.get("process") else None

    files_cfg = cfg.get("files", [])
    if files_cfg:
        for entry in files_cfg:
            path_str = entry["path"]
            fmt = entry.get("format", "auto")
            # Expand glob patterns (e.g. "ds_sample/*.xml"); treat plain paths literally
            if any(c in path_str for c in ("*", "?", "[")):
                matched = sorted(Path().glob(path_str))
                if not matched:
                    log.warning("No files matched pattern: %s", path_str)
                for fp in matched:
                    process_file(fp, output_dir, fmt, prefix, do_md, do_etl, do_claude, split,
                                 log_file=log_file, include_jobs=include_jobs, exclude_jobs=exclude_jobs,
                                 format_sql=format_sql)
            else:
                process_file(Path(path_str), output_dir, fmt, prefix, do_md, do_etl, do_claude, split,
                             log_file=log_file, include_jobs=include_jobs, exclude_jobs=exclude_jobs,
                             format_sql=format_sql)
    else:
        # Auto-discover all .dsd and .xml files in input_directory
        discover = input_dir.rglob if recursive else input_dir.glob
        patterns = ["*.dsd", "*.xml"]
        for pattern in patterns:
            for fp in sorted(discover(pattern)):
                process_file(fp, output_dir, "auto", prefix, do_md, do_etl, do_claude, split,
                             log_file=log_file, include_jobs=include_jobs, exclude_jobs=exclude_jobs,
                             format_sql=format_sql)


# ─── CLI ───────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="DataStage → Matillion transformation tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--config", "-c", type=Path, help="YAML batch config file")
    parser.add_argument("--file", "-f", type=Path, help="Single DataStage file (.dsd or .xml)")
    parser.add_argument("--output", "-o", type=Path, default=Path("output"), help="Output directory (default: output/)")
    parser.add_argument("--format", choices=["auto", "dsd", "xml"], default="auto", help="Input format override")
    parser.add_argument("--no-markdown", action="store_true", help="Skip Markdown output")
    parser.add_argument("--no-etl", action="store_true", help="Skip Matillion ETL output")
    parser.add_argument("--no-claude", action="store_true", help="Skip Matillion Claude output")
    parser.add_argument(
        "--no-split", action="store_true",
        help="Combine all jobs from one file into a single output (default: split per job)",
    )
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    parser.add_argument(
        "--log-file", type=Path, default=None,
        help="Path for structured processing log (appended on each run)",
    )
    parser.add_argument(
        "--format-sql", action="store_true", default=False,
        help="Format SQL queries with SQLFluff (T-SQL dialect) before writing to output",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if args.config:
        run_batch(args.config)
    elif args.file:
        process_file(
            args.file,
            args.output,
            args.format,
            do_markdown=not args.no_markdown,
            do_etl=not args.no_etl,
            do_claude=not args.no_claude,
            split=not args.no_split,
            log_file=args.log_file,
            format_sql=args.format_sql,
        )
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
