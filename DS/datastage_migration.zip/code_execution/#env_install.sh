#!/usr/bin/env bash
# ============================================================
#  DataStage Transformation Tool - Install / Setup
# ============================================================
set -euo pipefail
cd "$(dirname "$0")/.."

echo
echo "============================================================"
echo " DataStage Transformation Tool - Install / Setup"
echo "============================================================"
echo

# --- Step 1: Check for UV, install if missing ---
echo "[1/2] Checking for UV package manager..."
if ! command -v uv &>/dev/null; then
    echo "  UV not found. Installing UV..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    # Reload PATH so uv is available in this session
    export PATH="$HOME/.local/bin:$PATH"
    if ! command -v uv &>/dev/null; then
        echo "ERROR: UV installation failed."
        echo "  Please install manually: https://docs.astral.sh/uv/getting-started/installation/"
        exit 1
    fi
    echo "  UV installed successfully."
else
    echo "  Found: $(uv --version)"
fi
echo

# --- Step 2: Sync dependencies ---
echo "[2/2] Syncing project dependencies with UV..."
uv sync
echo

echo "Done!"
