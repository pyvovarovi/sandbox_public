@echo off
REM ============================================================
REM  DataStage Transformation Tool - Demo 2 (demo-002.xml)
REM ============================================================
cd /d "%~dp0\.."
setlocal enabledelayedexpansion

echo.
echo ============================================================
echo  DataStage Transformation Tool - Demo 2
echo ============================================================
echo.

REM --- Sync dependencies ---
echo [1/5] Syncing dependencies with UV...
uv sync
if errorlevel 1 (
    echo ERROR: uv sync failed. Make sure UV is installed.
    exit /b 1
)
echo.

:: REM --- Scenario 1: All outputs ---
:: echo [2/5] Scenario 1: All outputs (Markdown + Matillion ETL + Matillion Claude)
:: echo   Input:  ds_sample\demo-002.xml
:: echo   Output: output\demo-002\
:: echo.
:: uv run ds_transformation.py --file ds_sample\demo-002.xml --output output\demo-002 --format xml
:: if errorlevel 1 ( echo ERROR in Scenario 1 & exit /b 1 )
:: echo   Done.
:: echo.
:: 
:: REM --- Scenario 2: Markdown only ---
:: echo [3/5] Scenario 2: Markdown lineage only
:: echo   Input:  ds_sample\demo-002.xml
:: echo   Output: output\demo-002-md\
:: echo.
:: uv run ds_transformation.py --file ds_sample\demo-002.xml --output output\demo-002-md --format xml --no-etl --no-claude
:: if errorlevel 1 ( echo ERROR in Scenario 2 & exit /b 1 )
:: echo   Done.
:: echo.
:: 
:: REM --- Scenario 3: Matillion outputs only ---
:: echo [4/5] Scenario 3: Matillion outputs only
:: echo   Input:  ds_sample\demo-002.xml
:: echo   Output: output\demo-002-matillion\
:: echo.
:: uv run ds_transformation.py --file ds_sample\demo-002.xml --output output\demo-002-matillion --format xml --no-markdown
:: if errorlevel 1 ( echo ERROR in Scenario 3 & exit /b 1 )
:: echo   Done.
:: echo.

REM --- Scenario 4: YAML config file ---
echo [5/5] Scenario 4: Via YAML config (code_execution\demo-2.yaml)
echo   Input:  ds_sample\demo-002.xml  (defined in YAML)
echo   Output: output\demo-002-yaml\
echo.
uv run ds_transformation.py --config code_execution\demo-2.yaml
if errorlevel 1 ( echo ERROR in Scenario 4 & exit /b 1 )
echo   Done.
echo.

:: REM --- Summary ---
:: echo ============================================================
:: echo  All scenarios completed. Output files:
:: echo ============================================================
:: for /r output\demo-002 %%f in (*.md *.json) do echo   %%f
:: for /r output\demo-002-md %%f in (*.md *.json) do echo   %%f
:: for /r output\demo-002-matillion %%f in (*.md *.json) do echo   %%f
:: for /r output\demo-002-yaml %%f in (*.md *.json *.log) do echo   %%f
echo.
echo Done!
endlocal
cd /d "%~dp0"
