@echo off
REM ============================================================
REM  DataStage Transformation Tool - Demo and Test Scenarios
REM ============================================================
cd /d "%~dp0\.."
setlocal enabledelayedexpansion

echo.
echo ============================================================
echo  DataStage Transformation Tool - Demo
echo ============================================================
echo.

REM --- Sync dependencies ---
echo [1/5] Syncing dependencies with UV...
uv sync
if errorlevel 1 (
    echo ERROR: uv sync failed. Make sure UV is installed.
    exit /b 1
)
echo.

REM --- Scenario 1: Batch processing via YAML config ---
echo [2/5] Scenario 1: Batch processing (YAML config)
echo   Input:  ds_sample\demo.dsd + ds_sample\demo.xml
echo   Config: batch_config.yaml
echo   Output: output\
echo.
uv run ds_transformation.py --config code_execution\batch_config.yaml
if errorlevel 1 ( echo ERROR in Scenario 1 & exit /b 1 )
echo   Done.
echo.

REM --- Scenario 2: Single DSD file, all outputs ---
echo [3/5] Scenario 2: Single DSD file
echo   Input:  ds_sample\demo.dsd
echo   Output: output\single_dsd\
echo.
uv run ds_transformation.py --file ds_sample\demo.dsd --output output\single_dsd
if errorlevel 1 ( echo ERROR in Scenario 2 & exit /b 1 )
echo   Done.
echo.

REM --- Scenario 3: Single XML file, Markdown only ---
echo [4/5] Scenario 3: XML file - Markdown output only
echo   Input:  ds_sample\demo.xml
echo   Output: output\xml_md_only\
echo.
uv run ds_transformation.py --file ds_sample\demo.xml --output output\xml_md_only --no-etl --no-claude
if errorlevel 1 ( echo ERROR in Scenario 3 & exit /b 1 )
echo   Done.
echo.

REM --- Scenario 4: Single XML, Matillion outputs only ---
echo [5/5] Scenario 4: XML file - Matillion outputs only
echo   Input:  ds_sample\demo.xml
echo   Output: output\xml_matillion\
echo.
uv run ds_transformation.py --file ds_sample\demo.xml --output output\xml_matillion --no-markdown
if errorlevel 1 ( echo ERROR in Scenario 4 & exit /b 1 )
echo   Done.
echo.

REM --- Summary ---
echo ============================================================
echo  All scenarios completed. Output files:
echo ============================================================
for /r output %%f in (*.md *.json) do echo   %%f
echo.
echo Done!
endlocal
cd /d "%~dp0"
