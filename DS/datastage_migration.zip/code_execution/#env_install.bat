@echo off
REM ============================================================
REM  DataStage Transformation Tool - Install / Setup
REM ============================================================
cd /d "%~dp0\.."
setlocal enabledelayedexpansion

echo.
echo ============================================================
echo  DataStage Transformation Tool - Install / Setup
echo ============================================================
echo.

REM --- Step 1: Check for UV, install if missing ---
echo [1/2] Checking for UV package manager...
where uv >nul 2>&1
if errorlevel 1 (
    echo   UV not found. Installing UV via PowerShell...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
    if errorlevel 1 (
        echo ERROR: UV installation failed.
        echo   Please install manually: https://docs.astral.sh/uv/getting-started/installation/
        exit /b 1
    )
    REM Refresh PATH so uv is available in this session
    for /f "tokens=*" %%i in ('powershell -NoProfile -Command "[System.Environment]::GetEnvironmentVariable(\"PATH\",\"User\")"') do set "PATH=%%i;%PATH%"
    echo   UV installed successfully.
) else (
    for /f "tokens=*" %%v in ('uv --version 2^>nul') do echo   Found: %%v
)
echo.

REM --- Step 2: Sync dependencies ---
echo [2/2] Syncing project dependencies with UV...
uv sync
if errorlevel 1 (
    echo ERROR: uv sync failed.
    exit /b 1
)
echo.


REM --- Summary ---
echo.
echo Done!
endlocal
cd /d "%~dp0"
