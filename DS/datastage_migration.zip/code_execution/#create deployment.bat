@echo off
REM ============================================================
REM  DataStage Transformation Tool - Create Deployment Package
REM  Creates deployment\datastage_migration.zip with all files
REM  required to run the tool. Excludes sample and output data.
REM  Requires: 7-Zip (7z.exe) installed.
REM ============================================================
cd /d "%~dp0\.."
setlocal

set "DEPLOY_DIR=deployment"
set "ZIP_FILE=%DEPLOY_DIR%\datastage_migration.zip"

echo.
echo ============================================================
echo  DataStage Transformation Tool - Create Deployment Package
echo ============================================================
echo.

REM --- Locate 7z.exe ---
set "SEVENZIP="
where 7z >nul 2>&1
if not errorlevel 1 set "SEVENZIP=7z"
if not defined SEVENZIP (
    if exist "C:\Program Files\7-Zip\7z.exe" set "SEVENZIP=C:\Program Files\7-Zip\7z.exe"
)
if not defined SEVENZIP (
    echo ERROR: 7-Zip not found.
    echo        Please install 7-Zip: https://www.7-zip.org/
    echo        Or add 7z.exe to PATH.
    exit /b 1
)
echo 7-Zip: %SEVENZIP%
echo.

REM ============================================================
REM  Files to be deployed
REM ============================================================
echo Files to be deployed:
echo.
echo   [Root]
for %%f in (ds_transformation.py pyproject.toml uv.lock .python-version .gitattributes .gitignore) do (
    if exist "%%f" (echo     %%f) else (echo     %%f  [MISSING])
)
echo.
echo   [code_execution\]
for %%f in (code_execution\*) do echo     code_execution\%%~nxf
echo.

REM ============================================================
REM  Create deployment directory and ZIP
REM ============================================================
if not exist "%DEPLOY_DIR%" (
    mkdir "%DEPLOY_DIR%"
    echo Created directory: %DEPLOY_DIR%
)

if exist "%ZIP_FILE%" (
    del /f /q "%ZIP_FILE%"
    echo Removed existing archive.
)

echo Creating: %ZIP_FILE%
echo.

"%SEVENZIP%" a -tzip "%ZIP_FILE%" ^
    ds_transformation.py ^
    pyproject.toml ^
    uv.lock ^
    .python-version ^
    .gitattributes ^
    .gitignore ^
    code_execution\

if errorlevel 1 (
    echo.
    echo ERROR: 7-Zip failed to create the archive.
    exit /b 1
)

echo.
echo ============================================================
echo  Done.
echo  Deployment archive: %ZIP_FILE%
echo ============================================================
echo.

endlocal
cd /d "%~dp0"
