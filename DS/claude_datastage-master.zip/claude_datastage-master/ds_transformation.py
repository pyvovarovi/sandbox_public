#!/usr/bin/env python3
"""DataStage Transformation Tool

Reads IBM DataStage .dsd / .xml backup files and produces:
  Output 1: Markdown lineage + job documentation  (*_lineage.md)
  Output 2: Matillion ETL import JSON              (*_matillion_etl.json)
  Output 3: Matillion Claude AI-context JSON       (*_matillion_claude.json)

Batch processing is driven by a YAML configuration file.

Usage:
    uv run ds_transformation.py --config batch_config.yaml
    uv run ds_transformation.py --file ds_sample/demo.dsd --output output/
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional
import xml.etree.ElementTree as ET

import yaml

log = logging.getLogger("ds_transform")

# ─── SQL type map ──────────────────────────────────────────────────────────────
SQL_TYPES: dict[str, str] = {
    "1": "CHAR", "2": "NUMERIC", "3": "DECIMAL", "4": "INTEGER",
    "5": "SMALLINT", "6": "FLOAT", "7": "REAL", "8": "DOUBLE",
    "9": "DATE", "10": "TIME", "11": "TIMESTAMP", "12": "VARCHAR",
    "-1": "LONGVARCHAR", "-2": "BINARY", "-3": "VARBINARY",
    "-4": "LONGVARBINARY", "-5": "BIGINT", "-6": "TINYINT",
    "-7": "BIT", "-8": "WCHAR", "-9": "WVARCHAR", "-10": "WLONGVARCHAR",
}

# ─── Stage category map ────────────────────────────────────────────────────────
STAGE_CATEGORY: dict[str, str] = {
    "PxSequentialFile": "File",
    "PxDataSet": "File",
    "PxFTP": "File",
    "Pxsqlsvr": "Database",
    "PxODBC": "Database",
    "PxOracle": "Database",
    "PxDB2": "Database",
    "PxTeradata": "Database",
    "CTransformerStage": "Transform",
    "PxJoin": "Join",
    "PxMerge": "Join",
    "PxLookup": "Lookup",
    "PxSort": "Transform",
    "PxFilter": "Transform",
    "PxAggregator": "Transform",
    "PxPeek": "Debug",
    "PxRowGenerator": "Source",
    "CSequencer": "Control",
    "CRoutineActivity": "Control",
    "CJobActivity": "Control",
    "CExecCommandActivity": "Control",
    "CWaitForFileActivity": "Control",
}

# Matillion component type mapping from DataStage stage types
MATILLION_COMPONENT_MAP: dict[str, str] = {
    "PxSequentialFile": "fixed-width-file-input",
    "Pxsqlsvr": "sql-server-query",
    "PxODBC": "generic-query",
    "PxOracle": "oracle-query",
    "PxDB2": "db2-query",
    "PxTeradata": "teradata-query",
    "CTransformerStage": "calculator",
    "PxJoin": "join",
    "PxMerge": "union",
    "PxLookup": "lookup",
    "PxSort": "sort",
    "PxFilter": "filter-rows",
    "PxAggregator": "aggregate",
    "PxDataSet": "table-input",
}


# ─── Data models ───────────────────────────────────────────────────────────────

@dataclass
class DSParameter:
    name: str
    prompt: str = ""
    default: str = ""
    param_type: str = "0"


@dataclass
class DSColumn:
    name: str
    sql_type: str = ""
    nullable: bool = True
    length: int = 0
    scale: int = 0
    derivation: str = ""
    source_column: str = ""


@dataclass
class DSLink:
    name: str
    source_stage_id: str = ""
    target_stage_id: str = ""
    source_stage_name: str = ""
    target_stage_name: str = ""
    columns: list[DSColumn] = field(default_factory=list)


@dataclass
class DSStage:
    id: str
    name: str
    stage_type: str = ""
    category: str = ""
    input_links: list[str] = field(default_factory=list)
    output_links: list[str] = field(default_factory=list)


@dataclass
class DSJob:
    identifier: str
    name: str
    date_modified: str = ""
    time_modified: str = ""
    job_type: str = "Parallel"
    server_name: str = ""
    server_version: str = ""
    category: str = ""
    parameters: list[DSParameter] = field(default_factory=list)
    stages: list[DSStage] = field(default_factory=list)
    links: list[DSLink] = field(default_factory=list)
    source_file: str = ""
    source_format: str = ""


# ─── DSD Parser ────────────────────────────────────────────────────────────────

class DSDParser:
    """Parses IBM DataStage .dsd export files."""

    _KV_RE = re.compile(r'^\s*(\w+)\s+"(.*?)"\s*$')

    def parse(self, path: Path) -> list[DSJob]:
        text = path.read_text(encoding="cp1252", errors="replace")
        lines = text.splitlines()

        header: dict[str, str] = {}
        i = 0
        while i < len(lines):
            stripped = lines[i].strip()
            if stripped == "BEGIN HEADER":
                block, i = self._collect_block(lines, i + 1, "HEADER")
                header = self._parse_props(block)
            elif stripped == "BEGIN DSJOB":
                break
            else:
                i += 1

        jobs: list[DSJob] = []
        while i < len(lines):
            stripped = lines[i].strip()
            if stripped == "BEGIN DSJOB":
                job_block, i = self._collect_block(lines, i + 1, "DSJOB")
                job = self._parse_job(job_block, header)
                job.source_file = str(path)
                job.source_format = "DSD"
                jobs.append(job)
            else:
                i += 1
        return jobs

    def _collect_block(self, lines: list[str], start: int, end_type: str) -> tuple[list[str], int]:
        block: list[str] = []
        depth = 0
        i = start
        while i < len(lines):
            stripped = lines[i].strip()
            if stripped == f"END {end_type}" and depth == 0:
                return block, i + 1
            if stripped.startswith("BEGIN "):
                depth += 1
            elif stripped.startswith("END ") and depth > 0:
                depth -= 1
            block.append(lines[i])
            i += 1
        return block, i

    def _parse_props(self, lines: list[str]) -> dict[str, str]:
        props: dict[str, str] = {}
        for line in lines:
            m = self._KV_RE.match(line)
            if m:
                props[m.group(1)] = m.group(2)
        return props

    def _parse_subblocks(self, lines: list[str]) -> tuple[dict[str, str], list[tuple[str, list[str]]]]:
        """Return (props, [(block_type, block_lines), ...])."""
        props: dict[str, str] = {}
        subblocks: list[tuple[str, list[str]]] = []
        i = 0
        while i < len(lines):
            stripped = lines[i].strip()
            m = self._KV_RE.match(lines[i])
            if m:
                props[m.group(1)] = m.group(2)
                i += 1
            elif stripped.startswith("BEGIN "):
                block_type = stripped[6:]
                block_lines, i = self._collect_block(lines, i + 1, block_type)
                subblocks.append((block_type, block_lines))
            else:
                i += 1
        return props, subblocks

    def _parse_job(self, job_lines: list[str], header: dict[str, str]) -> DSJob:
        props, subblocks = self._parse_subblocks(job_lines)
        job = DSJob(
            identifier=props.get("Identifier", ""),
            name="",
            date_modified=props.get("DateModified", ""),
            time_modified=props.get("TimeModified", ""),
            server_name=header.get("ServerName", ""),
            server_version=header.get("ServerVersion", ""),
        )

        # Collect all DSRECORD blocks by their Identifier
        records: dict[str, dict[str, str]] = {}
        record_subblocks: dict[str, list[tuple[str, list[str]]]] = {}
        for btype, blines in subblocks:
            if btype == "DSRECORD":
                rprops, rsubs = self._parse_subblocks(blines)
                rid = rprops.get("Identifier", "")
                records[rid] = rprops
                record_subblocks[rid] = rsubs

        # ROOT record — job metadata + parameters
        root = records.get("ROOT", {})
        job.name = root.get("Name", job.identifier)
        job.category = root.get("Category", "")
        job.job_type = "Sequence" if root.get("JobType", "3") == "1" else "Parallel"

        for btype, blines in record_subblocks.get("ROOT", []):
            if btype == "DSSUBRECORD":
                pprops = self._parse_props(blines)
                if pprops.get("Name") and pprops.get("Name") not in ("APT",):
                    job.parameters.append(DSParameter(
                        name=pprops.get("Name", ""),
                        prompt=pprops.get("Prompt", ""),
                        default=pprops.get("Default", ""),
                        param_type=pprops.get("ParamType", "0"),
                    ))

        # V0 container — stage and link topology
        v0 = records.get("V0", {})
        stage_ids_raw = v0.get("StageList", "").split("|")
        stage_names_raw = v0.get("StageNames", "").split("|")
        stage_type_ids_raw = v0.get("StageTypeIDs", "").split("|")
        link_names_raw = v0.get("LinkNames", "").split("|")
        target_ids_raw = v0.get("TargetStageIDs", "").split("|")
        source_pin_ids_raw = v0.get("LinkSourcePinIDs", "").split("|")

        stage_map: dict[str, DSStage] = {}
        for idx, sid in enumerate(stage_ids_raw):
            sid = sid.strip()
            if not sid:
                continue
            sname = stage_names_raw[idx].strip() if idx < len(stage_names_raw) else sid
            stype = stage_type_ids_raw[idx].strip() if idx < len(stage_type_ids_raw) else ""
            stage_map[sid] = DSStage(
                id=sid,
                name=sname,
                stage_type=stype,
                category=STAGE_CATEGORY.get(stype, "Unknown"),
            )

        link_map: dict[str, DSLink] = {}
        for idx, lname in enumerate(link_names_raw):
            lname = lname.strip()
            if not lname:
                continue
            src_pin = source_pin_ids_raw[idx].strip() if idx < len(source_pin_ids_raw) else ""
            tgt_id = target_ids_raw[idx].strip() if idx < len(target_ids_raw) else ""
            src_id = re.sub(r"P\d+$", "", src_pin) if src_pin else ""
            src_stage = stage_map.get(src_id)
            tgt_stage = stage_map.get(tgt_id)
            link = DSLink(
                name=lname,
                source_stage_id=src_id,
                target_stage_id=tgt_id,
                source_stage_name=src_stage.name if src_stage else src_id,
                target_stage_name=tgt_stage.name if tgt_stage else tgt_id,
            )
            link_map[lname] = link
            if src_stage:
                src_stage.output_links.append(lname)
            if tgt_stage:
                tgt_stage.input_links.append(lname)

        # Extract columns from pin records (e.g. V0S34P2)
        for rid, rprops in records.items():
            if not re.match(r"^V\d+S\d+P\d+$", rid):
                continue
            link_name = rprops.get("Name", "")
            if link_name not in link_map:
                continue
            link = link_map[link_name]
            for btype, blines in record_subblocks.get(rid, []):
                if btype == "DSSUBRECORD":
                    cprops = self._parse_props(blines)
                    cname = cprops.get("Name", "")
                    if cname and cprops.get("SqlType"):
                        link.columns.append(DSColumn(
                            name=cname,
                            sql_type=SQL_TYPES.get(cprops.get("SqlType", ""), cprops.get("SqlType", "")),
                            nullable=cprops.get("Nullable", "1") == "1",
                            length=int(cprops.get("Precision", "0") or "0"),
                            scale=int(cprops.get("Scale", "0") or "0"),
                            derivation=cprops.get("Derivation", ""),
                            source_column=cprops.get("SourceColumn", ""),
                        ))

        job.stages = list(stage_map.values())
        job.links = list(link_map.values())
        return job


# ─── XML Parser ────────────────────────────────────────────────────────────────

class XMLParser:
    """Parses IBM DataStage .xml export files."""

    def parse(self, path: Path) -> list[DSJob]:
        tree = ET.parse(str(path))
        root = tree.getroot()

        header_el = root.find("Header")
        header: dict[str, str] = header_el.attrib if header_el is not None else {}

        jobs: list[DSJob] = []
        for job_el in root.findall("Job"):
            job = self._parse_job(job_el, header)
            job.source_file = str(path)
            job.source_format = "XML"
            jobs.append(job)
        return jobs

    def _get_props(self, el: ET.Element) -> dict[str, str]:
        """Extract all <Property Name="...">value</Property> children."""
        return {
            p.get("Name", ""): (p.text or "")
            for p in el.findall("Property")
        }

    def _parse_job(self, job_el: ET.Element, header: dict[str, str]) -> DSJob:
        job = DSJob(
            identifier=job_el.get("Identifier", ""),
            name="",
            date_modified=job_el.get("DateModified", ""),
            time_modified=job_el.get("TimeModified", ""),
            server_name=header.get("ServerName", ""),
            server_version=header.get("ServerVersion", ""),
        )

        records: dict[str, ET.Element] = {
            r.get("Identifier", ""): r
            for r in job_el.findall("Record")
        }

        # ROOT
        root_el = records.get("ROOT")
        if root_el is not None:
            rprops = self._get_props(root_el)
            job.name = rprops.get("Name", job.identifier)
            job.category = rprops.get("Category", "")
            job.job_type = "Sequence" if rprops.get("JobType") == "1" else "Parallel"
            for col in root_el.findall("Collection"):
                if col.get("Name") == "Parameters":
                    for sr in col.findall("SubRecord"):
                        pprops = self._get_props(sr)
                        if pprops.get("Name"):
                            job.parameters.append(DSParameter(
                                name=pprops.get("Name", ""),
                                prompt=pprops.get("Prompt", ""),
                                default=pprops.get("Default", ""),
                                param_type=pprops.get("ParamType", "0"),
                            ))

        # V0 container — topology
        v0_el = records.get("V0")
        if v0_el is None:
            return job

        v0_props = self._get_props(v0_el)
        stage_ids_raw = v0_props.get("StageList", "").split("|")
        stage_names_raw = v0_props.get("StageNames", "").split("|")
        stage_type_ids_raw = v0_props.get("StageTypeIDs", "").split("|")
        link_names_raw = v0_props.get("LinkNames", "").split("|")
        target_ids_raw = v0_props.get("TargetStageIDs", "").split("|")
        source_pin_ids_raw = v0_props.get("LinkSourcePinIDs", "").split("|")

        stage_map: dict[str, DSStage] = {}
        for idx, sid in enumerate(stage_ids_raw):
            sid = sid.strip()
            if not sid:
                continue
            sname = stage_names_raw[idx].strip() if idx < len(stage_names_raw) else sid
            stype = stage_type_ids_raw[idx].strip() if idx < len(stage_type_ids_raw) else ""
            stage_map[sid] = DSStage(
                id=sid,
                name=sname,
                stage_type=stype,
                category=STAGE_CATEGORY.get(stype, "Unknown"),
            )

        link_map: dict[str, DSLink] = {}
        for idx, lname in enumerate(link_names_raw):
            lname = lname.strip()
            if not lname:
                continue
            src_pin = source_pin_ids_raw[idx].strip() if idx < len(source_pin_ids_raw) else ""
            tgt_id = target_ids_raw[idx].strip() if idx < len(target_ids_raw) else ""
            src_id = re.sub(r"P\d+$", "", src_pin) if src_pin else ""
            src_stage = stage_map.get(src_id)
            tgt_stage = stage_map.get(tgt_id)
            link = DSLink(
                name=lname,
                source_stage_id=src_id,
                target_stage_id=tgt_id,
                source_stage_name=src_stage.name if src_stage else src_id,
                target_stage_name=tgt_stage.name if tgt_stage else tgt_id,
            )
            link_map[lname] = link
            if src_stage:
                src_stage.output_links.append(lname)
            if tgt_stage:
                tgt_stage.input_links.append(lname)

        # Columns from pin records
        for rid, rec_el in records.items():
            if not re.match(r"^V\d+S\d+P\d+$", rid):
                continue
            rprops = self._get_props(rec_el)
            link_name = rprops.get("Name", "")
            if link_name not in link_map:
                continue
            link = link_map[link_name]
            for col_coll in rec_el.findall("Collection"):
                if col_coll.get("Type") in ("OutputColumn", "InputColumn"):
                    for sr in col_coll.findall("SubRecord"):
                        cprops = self._get_props(sr)
                        cname = cprops.get("Name", "")
                        if cname and cprops.get("SqlType"):
                            link.columns.append(DSColumn(
                                name=cname,
                                sql_type=SQL_TYPES.get(cprops.get("SqlType", ""), cprops.get("SqlType", "")),
                                nullable=cprops.get("Nullable", "1") == "1",
                                length=int(cprops.get("Precision", "0") or "0"),
                                scale=int(cprops.get("Scale", "0") or "0"),
                                derivation=cprops.get("Derivation", ""),
                                source_column=cprops.get("SourceColumn", ""),
                            ))

        job.stages = list(stage_map.values())
        job.links = list(link_map.values())
        return job


# ─── Markdown Exporter ─────────────────────────────────────────────────────────

class MarkdownExporter:
    """Output 1: Markdown lineage document."""

    def export(self, jobs: list[DSJob], output_path: Path) -> None:
        lines: list[str] = []
        lines.append(f"# DataStage Job Lineage Report\n")
        lines.append(f"_Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}_\n")
        lines.append(f"**Total jobs:** {len(jobs)}\n")
        lines.append("---\n")

        for job in jobs:
            lines.extend(self._render_job(job))

        output_path.write_text("\n".join(lines), encoding="utf-8")
        log.info("Markdown written → %s", output_path)

    def _render_job(self, job: DSJob) -> list[str]:
        lines: list[str] = []
        lines.append(f"## Job: `{job.name}`\n")

        # Summary table
        lines.append("### Summary\n")
        lines.append("| Field | Value |")
        lines.append("|-------|-------|")
        lines.append(f"| **Identifier** | `{job.identifier}` |")
        lines.append(f"| **Server** | {job.server_name} |")
        lines.append(f"| **Server Version** | {job.server_version} |")
        lines.append(f"| **Date Modified** | {job.date_modified} |")
        lines.append(f"| **Job Type** | {job.job_type} |")
        lines.append(f"| **Category** | {job.category} |")
        lines.append(f"| **Source File** | `{job.source_file}` |")
        lines.append(f"| **Source Format** | {job.source_format} |")
        lines.append("")

        # Parameters
        if job.parameters:
            lines.append("### Parameters\n")
            lines.append("| Name | Prompt | Default | Type |")
            lines.append("|------|--------|---------|------|")
            for p in job.parameters:
                ptype = {"0": "String", "1": "Encrypted", "13": "List"}.get(p.param_type, p.param_type)
                lines.append(f"| `{p.name}` | {p.prompt} | `{p.default}` | {ptype} |")
            lines.append("")

        # Stages
        if job.stages:
            lines.append("### Stages\n")
            lines.append("| Stage Name | Type | Category | Inputs | Outputs |")
            lines.append("|-----------|------|----------|--------|---------|")
            for s in job.stages:
                ins = ", ".join(f"`{l}`" for l in s.input_links) or "—"
                outs = ", ".join(f"`{l}`" for l in s.output_links) or "—"
                lines.append(f"| **{s.name}** | `{s.stage_type}` | {s.category} | {ins} | {outs} |")
            lines.append("")

        # Data flow diagram (Mermaid)
        if job.links:
            lines.append("### Data Flow\n")
            lines.append("```mermaid")
            lines.append("graph LR")
            for lnk in job.links:
                src = lnk.source_stage_name.replace(" ", "_").replace("-", "_")
                tgt = lnk.target_stage_name.replace(" ", "_").replace("-", "_")
                lines.append(f"    {src} -->|{lnk.name}| {tgt}")
            lines.append("```\n")

        # Column lineage per link
        links_with_cols = [lnk for lnk in job.links if lnk.columns]
        if links_with_cols:
            lines.append("### Column Lineage\n")
            for lnk in links_with_cols:
                lines.append(f"#### Link `{lnk.name}`: `{lnk.source_stage_name}` → `{lnk.target_stage_name}`\n")
                lines.append("| Column | SQL Type | Length | Nullable | Derivation | Source Column |")
                lines.append("|--------|----------|--------|----------|------------|---------------|")
                for col in lnk.columns:
                    deriv = f"`{col.derivation}`" if col.derivation else "—"
                    src_col = f"`{col.source_column}`" if col.source_column else "—"
                    null_str = "Yes" if col.nullable else "No"
                    length_str = str(col.length) if col.length > 0 else "—"
                    lines.append(f"| `{col.name}` | {col.sql_type} | {length_str} | {null_str} | {deriv} | {src_col} |")
                lines.append("")

        lines.append("---\n")
        return lines


# ─── Matillion ETL Exporter ────────────────────────────────────────────────────

class MatillionETLExporter:
    """Output 2: Matillion ETL import JSON."""

    def export(self, jobs: list[DSJob], output_path: Path) -> None:
        payload = {
            "version": "1.0",
            "format": "matillion-etl-import",
            "metadata": {
                "exported_at": datetime.now().isoformat(),
                "source_tool": "DataStage Transformation Tool",
                "job_count": len(jobs),
            },
            "jobs": [self._render_job(job) for job in jobs],
        }
        output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        log.info("Matillion ETL JSON written → %s", output_path)

    def _render_job(self, job: DSJob) -> dict:
        stage_by_id = {s.id: s for s in job.stages}

        components = []
        for stage in job.stages:
            matillion_type = MATILLION_COMPONENT_MAP.get(stage.stage_type, "unknown")
            components.append({
                "name": stage.name,
                "type": matillion_type,
                "datastage_stage_type": stage.stage_type,
                "category": stage.category,
                "input_links": stage.input_links,
                "output_links": stage.output_links,
            })

        connections = []
        for lnk in job.links:
            conn: dict = {
                "name": lnk.name,
                "source_component": lnk.source_stage_name,
                "target_component": lnk.target_stage_name,
            }
            if lnk.columns:
                conn["column_mappings"] = [
                    {
                        "target_column": col.name,
                        "sql_type": col.sql_type,
                        "length": col.length,
                        "scale": col.scale,
                        "nullable": col.nullable,
                        "derivation": col.derivation,
                        "source_column": col.source_column,
                    }
                    for col in lnk.columns
                ]
            connections.append(conn)

        variables = [
            {
                "name": p.name,
                "prompt": p.prompt,
                "default_value": p.default,
                "type": "TEXT",
            }
            for p in job.parameters
        ]

        return {
            "name": job.name,
            "identifier": job.identifier,
            "type": "transformation" if job.job_type == "Parallel" else "orchestration",
            "datastage_job_type": job.job_type,
            "server": job.server_name,
            "date_modified": job.date_modified,
            "category": job.category,
            "variables": variables,
            "components": components,
            "connections": connections,
        }


# ─── Matillion Claude Exporter ─────────────────────────────────────────────────

class MatillionClaudeExporter:
    """Output 3: Matillion Claude AI-context JSON for migration assistance."""

    def export(self, jobs: list[DSJob], output_path: Path) -> None:
        payload = {
            "version": "1.0",
            "format": "matillion-claude-context",
            "purpose": "DataStage to Matillion AI-assisted migration",
            "metadata": {
                "exported_at": datetime.now().isoformat(),
                "job_count": len(jobs),
            },
            "jobs": [self._render_job(job) for job in jobs],
        }
        output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        log.info("Matillion Claude JSON written → %s", output_path)

    def _render_job(self, job: DSJob) -> dict:
        sources = [s for s in job.stages if s.category in ("File", "Database", "Source")]
        targets = [s for s in job.stages if s.category in ("File", "Database") and s.output_links == []]
        transforms = [s for s in job.stages if s.category in ("Transform", "Join", "Lookup")]

        # Build column lineage list
        lineage_entries = []
        for lnk in job.links:
            for col in lnk.columns:
                if col.derivation or col.source_column:
                    lineage_entries.append({
                        "target_stage": lnk.target_stage_name,
                        "link": lnk.name,
                        "column": col.name,
                        "sql_type": col.sql_type,
                        "derivation": col.derivation,
                        "source": col.source_column,
                    })

        # Migration notes
        notes = []
        for stage in job.stages:
            if stage.stage_type == "CTransformerStage":
                notes.append(f"Stage '{stage.name}' (Transformer) — review column derivations and map to Matillion Calculator component.")
            elif stage.stage_type in ("Pxsqlsvr",):
                notes.append(f"Stage '{stage.name}' (SQL Server) — extract and parameterise SQL query for Matillion SQL component.")
            elif stage.stage_type == "PxJoin":
                notes.append(f"Stage '{stage.name}' (Join) — identify join keys and join type (inner/left/right) for Matillion Join component.")

        return {
            "job_name": job.name,
            "identifier": job.identifier,
            "job_type": job.job_type,
            "server": job.server_name,
            "category": job.category,
            "summary": (
                f"{job.job_type} job with {len(job.stages)} stage(s) and "
                f"{len(job.links)} link(s). "
                f"Sources: {len(sources)}, Targets: {len(targets)}, Transforms: {len(transforms)}."
            ),
            "parameters": [
                {"name": p.name, "prompt": p.prompt, "default": p.default}
                for p in job.parameters
            ],
            "data_sources": [
                {"name": s.name, "type": s.stage_type, "outputs": s.output_links}
                for s in sources
            ],
            "data_targets": [
                {"name": s.name, "type": s.stage_type, "inputs": s.input_links}
                for s in targets
            ],
            "transformations": [
                {"name": s.name, "type": s.stage_type, "inputs": s.input_links, "outputs": s.output_links}
                for s in transforms
            ],
            "column_lineage": lineage_entries,
            "migration_notes": notes,
        }


# ─── Batch Processor ───────────────────────────────────────────────────────────

def _safe_name(name: str, max_len: int = 80) -> str:
    """Convert a job name to a filesystem-safe string."""
    safe = re.sub(r"[^\w\-]", "_", name)
    safe = re.sub(r"_+", "_", safe).strip("_")
    return safe[:max_len]


def detect_format(path: Path) -> str:
    ext = path.suffix.lower()
    if ext == ".dsd":
        return "dsd"
    if ext == ".xml":
        return "xml"
    # Peek at first line
    try:
        first = path.read_text(encoding="cp1252", errors="replace")[:50]
        if first.strip().startswith("<?xml"):
            return "xml"
        if "BEGIN HEADER" in first or "BEGIN DSJOB" in first:
            return "dsd"
    except Exception:
        pass
    return "unknown"


def load_jobs(path: Path, fmt: str = "auto") -> list[DSJob]:
    if fmt == "auto":
        fmt = detect_format(path)
    if fmt == "dsd":
        return DSDParser().parse(path)
    if fmt == "xml":
        return XMLParser().parse(path)
    raise ValueError(f"Unsupported format '{fmt}' for file: {path}")


def process_file(
    input_path: Path,
    output_dir: Path,
    fmt: str = "auto",
    prefix: str = "",
    do_markdown: bool = True,
    do_etl: bool = True,
    do_claude: bool = True,
    split: bool = True,
) -> None:
    log.info("Processing: %s", input_path)
    jobs = load_jobs(input_path, fmt)
    if not jobs:
        log.warning("No jobs found in: %s", input_path)
        return
    log.info("  Found %d job(s)", len(jobs))

    output_dir.mkdir(parents=True, exist_ok=True)

    if split:
        # One set of output files per job, named after the job
        for job in jobs:
            stem = prefix + _safe_name(job.name)
            if do_markdown:
                MarkdownExporter().export([job], output_dir / f"{stem}_lineage.md")
            if do_etl:
                MatillionETLExporter().export([job], output_dir / f"{stem}_matillion_etl.json")
            if do_claude:
                MatillionClaudeExporter().export([job], output_dir / f"{stem}_matillion_claude.json")
    else:
        # All jobs from the source file combined into one output file
        stem = prefix + input_path.stem
        if do_markdown:
            MarkdownExporter().export(jobs, output_dir / f"{stem}_lineage.md")
        if do_etl:
            MatillionETLExporter().export(jobs, output_dir / f"{stem}_matillion_etl.json")
        if do_claude:
            MatillionClaudeExporter().export(jobs, output_dir / f"{stem}_matillion_claude.json")


def run_batch(config_path: Path) -> None:
    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8"))

    log.info("Batch config: %s", config_path)

    input_dir = Path(cfg.get("input_directory", "."))
    output_dir = Path(cfg.get("output_directory", "output"))
    prefix = cfg.get("output_prefix", "")

    outputs = cfg.get("outputs", {})
    do_md = outputs.get("markdown", True)
    do_etl = outputs.get("matillion_etl", True)
    do_claude = outputs.get("matillion_claude", True)
    split = bool(cfg.get("split", True))

    files_cfg = cfg.get("files", [])
    if files_cfg:
        for entry in files_cfg:
            fp = Path(entry["path"])
            fmt = entry.get("format", "auto")
            process_file(fp, output_dir, fmt, prefix, do_md, do_etl, do_claude, split)
    else:
        # Auto-discover all .dsd and .xml files in input_directory
        patterns = ["*.dsd", "*.xml"]
        for pattern in patterns:
            for fp in sorted(input_dir.glob(pattern)):
                process_file(fp, output_dir, "auto", prefix, do_md, do_etl, do_claude, split)


# ─── CLI ───────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="DataStage → Matillion transformation tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--config", "-c", type=Path, help="YAML batch config file")
    parser.add_argument("--file", "-f", type=Path, help="Single DataStage file (.dsd or .xml)")
    parser.add_argument("--output", "-o", type=Path, default=Path("output"), help="Output directory (default: output/)")
    parser.add_argument("--format", choices=["auto", "dsd", "xml"], default="auto", help="Input format override")
    parser.add_argument("--no-markdown", action="store_true", help="Skip Markdown output")
    parser.add_argument("--no-etl", action="store_true", help="Skip Matillion ETL output")
    parser.add_argument("--no-claude", action="store_true", help="Skip Matillion Claude output")
    parser.add_argument(
        "--no-split", action="store_true",
        help="Combine all jobs from one file into a single output (default: split per job)",
    )
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if args.config:
        run_batch(args.config)
    elif args.file:
        process_file(
            args.file,
            args.output,
            args.format,
            do_markdown=not args.no_markdown,
            do_etl=not args.no_etl,
            do_claude=not args.no_claude,
            split=not args.no_split,
        )
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
