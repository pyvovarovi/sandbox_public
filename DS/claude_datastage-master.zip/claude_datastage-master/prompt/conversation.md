# Project Conversation Log

Development history of the **qbo-quickbooks** project — a tool that imports
QBO bank files into SQLite and exports transactions to QuickBooks Desktop.

---

## Prompt 001 — Package Manager Rule

**File:** `prompt/001.txt`

> when you create python code, for package management use UV package manager,
> do not use "pip install" ever.

**Action:** Saved as a standing rule for all subsequent Python work.

- Always use `uv add <package>` to add dependencies
- Always use `uv run <script>` to run scripts
- Never use `pip install`

---

## Prompt 002 — QBO Importer (`import_qbo.py`)

**File:** `prompt/002.txt`

> Create python script, which will read *.qbo files from directory, create
> sqlite DB, append new transactions to tables.
> QBO samples at claude_QuickBooks\sample_qbo

**Created:** [`import_qbo.py`](../import_qbo.py)

### What it does

Reads QBO (QuickBooks Online export) files, which use the OFX/SGML format,
and loads all transactions into a local SQLite database.

### QBO format notes

QBO files are SGML (not proper XML) — leaf-element values have no closing tag:

```
<TRNTYPE>CREDIT
<TRNAMT>1600.00
<FITID>90000010020251103C00171746D48
```

Container elements do have closing tags (`</STMTTRN>`, `</STMTRS>`, etc.).
A custom regex-based parser handles both patterns.

Two account classes appear in QBO files:
- **Bank accounts** — inside `<BANKMSGSRSV1>` → `<STMTTRNRS>` → `<STMTRS>`
- **Credit-card accounts** — inside `<CREDITCARDMSGSRSV1>` → `<CCSTMTTRNRS>` → `<CCSTMTRS>`

### Database schema (SQLite)

| Table | Purpose |
|---|---|
| `accounts` | One row per unique account (CHECKING / SAVINGS / CREDITCARD) |
| `transactions` | All transactions; `fitid` is UNIQUE — prevents duplicates |
| `account_balances` | Ledger balance snapshot from each imported file |
| `imported_files` | Audit log of every import run (new vs skipped counts) |

### Duplicate prevention

`FITID` (Financial Institution Transaction ID) is the natural unique key
provided by the bank in every QBO file. Transactions are inserted with
`INSERT OR IGNORE` so re-importing the same file is always safe.

### Usage

```bash
uv run import_qbo.py [qbo_dir] [db_path]
# defaults: sample_qbo  transactions.db
```

### Sample results (from `sample_qbo/`)

| File | Accounts | Transactions |
|---|---|---|
| `2026-02-22_C.qbo` | 2 bank accounts | 96 |
| `2026-02-22_V.qbo` | 3 credit-card accounts | 138 |
| **Total** | **5** | **234** |

---

## Prompt 003 — QuickBooks Exporter (`qb_export.py`)

**File:** `prompt/003.txt`

> create another python code qb_export.py, which will read sqlite db and
> insert new transactions into quickbooks desktop

**Created:** [`qb_export.py`](../qb_export.py)

### How QuickBooks Desktop integration works

QuickBooks Desktop exposes a COM-based API called **QBXML SDK**
(`QBXMLRP2.RequestProcessor`). The script connects via `win32com.client`
(from the `pywin32` package) and sends XML requests in the **QBXML** dialect.

Each bank/CC transaction becomes a **General Journal Entry** in QuickBooks —
the most flexible transaction type that works for any account combination.

### Journal-entry logic

| `trnamt` | Debit side | Credit side |
|---|---|---|
| `> 0` (money in) | QB account | Offset account |
| `< 0` (money out) | Offset account | QB account |

This is correct for both asset accounts (bank) and liability accounts
(credit cards) in double-entry bookkeeping.

### Configuration (top of `qb_export.py`)

```python
ACCOUNT_MAP = {
    "060611012251":     "Chequing",        # QBO account_id -> QB FullName
    "4516050003417221": "Visa Ending 7221",
    ...
}
DEFAULT_OFFSET_ACCOUNT = "Ask My Accountant"  # QB built-in catch-all
QB_COMPANY_FILE = ""   # "" = use currently-open file
```

Run `--list-accounts` to query QB and see exact account FullNames.

### Deduplication

Successful exports are recorded in the `qb_exports` table (added to the
existing SQLite DB). A transaction is never sent to QuickBooks twice.

### Usage

```bash
uv run qb_export.py --dry-run          # preview without touching QB
uv run qb_export.py --list-accounts    # print all QB account names
uv run qb_export.py --db myfile.db     # use a specific database
uv run qb_export.py                    # export to QuickBooks Desktop
```

### Requirements

- QuickBooks Desktop 2019+ installed and **running** with a company file open
- `pywin32` (managed by UV — added to `pyproject.toml`)
- On first run: QB shows a permission dialog — click **"Yes, always"**

---

## Prompt 004 — UV Project Infrastructure + `demo.bat`

**File:** `prompt/004.txt`

> from now on, create UV infrastructure which include but not limited to:
> uv init, uv add.
> create and support demo.bat file, which will run different test scenarios
> and include "uv sync"

### UV project setup

```bash
uv init --app --no-readme --name qbo-quickbooks   # created pyproject.toml
uv add pywin32                                     # added dependency + uv.lock
```

**Files created by UV:**

| File | Purpose |
|---|---|
| `pyproject.toml` | Project metadata and dependencies |
| `uv.lock` | Locked dependency graph (committed for reproducibility) |
| `.python-version` | Pins Python 3.12 |
| `.venv/` | Project virtual environment (git-ignored) |

The inline `# /// script` headers were removed from both scripts since the
project venv now manages all dependencies.

### `demo.bat` — test scenarios

**Created:** [`demo.bat`](../demo.bat)

```
demo.bat          run all 6 scenarios sequentially
demo.bat 1        uv sync only
demo.bat 2        fresh import (deletes demo DB, imports QBO files)
demo.bat 3        re-import (verifies 234 duplicates are skipped)
demo.bat 4        dry-run export (previews QB journal entries)
demo.bat 5        DB summary (counts, accounts, transactions per account)
demo.bat 6        CLI help for both scripts
```

Uses a separate `demo_transactions.db` to avoid touching the main database.

---

## Prompt 005 — `.gitignore`

**File:** `prompt/005.txt`

> create .gitignore file

**Created/updated:** [`.gitignore`](../.gitignore)

Key sections:

| Category | Patterns ignored |
|---|---|
| Python | `__pycache__/`, `*.py[oc]`, `build/`, `dist/` |
| UV / venv | `.venv/` (lock file is committed) |
| SQLite | `*.db`, `*.db-shm`, `*.db-wal`, `*.db-journal` |
| QuickBooks | `*.qbw`, `*.qbb`, `*.qbm`, `*.qbx` |
| IDE | `.vscode/`, `.idea/` |
| Windows | `Thumbs.db`, `Desktop.ini` |
| Demo artifacts | `demo_*.db`, `demo_out.txt`, `*.tmp` |

---

## Prompt 006 — `.gitattributes`

**File:** `prompt/006.txt`

> create .gitattributes file

**Created:** [`.gitattributes`](../.gitattributes)

Key rules:

| Pattern | EOL | Notes |
|---|---|---|
| `*` | `text=auto eol=lf` | Default: LF everywhere |
| `*.py`, `*.pyi` | `lf` | Python standard |
| `*.bat`, `*.cmd`, `*.ps1` | **`crlf`** | Windows requires CRLF for `cmd.exe` |
| `*.toml`, `*.lock`, `*.md`, `*.json` | `lf` | Config/data files |
| `*.qbo`, `*.ofx` | `lf` | Financial data files |
| `*.db`, `*.qbw`, `*.7z`, `*.dll` | `binary` | No EOL conversion or text diff |
| Dev files | — | `export-ignore` — excluded from `git archive` |

---

## Prompt 007 — This file

**File:** `prompt/007.txt`

> create and support conversation file at: /prompt/conversation.md

**Created:** `prompt/conversation.md` (this file)

---

## Project File Map

```
c:\claude_QuickBooks\
├── import_qbo.py          # QBO -> SQLite importer
├── qb_export.py           # SQLite -> QuickBooks Desktop exporter
├── demo.bat               # Demo runner (6 test scenarios)
├── pyproject.toml         # UV project config (pywin32 dependency)
├── uv.lock                # Locked dependency graph
├── .python-version        # Python 3.12
├── .gitignore             # Git ignore rules
├── .gitattributes         # Git line-ending and binary rules
├── .venv/                 # Virtual environment (git-ignored)
├── transactions.db        # SQLite database (git-ignored)
├── sample_qbo/
│   ├── 2026-02-22_C.qbo   # Sample bank QBO (2 accounts, 96 transactions)
│   └── 2026-02-22_V.qbo   # Sample credit-card QBO (3 accounts, 138 transactions)
└── prompt/
    ├── #list.txt           # Prompt execution list
    ├── 001.txt  ...007.txt # Individual prompts
    └── conversation.md    # This file
```

## Quick-start

```bash
# 1. Set up the environment
uv sync

# 2. Import QBO files
uv run import_qbo.py sample_qbo transactions.db

# 3. Preview what would go to QuickBooks
uv run qb_export.py --dry-run

# 4. (After configuring ACCOUNT_MAP) export to QuickBooks Desktop
uv run qb_export.py

# 5. Run the full demo
demo.bat
```
